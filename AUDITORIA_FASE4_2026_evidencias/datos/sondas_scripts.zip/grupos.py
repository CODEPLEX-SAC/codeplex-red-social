import json, collections, statistics, sys
from analizar import *

base = jsonl(A + r'\base\base.jsonl')
emp6 = jsonl(A + r'\emp6\base.jsonl')
e1280 = jsonl(A + r'\e1280\estado.jsonl')
e400 = jsonl(A + r'\e400\estado.jsonl')
shell = jsonl(A + r'\shell\estado.jsonl')
n2 = jsonl(A + r'\n2a\estado.jsonl') + jsonl(A + r'\n2b\estado.jsonl') + jsonl(A + r'\n2c\estado.jsonl')

VP = [1280, 820, 400, 320]
obs = []
visitas = set()
estados = []
errores = []
for fuente, lista in (('base', base), ('emp6', emp6)):
    for d in lista:
        if 'error' in d:
            errores.append((d['ruta'], d['w'], d['error']))
            continue
        visitas.add((d['ruta'], d['w'], 'Base'))
        for c in d['controles']:
            obs.append((d['ruta'], d['w'], 'Base', fuente, c))
for fuente, lista in (('est1280', e1280), ('est400', e400), ('shell', shell), ('nivel2', n2)):
    for d in lista:
        if d.get('modo') != 'estado':
            continue
        n = d['disparador']['n']
        if d.get('cambioUrl'):
            estados.append(dict(ruta=d['ruta'], w=d['w'], estado='Navega a ' + d['urlTras'], disparador=n, cambioUrl=True, fuente=fuente, n=0, paneles=[], nivel=d.get('nivel', 1)))
            continue
        etiqueta = f"Tras clic en «{nombre_visible(n)}»" if not d.get('nivel') else f"Tras clic en «{nombre_visible(d['padre']['n'])}» → «{nombre_visible(n)}»"
        visitas.add((d['ruta'], d['w'], etiqueta))
        estados.append(dict(ruta=d['ruta'], w=d['w'], estado=etiqueta, disparador=n, cambioUrl=False, fuente=fuente, n=len(d['nuevos']), paneles=d['paneles'], nivel=d.get('nivel', 1), desborde=d['desborde'], rol=d['disparador']['rol']))
        for c in d['nuevos']:
            obs.append((d['ruta'], d['w'], etiqueta, fuente, c))


def estructural(c):
    return c['region'] in ('barra_superior', 'barra_lateral', 'estructura')


def modulo_de_archivo(f):
    if not f:
        return None
    p = f.split('/')
    if p[0] in ('componentes', 'paginas', 'formularios', 'tablas') and len(p) > 1:
        if p[1] == 'compartido':
            return 'Compartido'
        return MAPA_DIR.get(p[1], p[1])
    return None


MAPA_DIR = {'inicio': 'Inicio', 'actividad': 'Actividad', 'avisos': 'Notificaciones', 'mensajeria': 'Mensajes', 'amigos': 'Amigos', 'grupos': 'Grupos', 'marketplace': 'Marketplace', 'eventos': 'Eventos', 'guardados': 'Guardados', 'colaboradores': 'Colaboradores', 'empresas': 'Empresas', 'dashboard': 'Dashboard', 'estadisticas': 'Estadísticas', 'reportes': 'Reportes', 'indicadores': 'Indicadores', 'acceso': 'Acceso'}


def origen(c, pr):
    """consumidor (componente que escribe el JSX), archivo y propietario de módulo"""
    if pr:
        duenos = pr.get('duenos') or []
        arch = pr.get('archivo')
        cons = duenos[0] if duenos else consumidor(c)
    else:
        duenos = c.get('duenosHost') or []
        arch = c.get('archivoHost')
        cons = duenos[0] if duenos else consumidor(c)
    if arch is None:
        arch = archivo_de(cons)
    return cons, arch


G = {}
for ruta, w, estado, fuente, c in obs:
    if c['tipo'] == 'archivo' and c['w'] <= 2:
        continue
    pr = principal(c)
    cons, arch = origen(c, pr)
    nat = nativo_clase(c)
    fam = familia(c, pr, nat)
    var = pr['props'].get('variant') if pr else None
    size = pr['props'].get('size') if pr else None
    if pr and pr['nombre'] == 'BotonPieLista':
        size = 'pie_lista'
    if cons == 'PaginaNoEncontrada':
        scope = 'Página no encontrada (404)'
    elif estructural(c):
        scope = ESTRUCTURA
    else:
        scope = modulo_de_archivo(arch) or modulo_de(ruta)
        if scope == 'Compartido':
            scope = 'Compartido (componente reutilizado por varios módulos)'
    ctx = 'modal' if en_modal(c) else ('superposición' if c['region'] == 'superposicion' else ('barra superior' if c['region'] == 'barra_superior' else ('barra lateral' if c['region'] == 'barra_lateral' else 'página')))
    wr = pr['nombre'] if pr else ('MUI/librería' if es_mui(c) else 'nativo:' + (nat or ''))
    k = (scope, fam, cons, arch, wr, var, size, ctx, c['tag'])
    g = G.setdefault(k, dict(scope=scope, fam=fam, cons=cons, archivo=arch, wrapper=pr['nombre'] if pr else None, wr=wr, var=var, size=size, ctx=ctx, nat=nat, libMui=es_mui(c), tag=c['tag'], tipo=c['tipo'], obs=[]))
    g['obs'].append((ruta, w, estado, fuente, c, pr))

FINAL = []
for k, g in G.items():
    claves = collections.defaultdict(list)
    for o in g['obs']:
        claves[nombre_clave(o[4]['nombre'])].append(o)
    if len(claves) <= 3:
        for nk, lst in claves.items():
            cn = collections.Counter(nombre_visible(o[4]['nombre']) for o in lst)
            FINAL.append(dict(g, obs=lst, nombre=cn.most_common(1)[0][0], colapsado=False, n_etiquetas=1))
    else:
        cn = collections.Counter(nombre_visible(o[4]['nombre']) for o in g['obs'])
        top = [n for n, _ in cn.most_common(3)]
        FINAL.append(dict(g, nombre=f"({len(claves)} etiquetas distintas; p. ej. " + '; '.join(x[:22] for x in top) + ')', colapsado=True, n_etiquetas=len(claves)))


def rango(v):
    v = [x for x in v if x is not None]
    if not v:
        return None
    a, b = min(v), max(v)
    return f'{a:g}' if abs(a - b) < 0.05 else f'{a:g}–{b:g}'


def moda(v):
    v = [json.dumps(x) for x in v if x is not None]
    return json.loads(collections.Counter(v).most_common(1)[0][0]) if v else None


ANCHOS_EMP = [1280, 1024, 768, 600, 390, 320]
for g in FINAL:
    g['rutas'] = sorted({o[0] for o in g['obs']})
    g['estados'] = sorted({o[2] for o in g['obs']})
    g['fuentes'] = sorted({o[3] for o in g['obs']})
    g['por_vp'] = {}
    origen_base = any(o[3] == 'base' or o[3] == 'emp6' for o in g['obs'])
    for w in VP + [1024, 768, 600, 390]:
        ob = [o for o in g['obs'] if o[1] == w]
        if ob:
            cs = [o[4] for o in ob]
            n_pant = collections.Counter((o[0], o[2]) for o in ob).most_common(1)[0][1]
            g['por_vp'][w] = dict(estado='MEDIDO', h=rango([c['h'] for c in cs]), w=rango([c['w'] for c in cs]), hmin=min(c['h'] for c in cs), hmax=max(c['h'] for c in cs), n=n_pant,
                                  pad=moda([c['pad'] for c in cs]), padInterno=moda([c['padInterno'] for c in cs]), borde=moda([c['borde'] for c in cs]), radio=moda([c['radio'] for c in cs]),
                                  fuente=moda([c['fuente'] for c in cs]), peso=moda([c['peso'] for c in cs]), lh=moda([c['lh'] for c in cs]), gap=moda([c['gap'] for c in cs]),
                                  iconos=moda([[i['w'] for i in (c['iconos'] or [])] for c in cs]), icfs=moda([[i['fs'] for i in (c['iconos'] or [])] for c in cs]), color=moda([c['color'] for c in cs]), fondo=moda([c['fondo'] for c in cs]), bordeColor=moda([c['bordeColor'] for c in cs]),
                                  minH=moda([c['minH'] for c in cs]), desborde=any(False for _ in cs), ariaExpanded=moda([c['ariaExpanded'] for c in cs]))
        else:
            if w in (1024, 768, 600, 390):
                if g['scope'] == 'Empresas' or any(r.startswith('/empresas') for r in g['rutas']):
                    vis = any((r, w, e) in visitas for r in g['rutas'] for e in g['estados'])
                    g['por_vp'][w] = dict(estado='NO VISIBLE' if vis else 'NO VERIFICADO')
                continue
            vis = any((r, w, e) in visitas for r in g['rutas'] for e in g['estados'])
            if vis and (origen_base or True):
                g['por_vp'][w] = dict(estado='NO VISIBLE')
            else:
                g['por_vp'][w] = dict(estado='NO VERIFICADO')


CHEV = re.compile(r'keyboard_arrow_(down|up)|expand_(more|less)|arrow_drop_(down|up)|unfold_more')


def es_pseudo_selector(g):
    if g['wrapper'] != 'Boton' or g['var'] != 'secundario':
        return False
    c0 = g['obs'][0][4]
    raws = {o[4]['nombre'] for o in g['obs']}
    return any(CHEV.search(r) for r in raws) and c0['ariaHaspopup'] is None and c0['ariaExpanded'] is None and not re.search(r'(?i)cargar|ver más|ver mas', g['nombre'])


def evalua(g):
    """devuelve dict(resultado, clase_reutilizacion, motivos[], tokens_locales, contrato)"""
    pr = None
    for o in g['obs']:
        if o[5]:
            pr = o[5]
            break
    c0 = g['obs'][0][4]
    motivos = []
    if pr and pr['nombre'] in ('SelectorFecha', 'SelectorHora') and g['nombre'] not in ('Selector de fecha', 'Selector de hora'):
        return dict(resultado='NO DETERMINADO', clase='Parte interna del calendario/reloj emergente de la librería (MUI X Date Pickers)', motivos=['elemento del selector emergente: dimensiones por defecto de la librería; sin contrato dimensional en el sistema'], seg=[], dim=[], otros=[], contrato='sin contrato', registro=None)
    res = None
    cls = None
    seg = dim = otros = []
    contrato_txt = 'sin contrato de altura'
    reg = None
    if pr:
        cls = 'Componente compartido (wrapper CodePlex)'
        cn = pr['props'].get('className')
        seg, dim, otros = tokens_locales(cn)
        fallos = []
        for w, v in g['por_vp'].items():
            if v['estado'] != 'MEDIDO':
                continue
            contr = contrato_altura(c0, pr, w, g['nat'])
            contrato_txt = texto_contrato(contr)
            if contr and g['fam'] != 'Caja de texto multilínea':
                if contr[0] == 'min' and v['hmin'] + 0.6 < contr[1]:
                    fallos.append(f'{w}px: altura {v["h"]} < contrato {contr[1]}')
                elif contr[0] == 'exacta' and (abs(v['hmin'] - contr[1]) > 0.6 or abs(v['hmax'] - contr[1]) > 0.6):
                    fallos.append(f'{w}px: altura {v["h"]} ≠ contrato {contr[1]}')
        if fallos:
            motivos.append('altura fuera de contrato (' + '; '.join(fallos[:2]) + ')')
        if dim:
            motivos.append('estilo local dimensional/tipográfico en className: ' + ' '.join(dim[:6]))
        if otros:
            motivos.append('estilo local de color/superficie en className: ' + ' '.join(otros[:6]))
        if pr['nombre'] == 'Boton' and es_pseudo_selector(g):
            motivos.append('desplegable simulado: Boton secundario + chevron sin panel ni aria-haspopup/aria-expanded (la función es la de un Selector; el clic no abre nada)')
        res = 'INCUMPLE' if motivos else 'CUMPLE'
        if pr['nombre'] in ('Casilla', 'Radio', 'Interruptor', 'Paginacion', 'Menu'):
            contrato_txt = 'sin contrato de altura (librería con configuración compartida)'
    elif g['nat'] == 'chip':
        cls = 'Componente propio que consume la configuración compartida (clasesChip)'
        contrato_txt = '32 px'
        hs = [v['hmin'] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'] + [v['hmax'] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO']
        res = 'CUMPLE' if all(abs(h - 32) <= 0.6 for h in hs) else 'INCUMPLE'
        if res == 'INCUMPLE':
            motivos.append('altura de chip ≠ 32 px')
        pads = sorted({v['pad'][3] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO' and v.get('pad')})
        if pads and any(abs(x - 14) > 0.6 for x in pads):
            res = 'INCUMPLE'
            motivos.append('padding horizontal del chip ' + '/'.join(f'{x:g}' for x in pads) + ' px frente a 14 px del contrato clasesChip (px-3.5): sobrescrito en el consumidor')
    elif g['nat'] == 'boton_pie':
        cls = 'Componente propio que consume la configuración compartida (clasesBoton, tamaño pie_lista)'
        contrato_txt = 'sin contrato de altura (pie_lista: p-3.5)'
        res = 'CUMPLE'
    elif g['nat'] == 'boton':
        cls = 'Componente propio que consume la configuración compartida (clasesBoton)'
        contrato_txt = 'uno de 30/34/40/48 px'
        hs = [v['hmin'] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO']
        res = 'CUMPLE' if all((h < 28) or any(abs(h - x) <= 0.6 for x in (30, 34, 40, 48)) for h in hs) else 'INCUMPLE'
        if res == 'INCUMPLE':
            motivos.append('altura fuera de {30,34,40,48}: ' + ', '.join(sorted({f'{h:g}' for h in hs})))
    elif g['nat'] == 'pie_enlace':
        cls = 'Componente propio que implementa un patrón paralelo (pie de lista hecho a mano; existe BotonPieLista)'
        hs = sorted({v['hmin'] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'})
        contrato_txt = 'BotonPieLista: 49 px'
        res = 'INCUMPLE'
        motivos.append('enlace de pie de lista escrito a mano (' + '/'.join(f'{h:g}' for h in hs) + ' px) en lugar de BotonPieLista (49 px)')
    elif g['nat'] == 'boton_a_mano':
        cls = 'Componente propio que implementa un patrón paralelo (botón secundario hecho a mano)'
        hs = sorted({v['hmin'] for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'})
        contrato_txt = 'uno de 30/34/40/48 px'
        res = 'INCUMPLE'
        motivos.append('enlace con clases de botón secundario escritas a mano (' + '/'.join(f'{h:g}' for h in hs) + ' px, fuera de 30/34/40/48) en lugar de Boton o clasesBoton')
    elif g['nat'] == 'fila':
        cls = 'Nativo sin equivalente compartido (fila de lista navegable)'
        res = 'NO DETERMINADO'
        motivos.append('fila de lista con enlace: sin componente compartido; patrón repetido en Amigos y paneles laterales')
    elif g['nat'] == 'mapa':
        cls = 'Librería de mapas (Leaflet), sin contrato de diseño'
        res = 'NO DETERMINADO'
        motivos.append('control interno del mapa Leaflet')
    elif g['nat'] == 'texto':
        cls = 'Nativo sin equivalente de caja (enlace de texto con clases del sistema)'
        res = 'CUMPLE'
    elif g['libMui'] and not (g['archivo'] and g['archivo'] in REGISTRO):
        cls = 'Librería directa (MUI / @codeplex-sac sin envoltorio propio)'
        res = 'CUMPLE' if g['scope'] == ESTRUCTURA else 'NO DETERMINADO'
        if res == 'NO DETERMINADO':
            motivos.append('componente de librería sin contrato dimensional en el sistema')
    else:
        f = g['archivo']
        reg = REGISTRO.get(f) if f else None
        if reg:
            cls = f"Nativo con excepción registrada (clase {reg['clase']})"
            if reg['clase'] in ('A', 'B'):
                res = 'CUMPLE'
            else:
                res = 'NO DETERMINADO'
            motivos.append('registro_componentes_permitidos: ' + reg['motivo'])
        else:
            cls = 'Componente propio que implementa un patrón paralelo / nativo no registrado'
            res = 'NO DETERMINADO'
            motivos.append('control nativo sin entrada en el registro de excepciones; requiere clasificación')
    return dict(resultado=res, clase=cls, motivos=motivos, seg=seg, dim=dim, otros=otros, contrato=contrato_txt, registro=reg)


for g in FINAL:
    g['ev'] = evalua(g)

if __name__ == '__main__':
    print('obs', len(obs), 'grupos', len(FINAL), 'visitas', len(visitas), 'estados', len(estados), 'errores', len(errores), file=sys.stderr)
    cnt = collections.Counter((g['ev']['resultado']) for g in FINAL)
    print(cnt)
    cnt2 = collections.Counter((g['fam'], g['ev']['resultado']) for g in FINAL)
    for k, v in sorted(cnt2.items()):
        print(k, v)
