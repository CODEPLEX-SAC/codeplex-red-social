import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', '--remote-debugging-port=9397', `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch('http://127.0.0.1:9397/json')).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

await cdp('Page.enable')
const SONDA = `(() => {
  const el = [...document.querySelectorAll('aside *')].filter((e) => e.children.length < 3 && /m.dulos disponibles/i.test(e.textContent || '') && e.textContent.length < 40).pop()
  if (!el) return null
  const cs = getComputedStyle(el); const r = el.getBoundingClientRect()
  const p = el.parentElement; const rp = p.getBoundingClientRect()
  return { tag: el.tagName, texto: el.textContent.slice(0, 40), w: r.width, h: r.height, ls: cs.letterSpacing, fs: cs.fontSize, fw: cs.fontWeight, ff: cs.fontFamily.slice(0, 40), tt: cs.textTransform, lh: cs.lineHeight, wsp: cs.whiteSpace, padre: p.tagName, pw: rp.width, ph: rp.height, plazas: [...p.children].map((c) => ({ t: c.tagName, w: Math.round(c.getBoundingClientRect().width * 10) / 10, h: Math.round(c.getBoundingClientRect().height * 10) / 10 })) }
})()`
const RES = {}
for (const [clave, base] of [['ref', 'http://localhost:5180'], ['act', 'http://localhost:5173']]) {
  await viewport(1280, 900, false)
  await cdp('Page.navigate', { url: base + '/empresas' }); await dormir(5000)
  RES[clave] = await evalJS(SONDA)
}
console.log(JSON.stringify(RES, null, 1))
ws.close(); chrome.kill(); process.exit(0)
