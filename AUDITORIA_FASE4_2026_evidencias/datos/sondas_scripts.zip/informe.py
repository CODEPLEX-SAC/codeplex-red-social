import json, collections, re, os, sys, shutil, zipfile
from datos7 import *

D = ensamblar()
json.dump(D, open(SC + r'\au\datos.json', 'w', encoding='utf8'), ensure_ascii=False)

NOMBRE = 'AUDITORIA_DISENO_COMPARTIDO_2026_FASE4'
EVID = 'AUDITORIA_FASE4_2026_evidencias'
RAIZ_REPO = RAIZ

# ---------------------------------------------------------------- cifras
inv = D['inventario']
res_c = collections.Counter(r['resultado'] for r in inv)
n_visitas_base = len({(r, w) for (r, w, e) in visitas if e == 'Base'})
n_estados = len({(e['ruta'], e['w'], e['estado']) for e in estados if not e['cambioUrl']})
n_nav = sum(1 for e in estados if e['cambioUrl'])
n2_est = sum(1 for e in estados if e.get('nivel') == 2 and not e['cambioUrl'])
instancias_total = sum(1 for _ in obs)
rutas_vis = sorted({r for (r, w, e) in visitas})
dim_c = collections.Counter(r['estado'] for r in D['dimensiones'])
reut_c = collections.Counter(reutiliza(g) for g in FINAL)
mods15 = MODULOS[:15]
res_mod = {r['modulo']: r for r in D['resumen']}
tot_inc = collections.Counter(i['prioridad'] for i in D['incidencias'])


def esc(s):
    return str(s).replace('|', '\\|').replace('\n', ' ')


def tabla(cols, filas, anchos=None):
    out = ['| ' + ' | '.join(cols) + ' |', '|' + '|'.join(['---'] * len(cols)) + '|']
    for f in filas:
        out.append('| ' + ' | '.join(esc(x) for x in f) + ' |')
    return '\n'.join(out)


# ---------------------------------------------------------------- meta para Excel
fecha = '2026-10-17'
META = dict(
    resumen_notas=[
        f'Fecha de la auditoría: {fecha} · rama codeplexMaster · HEAD 6c11e0f + cambios sin confirmar de las fases 2–3 · sin modificar componentes, estilos, tokens ni línea base.',
        'Fuente de las medidas: Chrome headless (CDP) sobre el servidor Vite del proyecto, getBoundingClientRect/getComputedStyle; contrato: código (compartido.json, boton.tsx, etc.). «CUMPLE / INCUMPLE / NO VERIFICADO / NO DETERMINADO» tal como los define el informe Markdown.',
        'Un «control único» agrupa instancias repetidas (mismo componente consumidor, wrapper, variante, tamaño, contexto y etiqueta); las repeticiones aparecen en «Instancias máx. por pantalla». La barra superior/lateral se cuenta una sola vez en «Estructura compartida».',
    ],
    hechos=[
        ('Rutas registradas', f'{len(RUTAS_APP)} rutas de aplicación (+ /no-encontrada, no inventariada). Rutas visitadas en 4 viewports (1280, 820, 400, 320): {sum(1 for r in RUTAS_APP if len({w for (rr, w, e) in visitas if rr == r and e == "Base"}) >= 4)}.'),
        ('Visitas base', f'{n_visitas_base} combinaciones ruta × viewport en estado base (incluye los seis anchos de /empresas).'),
        ('Estados tras interacción', f'{n_estados} estados distintos (ruta × viewport × clic) sin cambio de URL, de ellos {n2_est} de segundo nivel (modales/paneles); {n_nav} clics navegaron a otra ruta (pestañas) y no se recontaron.'),
        ('Observaciones de controles', f'{instancias_total} observaciones brutas de controles interactivos (antes de agrupar).'),
        ('Controles únicos inventariados', f'{len(inv)}: CUMPLE {res_c.get("CUMPLE", 0)} · INCUMPLE {res_c.get("INCUMPLE", 0)} · NO DETERMINADO {res_c.get("NO DETERMINADO", 0)} · NO VERIFICADO {res_c.get("NO VERIFICADO", 0)}.'),
        ('Catálogo de dimensiones', f'{len(D["dimensiones"])} filas: CUMPLE {dim_c.get("CUMPLE", 0)} · INCUMPLE {dim_c.get("INCUMPLE", 0)} · NO DETERMINADO {dim_c.get("NO DETERMINADO", 0)} · NO VERIFICADO {dim_c.get("NO VERIFICADO", 0)}.'),
        ('Reutilización (A+B)', f'A compartido {reut_c["A"]} · B propio con configuración compartida {reut_c["B"]} · C paralelo/no clasificado {reut_c["C"]} · D librería directa {reut_c["D"]} · E nativo con excepción {reut_c["E"]}.'),
        ('Incidencias', ', '.join(f'{k}: {v}' for k, v in sorted(tot_inc.items()))),
        ('Línea base', 'No modificada. «Regresión Empresas» compara 6 anchos de /empresas; la versión de referencia (commit a2b857e renderizado) reproduce la firma de roles.json en los 6 anchos.'),
    ],
    inventario_notas=['Los hipervínculos de «Archivo del consumidor» abren el archivo (file:///). Altura/ancho: rango mín–máx si hay varias instancias; NO VISIBLE = la ruta se visitó en ese viewport y el control no estaba; NO VERIFICADO = no se visitó ese estado/viewport.'],
    dimensiones_notas=['Contractual = valor derivado del código (clases de compartido.json, tokens de index.css); efectivo = medida del navegador. «NO DETERMINADO» en una fila indica que el código no define un valor contractual para esa propiedad (solo medida).'],
    matriz_notas=['Cada celda: componente ×nº de controles únicos [Cumple/Incumple/ND]. Excluye la barra superior/lateral (ver fila «Estructura compartida» en el resumen).'],
    escalabilidad_notas=['Consumidores: módulos donde se midió el componente; «Sitios JSX» cuenta las etiquetas <Componente> halladas en el código fuente (estático).'],
    incidencias_notas=['Sin correcciones aplicadas: esta fase solo audita.'],
    empresas_notas=['Referencia = commit a2b857e (primera aparición de roles.json en Git) renderizado en un servidor aparte; su firma coincide con roles.json en los 6 anchos. Las capturas son de página completa (captureBeyondViewport). No hay capturas históricas de la línea base: la línea base es una medición, no imágenes.', 'Rutas de imágenes relativas a la carpeta del Excel.'],
    pendientes_notas=['Estados que no se pudieron alcanzar se declaran NO VERIFICADO; no se infieren como correctos.'],
)
json.dump(META, open(SC + r'\au\meta.json', 'w', encoding='utf8'), ensure_ascii=False)
