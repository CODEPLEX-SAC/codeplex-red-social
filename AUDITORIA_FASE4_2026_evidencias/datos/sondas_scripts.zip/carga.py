import json, collections, os, re
SC = r'C:\Users\Angie\AppData\Local\Temp\claude\c--Users-Angie-Documents-CODEPLEX-redSocial\26ddb8b9-2d82-47e0-88ed-6b3b0a3f39fd\scratchpad'
A = SC + r'\h\aud'


def jsonl(p):
    out = []
    if not os.path.exists(p):
        return out
    for l in open(p, encoding='utf8'):
        l = l.strip()
        if l:
            out.append(json.loads(l))
    return out


def cargar():
    base = jsonl(A + r'\base\base.jsonl')
    e1280 = jsonl(A + r'\e1280\estado.jsonl')
    e400 = jsonl(A + r'\e400\estado.jsonl')
    shell = jsonl(A + r'\shell\estado.jsonl')
    return base, e1280, e400, shell


SAFE = re.compile(r'^(-?m[trblxy]?-|-?mt-|flex-none$|flex-1$|flex$|shrink-0$|grow$|self-|justify-|items-|w-full$|min-w-0$|max-w-|col-span|order-|ml-auto$|mr-auto$|mx-auto$|hidden$|block$|inline|sm:|md:|lg:|max-\d+:(m|flex|hidden|w-full|order|self|col)|disabled:|hover:no-underline$|aria-|focus-visible:)')


def tokens_locales(cn):
    if not cn:
        return [], []
    seguros, visuales = [], []
    for t in cn.split():
        (seguros if SAFE.match(t) else visuales).append(t)
    return seguros, visuales
