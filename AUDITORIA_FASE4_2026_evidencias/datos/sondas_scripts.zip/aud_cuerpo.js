(() => {
  const NUESTROS = new Set(['Boton', 'BotonIcono', 'BotonPieLista', 'Selector', 'SelectorBuscable', 'SelectorFecha', 'SelectorHora', 'CampoTexto', 'CampoBusqueda', 'CampoNumero', 'CampoEtiquetado', 'Casilla', 'Radio', 'Interruptor', 'Acordeon', 'Pestanas', 'Menu', 'Modal', 'Paginacion', 'PanelSelectorBuscable', 'ListaOpcionesBuscables'])
  const PROPS = ['variant', 'size', 'activo', 'className', 'tamano', 'multilinea', 'filasMinimas', 'type', 'anchoCompleto', 'label', 'etiqueta', 'placeholder', 'marcador', 'orientacion']
  const fib = (e) => { const k = Object.keys(e).find((x) => x.startsWith('__reactFiber$')); return k ? e[k] : null }
  const nombreTipo = (t) => {
    if (!t) return null
    if (typeof t === 'function') return t.displayName || t.name || null
    if (typeof t === 'object') return t.displayName || t.render?.displayName || t.render?.name || t.type?.displayName || t.type?.name || null
    return null
  }
  const archivoDe = (f) => {
    const st = f && f._debugStack && f._debugStack.stack
    if (!st) return null
    for (const l of st.split(String.fromCharCode(10))) { const m = l.match(/redsocial\/frontend\/([^?:)]+\.tsx?)/); if (m) return m[1] }
    return null
  }
  const propietarios = (f) => {
    const out = []; let o = f && f._debugOwner; let n = 0
    while (o && n < 5) { const nm = nombreTipo(o.type); if (nm) out.push(nm); o = o._debugOwner; n++ }
    return out
  }
  const cadena = (e) => {
    let f = fib(e)
    const nombres = []
    const envolturas = []
    let n = 0
    while (f && n < 60) {
      const t = f.type
      if (typeof t !== 'string') {
        const nm = nombreTipo(t)
        if (nm && !/^(Anonymous|Context|Provider|Consumer)/.test(nm)) {
          if (!nombres.length || nombres[nombres.length - 1] !== nm) nombres.push(nm)
          if (NUESTROS.has(nm) && f.memoizedProps) {
            const p = {}
            for (const k of PROPS) {
              const v = f.memoizedProps[k]
              if (v === undefined) continue
              p[k] = typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean' ? v : typeof v === 'object' ? '[objeto]' : '[' + typeof v + ']'
            }
            if (f.memoizedProps.sx) p.sx = 'si'
            envolturas.push({ nombre: nm, props: p, archivo: archivoDe(f), duenos: propietarios(f) })
          }
        }
      }
      f = f.return
      n++
    }
    const f0 = fib(e)
    return { nombres: nombres.slice(0, 22), envolturas, archivoHost: archivoDe(f0), duenosHost: propietarios(f0) }
  }
  const visible = (e) => {
    const r = e.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return false
    const cs = getComputedStyle(e)
    return cs.visibility !== 'hidden' && cs.display !== 'none'
  }
  const px = (v) => Math.round(parseFloat(v) * 100) / 100
  const nombreAccesible = (e) => {
    const al = e.getAttribute('aria-label')
    if (al) return { n: al, f: 'aria-label' }
    const lb = e.getAttribute('aria-labelledby')
    if (lb) {
      const t = lb.split(/\s+/).map((i) => document.getElementById(i)?.textContent?.trim() ?? '').join(' ').trim()
      if (t) return { n: t, f: 'aria-labelledby' }
    }
    if (e.labels && e.labels.length) { const t = [...e.labels].map((l) => l.textContent.trim()).join(' ').trim(); if (t) return { n: t, f: 'label' } }
    const wl = e.closest('label')
    if (wl) { const t = wl.textContent.trim(); if (t) return { n: t, f: 'label-envolvente' } }
    const t = (e.textContent || '').replace(/\s+/g, ' ').trim()
    if (t) return { n: t, f: 'contenido' }
    const tt = e.getAttribute('title')
    if (tt) return { n: tt, f: 'title' }
    const ph = e.getAttribute('placeholder')
    if (ph) return { n: ph, f: 'placeholder' }
    const img = e.querySelector('img[alt]')
    if (img && img.alt) return { n: img.alt, f: 'alt' }
    return { n: '', f: 'ninguno' }
  }
  const iconos = (e) => {
    const out = []
    e.querySelectorAll('svg, .material-symbols-rounded, .icono, i').forEach((s) => {
      if (s.closest('svg') && s.tagName !== 'svg' && s.closest('svg') !== s) return
      const r = s.getBoundingClientRect()
      if (r.width && r.height) out.push({ w: px(r.width), h: px(r.height), fs: px(getComputedStyle(s).fontSize) })
    })
    return out
  }
  const SEL = 'button, a[href], [role=button], [role=tab], [role=combobox], [role=switch], [role=checkbox], [role=radio], [role=menuitem], input, textarea, select, [contenteditable=true]'
  const todos = [...document.querySelectorAll(SEL)]
  const enSet = new Set(todos)
  const controles = []
  const pickersVistos = new Set()
  for (const e of todos) {
    if (!visible(e)) continue
    if (e.tagName === 'INPUT' && e.type === 'hidden') continue
    if (e.getAttribute('aria-hidden') === 'true' && e.tagName === 'INPUT') continue
    if (e.tagName === 'INPUT' && e.classList.contains('MuiSelect-nativeInput')) continue
    const pk = e.closest('.MuiPickersInputBase-root, .MuiPickersTextField-root')
    if (pk) { if (pickersVistos.has(pk)) continue; pickersVistos.add(pk) }
    const anidado = e.parentElement ? e.parentElement.closest(SEL) : null
    let padre = anidado && enSet.has(anidado) ? anidado : null
    if (padre && e.tagName === 'INPUT' && (padre.tagName === 'LABEL')) padre = null
    const tag = e.tagName.toLowerCase()
    const rol = e.getAttribute('role')
    let tipo = 'boton'
    if (tag === 'a') tipo = 'enlace'
    if (rol === 'tab') tipo = 'pestana'
    if (rol === 'menuitem') tipo = 'item_menu'
    if (rol === 'combobox' || tag === 'select') tipo = 'selector'
    if (rol === 'switch') tipo = 'interruptor'
    if (tag === 'input') {
      const t = e.type
      tipo = t === 'checkbox' ? 'casilla' : t === 'radio' ? 'radio' : t === 'file' ? 'archivo' : t === 'range' ? 'rango' : t === 'search' ? 'busqueda' : 'campo'
      if (t === 'number') tipo = 'campo_numero'
      if (t === 'date' || t === 'time') tipo = 'campo_fecha'
      if (e.closest('.MuiPickersInputBase-root, .MuiPickersTextField-root')) tipo = 'campo_fecha'
    }
    if (tag === 'textarea') tipo = 'campo_multilinea'
    if (e.closest('.MuiSwitch-root') && tag === 'input') tipo = 'interruptor'
    if (pk) tipo = 'campo_fecha'
    const envolturas = cadena(e)
    const raiz = pk ? (pk.closest('.MuiPickersInputBase-root') || pk) : e.closest('.MuiInputBase-root, .MuiPickersInputBase-root, .MuiSelect-root') && ['campo', 'campo_numero', 'campo_fecha', 'campo_multilinea', 'busqueda', 'selector'].includes(tipo)
      ? e.closest('.MuiInputBase-root, .MuiPickersInputBase-root') || e
      : e
    const r = raiz.getBoundingClientRect()
    const cs = getComputedStyle(raiz)
    const ci = raiz === e ? cs : getComputedStyle(e)
    const nom = pk ? { n: [...pk.querySelectorAll('[aria-label]')].some((x) => /hour|minute/i.test(x.getAttribute('aria-label'))) ? 'Selector de hora' : 'Selector de fecha', f: 'raiz-picker' } : nombreAccesible(e)
    const dentroMain = !!e.closest('main')
    const overlay = e.closest('[role=dialog], .MuiPopover-root, .MuiPopper-root, .MuiMenu-root, [role=listbox], [role=menu], [aria-modal=true]')
    const region = overlay ? 'superposicion' : dentroMain ? 'pagina' : e.closest('header') ? 'barra_superior' : e.closest('aside, nav') ? 'barra_lateral' : 'estructura'
    const iconosE = iconos(e)
    const h = (x) => (x && x.length > 0 ? x : null)
    controles.push({
      tipo, tag, rol, region,
      cadena: envolturas.nombres, envolturas: envolturas.envolturas, archivoHost: envolturas.archivoHost, duenosHost: envolturas.duenosHost,
      anidadoEn: padre ? padre.tagName.toLowerCase() + (padre.getAttribute('role') ? '[' + padre.getAttribute('role') + ']' : '') : null,
      nombre: nom.n.slice(0, 80), nombreFuente: nom.f,
      tipoInput: tag === 'input' ? e.type : null,
      placeholder: e.getAttribute('placeholder') || null,
      deshabilitado: e.disabled === true || e.getAttribute('aria-disabled') === 'true',
      ariaExpanded: e.getAttribute('aria-expanded'), ariaHaspopup: e.getAttribute('aria-haspopup'), ariaControls: e.getAttribute('aria-controls'),
      ariaPressed: e.getAttribute('aria-pressed'), ariaSelected: e.getAttribute('aria-selected'), ariaInvalid: e.getAttribute('aria-invalid'),
      href: tag === 'a' ? e.getAttribute('href') : null,
      libMui: !!(raiz.closest('[class*=Mui]') || /Mui/.test(typeof e.className === 'string' ? e.className : '')),
      clases: (typeof raiz.className === 'string' ? raiz.className : '').slice(0, 400),
      claseHost: (typeof e.className === 'string' ? e.className : '').slice(0, 200),
      x: px(r.x), y: px(r.y + scrollY), w: px(r.width), h: px(r.height),
      minH: cs.minHeight, alturaCss: cs.height,
      pad: [px(cs.paddingTop), px(cs.paddingRight), px(cs.paddingBottom), px(cs.paddingLeft)],
      padInterno: raiz === e ? null : [px(ci.paddingTop), px(ci.paddingRight), px(ci.paddingBottom), px(ci.paddingLeft)],
      borde: px(cs.borderTopWidth), bordeColor: cs.borderTopColor, radio: cs.borderTopLeftRadius,
      fuente: px(ci.fontSize), peso: ci.fontWeight, lh: ci.lineHeight === 'normal' ? 'normal' : px(ci.lineHeight),
      color: ci.color, fondo: cs.backgroundColor, gap: cs.columnGap, display: cs.display,
      iconos: h(iconosE), tieneTexto: !!(e.textContent || '').trim(),
      sombraFoco: null,
      anchoAuto: cs.width,
    })
  }
  // paneles abiertos
  const paneles = []
  document.querySelectorAll('.MuiPopover-paper, .MuiPopper-root > *, .MuiMenu-paper, .MuiDialog-paper, [role=dialog], [role=listbox], [id^=panel-]').forEach((p) => {
    if (!visible(p)) return
    const r = p.getBoundingClientRect()
    const cs = getComputedStyle(p)
    const item = p.querySelector('[role=option], [role=menuitem], li')
    const ci = item ? getComputedStyle(item) : null
    const it = item ? item.getBoundingClientRect() : null
    paneles.push({
      rol: p.getAttribute('role'), clase: (typeof p.className === 'string' ? p.className : '').slice(0, 160),
      cadena: cadena(p).nombres.slice(0, 8),
      w: px(r.width), h: px(r.height), radio: cs.borderTopLeftRadius, pad: [px(cs.paddingTop), px(cs.paddingRight), px(cs.paddingBottom), px(cs.paddingLeft)],
      fondo: cs.backgroundColor, sombra: cs.boxShadow.slice(0, 80), borde: cs.borderTopWidth,
      items: p.querySelectorAll('[role=option], [role=menuitem]').length,
      itemH: it ? px(it.height) : null, itemFuente: ci ? px(ci.fontSize) : null, itemPad: ci ? [px(ci.paddingTop), px(ci.paddingRight), px(ci.paddingBottom), px(ci.paddingLeft)] : null,
      ancla: p.getAttribute('aria-label') || p.getAttribute('aria-labelledby') || null,
    })
  })
  const ancho = document.documentElement.scrollWidth
  return { url: location.pathname, ancho, vw: innerWidth, desborde: ancho > innerWidth + 1, controles, paneles, titulo: document.querySelector('main h1')?.textContent?.trim() ?? null }
})()
