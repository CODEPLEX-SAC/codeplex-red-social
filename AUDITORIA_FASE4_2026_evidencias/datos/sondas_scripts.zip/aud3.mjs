import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const PUERTO = process.env.AUD_PORT || 9381
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${PUERTO}`, `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch(`http://127.0.0.1:${PUERTO}/json`)).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

import { readFileSync as leer, appendFileSync as anexar } from 'node:fs'
const SC = process.argv[4]
const VPS = process.argv[5].split(',').map((v) => v.split('x').map(Number))
const FN = leer(SC + '/h/aud_cuerpo.js', 'utf8')
const CAND = leer(SC + '/h/aud_cand.js', 'utf8')
const RUTAS = JSON.parse(leer(SC + '/f3/rutas.json', 'utf8')).filter((r) => !/^\/no-encontrada/.test(r))
const OUT = SALIDA + '/estado.jsonl'
const guardar = (o) => anexar(OUT, JSON.stringify(o) + '\n')
const claveC = (c) => [c.region, c.tipo, c.cadena.slice(0, 4).join('>'), c.nombre].join('|')
const listo = async () => {
  await dormir(900)
  let previo = -1, estable = 0
  for (let i = 0; i < 60; i++) {
    const n = await evalJS(`document.querySelectorAll('button, a, input, textarea, [role]').length + ':' + document.body.innerText.length`)
    const cuenta = parseInt(String(n).split(':')[0], 10)
    if (n === previo && cuenta >= 4) { estable++; if (estable >= 3) break } else { estable = 0; previo = n }
    await dormir(400)
  }
}
const ERRORES = `(() => [...document.querySelectorAll('[aria-invalid=true], .Mui-error, [role=alert]')].filter((e) => e.getBoundingClientRect().width > 0).map((e) => ({ tag: e.tagName.toLowerCase(), clase: String(e.className).slice(0, 80), texto: (e.textContent || '').trim().slice(0, 80), ariaInvalid: e.getAttribute('aria-invalid'), rol: e.getAttribute('role') })))()`
await cdp('Page.enable')
for (const [w, h] of VPS) {
  await viewport(w, h, w <= 480)
  for (const ruta of RUTAS) {
    await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta }); await listo()
    const base = await evalJS(FN)
    if (typeof base === 'string') continue
    const claves = new Set(base.controles.map(claveC))
    // 1) búsqueda sin resultados
    const bus = await evalJS(`(() => [...document.querySelectorAll('main input')].filter((e) => (e.type === 'search' || /buscar/i.test(e.placeholder || '')) && e.getBoundingClientRect().width > 0).slice(0, 2).map((e, i) => { const r = e.getBoundingClientRect(); return { i, x: r.x + r.width / 2, y: r.y + r.height / 2, ph: e.placeholder } }))()`)
    if (Array.isArray(bus)) {
      for (const b of bus) {
        await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta }); await listo()
        const p = await evalJS(`(() => { const e = [...document.querySelectorAll('main input')].filter((e) => (e.type === 'search' || /buscar/i.test(e.placeholder || '')) && e.getBoundingClientRect().width > 0)[${b.i}]; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 } })()`)
        if (!p) continue
        await clicXY(p.x, p.y); await escribir('zzqxzzq'); await dormir(900)
        const st = await evalJS(FN)
        const vacio = await evalJS(`/no se encontr|sin resultados|no hay|no tienes|no existen/i.test(document.querySelector('main')?.innerText || '')`)
        if (typeof st === 'string') continue
        guardar({ modo: 'estado', etiqueta: `Búsqueda sin resultados («${b.ph}»)`, ruta, w, disparador: { n: b.ph, rol: 'search' }, urlTras: st.url, cambioUrl: st.url !== ruta, nuevos: st.controles.filter((x) => !claves.has(claveC(x))), paneles: st.paneles, desborde: st.desborde, vacio })
      }
    }
    // 2) formularios en diálogo: abrir y enviar vacío
    await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta }); await listo()
    await evalJS(CAND)
    const abridores = (await evalJS(`window.__aud.lista('pagina')`)).filter((c) => c.rol === 'button' && /nuev|crear|agreg|invitar|a.adir|registrar|publicar/i.test(c.n)).slice(0, 3)
    for (const ab of abridores) {
      await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta }); await listo(); await evalJS(CAND)
      const p = await evalJS(`window.__aud.pos(${JSON.stringify(ab.n)}, 'button', 'pagina')`)
      if (!p) continue
      await clicXY(p.x, p.y); await dormir(700)
      const hay = await evalJS(`!!document.querySelector('[role=dialog]')`)
      if (!hay) continue
      const env = await evalJS(`(() => { const d = document.querySelector('[role=dialog]'); const b = [...d.querySelectorAll('button')].reverse().find((x) => /guardar|crear|agregar|enviar|invitar|publicar|registrar|siguiente|continuar/i.test(x.textContent) && !x.disabled && x.getBoundingClientRect().width > 0); if (!b) return null; b.scrollIntoView({block:'center'}); const r = b.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2, t: b.textContent.trim().slice(0, 30) } })()`)
      if (!env) continue
      await clicXY(env.x, env.y); await dormir(800)
      const errs = await evalJS(ERRORES)
      const st = await evalJS(FN)
      if (typeof st === 'string') continue
      guardar({ modo: 'estado', etiqueta: `Formulario «${ab.n.replace(/[a-z]+_[a-z_]+/g, '').trim()}» enviado vacío (${env.t})`, ruta, w, disparador: { n: ab.n, rol: 'form' }, urlTras: st.url, cambioUrl: st.url !== ruta, nuevos: st.controles.filter((x) => !claves.has(claveC(x))), paneles: st.paneles, desborde: st.desborde, errores: errs })
    }
  }
}
ws.close(); chrome.kill(); process.exit(0)
