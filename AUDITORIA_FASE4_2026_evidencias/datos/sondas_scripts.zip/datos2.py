import collections
from datos import *


def px_num(s):
    try:
        return float(str(s).replace('px', '').split()[0])
    except Exception:
        return None


def rango_txt(xs):
    xs = [x for x in xs if x is not None]
    if not xs:
        return '—'
    lo, hi = min(xs), max(xs)
    return f'{lo:g}' if abs(lo - hi) < 0.05 else f'{lo:g}–{hi:g}'


def contrato_boton(size, w):
    movil = w < 600
    size = size or 'default'
    tab = {
        'md': dict(alt=('min', 48), padH=13 if movil else 18, radio=7 if movil else 8, icono=16, fuente=(14, 600), gap=8),
        'cta': dict(alt=('min', 40), padH=13 if movil else 18, radio=7 if movil else 8, icono=16, fuente=(14, 600), gap=8),
        'default': dict(alt=('min', 30 if movil else 34), padH=10 if movil else 13, radio=7, icono=16, fuente=(14, 600), gap=8),
        'mini': dict(alt=('min', 30), padH=10, radio=7, icono=14, fuente=(12, 600), gap=8),
        'filtro': dict(alt=('exacta', 32), padH=12, radio=8, icono=14, fuente=(14, 500), gap=8),
        'enlace': dict(alt=None, padH=None, radio=None, icono=None, fuente=(14, 600), gap=8),
        'enlace_accion': dict(alt=None, padH=None, radio=None, icono=None, fuente=(12, 600), gap=8),
        'pie_lista': dict(alt=None, padH=14, radio=0, icono=16, fuente=(14, 600), gap=8),
    }
    return tab.get(size)


def contrato_boton_icono(size, w, var):
    movil = w < 600
    size = size or 'default'
    rad = {'default': 7, 'primario': 7, 'suave': 7, 'discreto': 9999, 'sobre_oscuro': 9999, 'contorno': 8, 'sutil': 6, 'flotante': 9999}.get(var or 'default')
    tab = {'default': dict(caja=28 if movil else 32, icono=16 if movil else 18), 'sm': dict(caja=24, icono=14), 'md': dict(caja=28, icono=14)}
    d = tab.get(size)
    return dict(d, radio=rad) if d else None


WRAP_DIM = ('Boton', 'BotonIcono', 'Selector', 'SelectorBuscable', 'SelectorFecha', 'SelectorHora', 'CampoTexto', 'CampoBusqueda', 'CampoNumero', 'Pestanas', 'Casilla', 'Radio', 'Interruptor', 'Paginacion', 'Menu')


def contrato(wr, fam, var, size, clave, w):
    if wr == 'Boton':
        c = contrato_boton(size, w)
        return c.get({'h': 'alt'}.get(clave, clave)) if c else None
    if wr == 'BotonIcono':
        c = contrato_boton_icono(size, w, var)
        if not c:
            return None
        if clave in ('h', 'w'):
            return ('exacta', c['caja'])
        return c.get(clave)
    if wr in ('CampoTexto', 'CampoBusqueda', 'CampoNumero', 'SelectorFecha', 'SelectorHora') and clave == 'h' and fam != 'Caja de texto multilínea':
        return ('min', 48)
    if wr == 'Selector' and clave == 'h' and (var or 'default') in ('default', 'colaboradores'):
        return ('min', 48)
    if wr == 'SelectorBuscable' and clave == 'h':
        return ('exacta', 48)
    if wr == 'Pestanas' and clave == 'h':
        return ('min', 40)
    if wr == 'clasesChip':
        return {'h': ('exacta', 32), 'padH': 14, 'radio': 20}.get(clave)
    if wr == 'clasesBoton' and clave == 'h':
        return ('uno_de', (30, 34, 40, 48))
    return None


def texto_ctr(wr, size, clave, ct):
    if ct is None:
        return None
    if isinstance(ct, tuple) and ct[0] in ('min', 'exacta', 'uno_de'):
        t = texto_contrato(ct)
        if wr == 'Boton' and clave == 'h' and (size or 'default') == 'default':
            t = 'mín. 34 px (≥600) / 30 px (<600)'
        if wr == 'BotonIcono' and size in (None, 'default') and clave in ('h', 'w'):
            t = '32 px (≥600) / 28 px (<600)'
        return t
    if isinstance(ct, tuple):
        return f'{ct[0]} px / peso {ct[1]}'
    t = f'{ct:g} px'
    if wr == 'Boton' and clave == 'padH' and size in ('md', 'cta'):
        t = '18 px (≥600) / 13 px (<600)'
    if wr == 'Boton' and clave == 'padH' and (size or 'default') == 'default':
        t = '13 px (≥600) / 10 px (<600)'
    if wr == 'Boton' and clave == 'radio' and size in ('md', 'cta'):
        t = '8 px (≥600) / 7 px (<600)'
    if wr == 'BotonIcono' and clave == 'icono' and size in (None, 'default'):
        t = '18 px (≥600) / 16 px (<600)'
    return t


PROPS = (('h', 'Altura exterior'), ('w', 'Ancho efectivo'), ('padH', 'Padding horizontal'), ('icono', 'Tamaño de icono'), ('gap', 'Separación icono–texto'), ('fuente', 'Tipografía (tamaño/peso)'), ('radio', 'Radio de borde'))


def tam_icono(v):
    ic = v['iconos'] or []
    if not ic:
        return None
    w = ic[0]
    fs = (v.get('icfs') or [None])[0]
    if fs and abs(w - fs * 1.1) < 0.4:
        return fs
    return w


def construir_dimensiones():
    claves = collections.defaultdict(list)
    for g in FINAL:
        wr = g['wrapper']
        if g['ev']['clase'].startswith('Parte interna'):
            continue
        if wr in WRAP_DIM:
            claves[(g['fam'], wr, (g['var'] or ('default' if wr in ('BotonIcono', 'Selector') else None)) if wr in ('Boton', 'BotonIcono', 'Selector') else None, (g['size'] or 'default') if wr in ('Boton', 'BotonIcono') else None)].append(g)
        elif g['nat'] == 'chip':
            claves[('Chip de filtro (enlace)', 'clasesChip', None, None)].append(g)
        elif g['nat'] == 'boton':
            claves[('Enlace con apariencia de botón', 'clasesBoton', None, None)].append(g)
    filas = []
    for (fam, wr, var, size), gs in sorted(claves.items(), key=lambda x: (x[0][0], x[0][1], str(x[0][2]), str(x[0][3]))):
        def vals(w):
            return [g['por_vp'][w] for g in gs if g['por_vp'].get(w, {}).get('estado') == 'MEDIDO']

        if wr == 'Boton':
            etiqueta = f'Boton · {var or "sin variante"} · tamaño {size or "default"}'
        elif wr == 'BotonIcono':
            etiqueta = f'BotonIcono · {var or "default"} · tamaño {size or "default"}'
        elif wr == 'Selector':
            etiqueta = f'Selector · variante {var or "default"}'
        else:
            etiqueta = wr
        n_inst = sum(max([v.get('n', 0) for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'] or [0]) for g in gs)
        cons = sorted({g['cons'] for g in gs})

        def celda(w, clave):
            vs = vals(w)
            if not vs:
                est = [g['por_vp'].get(w, {}).get('estado', 'NO VERIFICADO') for g in gs]
                return 'NO VISIBLE' if 'NO VISIBLE' in est else 'NO VERIFICADO'
            if clave == 'h':
                return rango_txt([v['hmin'] for v in vs] + [v['hmax'] for v in vs])
            if clave == 'w':
                return rango_txt([px_num(v['w'].split('–')[0]) for v in vs] + [px_num(v['w'].split('–')[-1]) for v in vs])
            if clave == 'padH':
                return rango_txt([v['pad'][3] for v in vs if v['pad']] + [v['pad'][1] for v in vs if v['pad']])
            if clave == 'radio':
                t = rango_txt([px_num(v['radio']) for v in vs if v['radio']])
                return t.replace('33554400', 'completo').replace('3.35544e+07', 'completo')
            if clave == 'fuente':
                return ' / '.join(sorted({f"{v['fuente']:g}px {v['peso']}" for v in vs if v['fuente'] is not None}))
            if clave == 'icono':
                return rango_txt([tam_icono(v) for v in vs if v['iconos']])
            if clave == 'gap':
                return rango_txt([px_num(v['gap']) for v in vs if v['gap'] and v['gap'] != 'normal'])
            return '—'

        for clave, nombre in PROPS:
            celdas = {w: celda(w, clave) for w in VP}
            ctr = {w: contrato(wr, fam, var, size, clave, w) for w in VP}
            ct0 = next((v for v in ctr.values() if v is not None), None)
            ctr_txt = texto_ctr(wr, size, clave, ct0)
            oks = []
            for w in VP:
                vs = vals(w)
                c = ctr[w]
                if not vs or c is None:
                    continue
                if clave == 'h':
                    lo = min(v['hmin'] for v in vs)
                    hi = max(v['hmax'] for v in vs)
                    if c[0] == 'min':
                        oks.append(lo + 0.6 >= c[1])
                    elif c[0] == 'exacta':
                        oks.append(abs(lo - c[1]) <= 0.6 and abs(hi - c[1]) <= 0.6)
                    else:
                        oks.append(all(any(abs(x - y) <= 0.6 for y in c[1]) for x in (lo, hi)))
                elif clave == 'w':
                    oks.append(all(abs(px_num(v['w'].split('–')[0]) - c[1]) <= 0.6 and abs(px_num(v['w'].split('–')[-1]) - c[1]) <= 0.6 for v in vs))
                elif clave == 'fuente':
                    oks.append(all(v['fuente'] is not None and abs(v['fuente'] - c[0]) <= 0.1 and str(v['peso']) == str(c[1]) for v in vs))
                elif clave == 'padH':
                    xs = [v['pad'][3] for v in vs if v['pad']]
                    if xs:
                        oks.append(all(abs(x - c) <= 0.6 for x in xs))
                elif clave == 'radio':
                    xs = [px_num(v['radio']) for v in vs if v['radio']]
                    if xs:
                        oks.append(all((abs(x - c) <= 0.6) or (c >= 9999 and x >= 20) for x in xs))
                elif clave == 'icono':
                    xs = [tam_icono(v) for v in vs if v['iconos']]
                    if xs:
                        oks.append(all(abs(x - c) <= 1.6 for x in xs))
                elif clave == 'gap':
                    xs = [px_num(v['gap']) for v in vs if v['gap'] and v['gap'] != 'normal']
                    if xs:
                        oks.append(all(abs(x - c) <= 0.6 for x in xs))
            hay_medida = any(celdas[w] not in ('NO VISIBLE', 'NO VERIFICADO') for w in VP)
            if not hay_medida:
                estado = 'NO VERIFICADO'
            elif ctr_txt is None:
                estado = 'NO DETERMINADO'
            elif oks and all(oks):
                estado = 'CUMPLE'
            elif oks:
                estado = 'INCUMPLE'
            else:
                estado = 'NO DETERMINADO'
            filas.append(dict(familia=fam, variante=etiqueta, propiedad=nombre, contractual=ctr_txt or 'sin valor contractual explícito en el código',
                              fuente_contrato=(('compartido.json: boton_tamanos / boton_medio / boton_icono_por_tamano / boton_icono_tamanos' if wr in ('Boton', 'BotonIcono') else 'compartido.json: controles / selector_libreria / selector_buscable / pestanas_tema / chip_filtro') if ctr_txt else '—'),
                              v1280=celdas[1280], v820=celdas[820], v400=celdas[400], v320=celdas[320], instancias=n_inst,
                              consumidores=', '.join(cons[:6]) + (f' (+{len(cons) - 6})' if len(cons) > 6 else ''), origen='navegador: getBoundingClientRect / getComputedStyle', estado=estado))
    return filas


if __name__ == '__main__':
    inv, gs = construir_inventario()
    print('inventario', len(inv))
    dm = construir_dimensiones()
    print('dimensiones', len(dm), collections.Counter(r['estado'] for r in dm))
    for r in dm:
        if r['estado'] == 'INCUMPLE':
            print(r['variante'], '|', r['propiedad'], '| ctr', r['contractual'], '|', r['v1280'], r['v820'], r['v400'], r['v320'])
