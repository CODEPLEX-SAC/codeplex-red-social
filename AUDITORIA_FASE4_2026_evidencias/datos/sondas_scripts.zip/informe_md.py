import json, collections, re, os, sys
from informe import *

BANNER = json.load(open(SC + r'\au\banner\banner.json', encoding='utf8'))
H = lambda g, w: g['por_vp'].get(w, {}).get('h') if g['por_vp'].get(w, {}).get('estado') == 'MEDIDO' else g['por_vp'].get(w, {}).get('estado', 'NO VERIFICADO')
fam_orden = ['Botón', 'Botón con icono', 'Selector / desplegable', 'Opción de panel de selector buscable', 'Selector de fecha/hora', 'Campo de texto', 'Buscador', 'Campo numérico', 'Caja de texto multilínea', 'Casilla', 'Radio', 'Interruptor', 'Pestaña', 'Paginación', 'Ítem de menú', 'Enlace con apariencia de botón', 'Chip de filtro (enlace)', 'Enlace de texto']


def filas_ruta(rutas, excluir_estructura=True):
    out = []
    for g in sorted(FINAL, key=lambda g: (g['fam'], g['cons'], g['nombre'])):
        if excluir_estructura and g['scope'] == ESTRUCTURA:
            continue
        if any(r in rutas for r in g['rutas']):
            out.append(g)
    return out


def tabla_controles(gs, limite=60):
    filas = []
    for g in gs[:limite]:
        filas.append([g['fam'], g['nombre'][:34], (g['wr'] or ('<' + g['tag'] + '>' if not g['libMui'] else 'MUI')), (g['var'] or '—') + ' / ' + (g['size'] or '—'), g['cons'], H(g, 1280), H(g, 820), H(g, 400), H(g, 320), g['ev']['resultado']])
    return tabla(['Familia', 'Control', 'Componente', 'Variante / tamaño', 'Consumidor', 'h 1280', 'h 820', 'h 400', 'h 320', 'Resultado'], filas)


md = []
A_ = md.append
A_(f'# Auditoría exhaustiva del diseño compartido — CodePlex Red Social (Fase 4)\n')
A_(f'**Fecha:** {fecha} · **Rama:** `codeplexMaster` · **Modo:** solo lectura (sin modificar componentes, estilos, tokens, configuración ni dependencias; sin commits ni pushes; línea base y `roles.json` intactos).\n')
A_(f'**Archivos hermanos (describen los mismos resultados):** [{NOMBRE}.xlsx]({NOMBRE}.xlsx) · [{NOMBRE}_inventario.md]({NOMBRE}_inventario.md) · [{EVID}/]({EVID}/)\n')

n_pseudo = len(sitios_pseudo())
# ------------------------------------------------------------------ 1 resumen
A_('## 1. Resumen ejecutivo\n')
n_rutas_4 = sum(1 for r in RUTAS_APP if len({w for (rr, w, e) in visitas if rr == r and e == "Base"}) >= 4)
A_(f'- **Cobertura:** {len(RUTAS_APP)} rutas registradas (más `/no-encontrada`, no inventariada); {n_rutas_4} medidas en los 4 viewports (1280, 820, 400, 320 px). {n_estados} estados alcanzados por interacción real (clic en cada pestaña, filtro, selector, botón y, en modales/paneles, un segundo nivel), a 1280 y 400 px. {format(instancias_total, ",").replace(",", ".")} observaciones de controles interactivos agrupadas en **{len(inv)} controles únicos**.')
A_(f'- **Resultado por control único:** CUMPLE {res_c.get("CUMPLE", 0)} · INCUMPLE {res_c.get("INCUMPLE", 0)} · NO DETERMINADO {res_c.get("NO DETERMINADO", 0)} · NO VERIFICADO {res_c.get("NO VERIFICADO", 0)}. Reutilización: {reut_c["A"]} usan un wrapper compartido (A), {reut_c["B"]} consumen la configuración compartida desde un componente propio (B), {reut_c["C"]} son patrones propios paralelos o sin clasificar (C), {reut_c["D"]} son librería directa (D) y {reut_c["E"]} nativos con excepción registrada (E).')
A_(f'- **Veredicto dimensional:** el sistema compartido **cumple su propio contrato** en las alturas de `Boton` (md 48, cta 40, default 34/30, mini 30, filtro 32), `BotonIcono` (32/28, 24, 28), `Selector`/`CampoTexto`/`CampoBusqueda`/`CampoNumero`/`SelectorFecha`/`SelectorHora` (48), `SelectorBuscable` (48), `Pestanas` (≥40) y chips (32) en todos los viewports en que cada control es visible (p. ej. el selector de empresa solo se muestra a 1280 px). Las pocas filas dimensionales que no cumplen (radio de `filtro mini` y de `BotonIcono discreto md` por sobrescritura local, padding de los chips de Mensajes) son sobrescrituras de consumidor; el resto de incidencias no son de altura sino de **uso del patrón**: controles que parecen un componente compartido sin serlo, sobrescrituras locales y patrones duplicados.')
A_(f'- **Hallazgos principales** (detalle en §8): (INC-01) {n_pseudo} «desplegables» de Actividad, Amigos y Grupos son `Boton secundario` + chevron que **no abren nada**, mientras la misma función «Más recientes» usa `Selector mini` en Guardados y Notificaciones; (INC-02) el panel de **Ubicación** de Eventos **desborda a 820 px**; (INC-03) el botón de menú solapa 28 px el buscador entre 801 y 900 px; (INC-04) el **foco** de los campos es distinto entre familias y usa #7c3aed, no el token de foco #5a43f4; (INC-05/06) el filtro desplegable de Eventos está repetido cuatro veces y Categoría no devuelve su selección; (INC-07) el banner informativo está copiado cuatro veces con medidas distintas.')
A_('- **Regresión Empresas:** las 6 «páginas» son `/empresas` en 6 anchos y la línea base es una **medición**, no capturas. La versión de referencia (commit `a2b857e`, renderizada aparte) reproduce la firma de `roles.json` en los 6 anchos, de modo que todas las diferencias son atribuibles. Resultado: diferencias **intencionales y ya aprobadas** (campos/botones 48 px, selector de empresa, carrito) más **dos cambios no registrados** con causa demostrada (tipografía MUI heredada y altura de la barra superior 64→72 px). **No se confirma ningún defecto visual**; sí hay que decidir si se aceptan esos dos cambios.')
A_('- **Qué centralizar** (sin decisión de diseño): wrapper de filtro desplegable, banner informativo, variantes de `BotonIcono` (sobre oscuro/imagen/peligro) y tamaño `enlace` compacto, pie de lista, un único estado de foco. **Qué requiere decisión:** pseudo-selectores, color primario del tema MUI, alturas de la barra superior, píldoras de Inicio, patrones especiales y la licencia de `CodeplexSelectorRangoFecha` (MUI X Pro).\n')

# ------------------------------------------------------------------ 2 cobertura
A_('## 2. Cobertura real por módulo y pestaña\n')
A_('Cada fila es un módulo; el detalle por pestaña/ruta está en la hoja «4 Matriz por módulo» del Excel. Ningún módulo se declara «completamente auditado»: ver limitaciones (§11).\n')
filas = []
for m in mods15 + ['Acceso']:
    r = res_mod[m]
    filas.append([m, r['rutas'], r['visitadas'], r['estados'], r['inventariados'], r['medidos'], r['cumple'], r['incumple'], r['nd'], r['nv']])
r = res_mod[ESTRUCTURA]
filas.append(['Estructura compartida (barra superior y lateral)', '—', '—', '—', r['inventariados'], r['medidos'], r['cumple'], r['incumple'], r['nd'], r['nv']])
r = res_mod['Compartido (componente reutilizado por varios módulos)']
filas.append(['Compartido reutilizado por varios módulos', '—', '—', '—', r['inventariados'], r['medidos'], r['cumple'], r['incumple'], r['nd'], r['nv']])
A_(tabla(['Módulo', 'Rutas', 'Visitadas', 'Estados tras clic', 'Controles únicos', 'Medidos', 'CUMPLE', 'INCUMPLE', 'NO DET.', 'NO VERIF.'], filas))
A_('\n**Rutas por módulo:** ' + '; '.join(f"{m}: " + ', '.join(f"`{r}` ({PESTANA.get(r, r)})" for r in RUTAS_APP if modulo_de(r) == m) for m in mods15 + ['Acceso']) + '.\n')
A_('**Método de recorrido.** Cada ruta se cargó en 4 viewports y se enumeraron los controles interactivos del DOM (botones, enlaces, pestañas, desplegables, casillas, radios, interruptores, campos y áreas de texto). Después, a 1280 y 400 px, se hizo clic una vez en cada pestaña, filtro, selector, interruptor y botón de página (excepto cerrar sesión), se midieron los controles y paneles nuevos y se restauró el estado; en modales y paneles se repitió un segundo nivel (a 1280 px) en las rutas con formularios y filtros. Además se ejecutaron sondas dedicadas: filtros de Eventos (4 viewports), foco de campos (3 formularios), banners (10 rutas), búsqueda sin resultados y envío vacío de formularios (a 1280 y 400 px) y las dos versiones de `/empresas`.\n')

# ------------------------------------------------------------------ 3 casos denunciados
A_('## 3. Casos denunciados — verificación\n')
A_('### 3.1 Actividad\n')
rut_act = ['/actividad', '/actividad/publicaciones', '/actividad/menciones', '/actividad/colaboradores', '/actividad/grupos', '/actividad/modulos', '/actividad/sistema']
gs = [g for g in filas_ruta(rut_act) if g['ctx'] == 'página' and g['fam'] not in ('Enlace de texto',)]
A_('Pestañas de Actividad: ' + ', '.join(f'**{PESTANA[r]}** (`{r}`)' for r in rut_act) + '. Los controles de la página (sin la barra superior/lateral):\n')
A_(tabla_controles([g for g in gs if g['fam'] != 'Pestaña' or True], 40))
A_('')
A_('- **«Todos los módulos»** (`/actividad/modulos`) y **«Todos los eventos»** (`/actividad/sistema`, mismo patrón) son `Boton variant="secundario" size="default"` con un chevron de Material Symbols. **No son un `Selector`**: 34 px (30 px a ≤599 px) frente a los 48 px de `Selector default` o los 40 px de `Selector mini`, sin `aria-haspopup`/`aria-expanded` y **sin ninguna acción**: el clic no añade controles ni paneles (medido a 1280 y 400 px). Coinciden en altura con el contrato de `Boton default`, pero el contrato correcto sería el de un selector (INC-01).')
A_('- **«Ver perfil»** (`/actividad/colaboradores`) es `Boton variant="contorno" size="mini"`: 30 px a 1280 y 400 px, solo `className="flex-none"` (layout), hereda variante, tamaño, radio 7 px y colores del catálogo → CUMPLE. «Ver grupo» (misma pestaña y en «Todas») usa la misma combinación.')
A_('- **Grupos:** «Crear grupo» es `Boton contorno size="cta"` (40 px) y «Ver más» es `BotonPieLista` (49 px). **Sistema:** el pseudo-selector (34 px), `BotonIcono discreto md` «Más opciones» (28 px) y «Cargar más» (`BotonPieLista`, 49 px). Cada control cumple su variante; la cabecera de pestaña usa tres tamaños distintos (30, 40 y 34 px) → INC-13 (decisión de diseño).')
A_('- Las pestañas usan `Pestanas` (`CodeplexPestanas` + MUI `Tab`): 41,5 px (contrato ≥40 px).\n')
A_('### 3.2 Notificaciones\n')
rut_not = ['/notificaciones', '/notificaciones/no-leidas', '/notificaciones/solicitudes', '/notificaciones/menciones', '/notificaciones/eventos', '/notificaciones/sistema']
gs = [g for g in filas_ruta(rut_not) if g['ctx'] == 'página' and g['fam'] not in ('Enlace de texto',) and g['cons'] != 'PaginaNoEncontrada']
A_('Pestañas: ' + ', '.join(f'**{PESTANA[r]}** (`{r}`)' for r in rut_not) + '. **«Sistema» no tiene página:** `/notificaciones/sistema` muestra la página 404 (la pestaña declara la ruta «#»), por lo que no hay controles de Sistema que auditar (NO VERIFICADO; INC-28). Controles de las otras cinco pestañas:\n')
A_(tabla_controles(gs, 45))
A_('')
bs = [x for x in BANNER if x['ruta'].startswith('/notificaciones') and x['w'] == 1280]
A_('- **Banner:** aparece solo en **Solicitudes, Menciones y Eventos** (no en «Todas», «No leídas» ni «Sistema»). Es un `div` escrito a mano (`BannerInfoAviso`): 653×99,4 px, padding 14 px, radio 12 px, icono 36 px, título 14 px; su botón de cierre sí es `BotonIcono discreto sm` (24×24 px, compartido). No existe un componente banner compartido, y otras tres copias (Grupos, Colaboradores) difieren: padding 20 px, radio 10 px, icono 44 px (INC-07).')
A_('- **Botones por tipo de notificación:** solicitudes → `Aceptar/Aprobar` (primario default) y `Rechazar/Eliminar` (secundario default); eventos → `Aceptar`, `Rechazar`, `Ver evento`; todas las pestañas → «Marcar todas como leídas» (secundario default) y `BotonIcono` «Más opciones» (contorno default 32 px y discreto sm 24 px). Todos con 34 px (30 px a ≤599 px) → CUMPLE.')
A_('- **«No leídas»** usa `Selector variant="mini"` («Mas recientes», 40 px; el catálogo no define altura para `mini`, INC-19) y casillas `Casilla` de 32 px. **Menciones** usa `Boton secundario md` (48 px) con chevron para «Cargar más notificaciones», frente a `BotonPieLista` en Actividad (INC-12).\n')
A_('### 3.3 Eventos\n')
d_ver = [g for g in FINAL if g['nombre'] == 'Ver detalles' and g['scope'] == 'Eventos']
for g in d_ver:
    A_(f"- **«Ver detalles»** (`{g['cons']}`, {g['archivo']}; rutas {', '.join(g['rutas'])}): componente real `Boton variant=\"{g['var']}\" size=\"default\"` (clasesBoton, sin `className` visual). Alto {H(g, 1280)} px a 1280 y 820 px, {H(g, 400)} px a 400 y 320 px (contrato `default`: 34 px / 30 px <600); ancho {g['por_vp'][1280]['w']} px a 1280 px y ancho completo en móvil ({g['por_vp'].get(400, {}).get('w', 'NO VISIBLE')} px a 400, {g['por_vp'].get(320, {}).get('w', 'NO VISIBLE')} px a 320) → CUMPLE.")
A_('')
fil = []
for filtro in ('Fecha', 'Categoría', 'Ubicación'):
    r1280 = next(x for x in EVT if x['w'] == 1280 and x['filtro'] == filtro)
    r820 = next(x for x in EVT if x['w'] == 820 and x['filtro'] == filtro)
    r400 = next(x for x in EVT if x['w'] == 400 and x['filtro'] == filtro)
    fil.append([filtro, f"Boton filtro/filtro · {r1280['cerrado']['w']:g}×{r1280['cerrado']['h']:g} px · aria-expanded {r1280['cerrado']['ariaExpanded']}→{r1280['abierto']['ariaExpanded']}, aria-controls `{r1280['abierto']['ariaControls']}`", f"{r1280['panel']['w']:g}×{r1280['panel']['h']:g} (absoluto, radio {r1280['panel']['radio']})", f"{r820['panel']['w']:g}×{r820['panel']['h']:g}; derecha {r820['panel']['derecha']:g} / {r820['panel']['vw']} px; desborde: {'SÍ' if r820['desborde'] else 'no'}", f"{r400['panel']['w']:g}×{r400['panel']['h']:g} (hoja inferior fixed, radio {r400['panel']['radio']})", {'Fecha': 'rangos, atajos (Hoy, Mañana, Fin de semana…), calendario, selección de día único/rango', 'Categoría': 'buscador + casillas múltiples (13 ítems); la selección no sale del panel', 'Ubicación': 'buscador, ciudades (radio), mapa Leaflet, «Mi ubicación actual»'}[filtro]])
A_(tabla(['Filtro', '1) Disparador visible', '2) Panel (1280 px)', '3) Panel a 820 px', '4) Panel a 400 px', '5) Contenido y lógica'], fil))
A_('')
A_('- **Disparador:** los tres usan el patrón compartido de filtro: `Boton variant="filtro" size="filtro"`, 32 px de alto en los 4 viewports, `activo` cuando está abierto o con valor, icono 14 px, y semántica `aria-expanded`/`aria-controls` correcta (verificada abierto/cerrado).')
A_('- **Panel y contenido:** cada panel es un componente propio (`PanelFiltroFecha`, `PanelFiltroCategoria`, `PanelFiltroUbicacion`; en Mis eventos también `PanelFiltroEstado`) con el mismo marco local (`absolute left-0 top-tooltip z-20 … rounded-xl border shadow-t13`, hoja inferior ≤600 px) y `FondoPanelFlotante` compartido para cerrar. **Estados:** cerrado y abierto verificados en los 3; «seleccionado» solo es representable en Fecha (etiqueta del disparador) y Ubicación («Ubicación: …» + «Limpiar filtros»); **Categoría no tiene estado seleccionado** (INC-06).')
A_('- **¿Pueden compartir un envoltorio?** Sí: disparador, apertura/cierre, `aria-*`, fondo, marco y hoja inferior son idénticos y solo cambia el contenido (INC-05). Un `FiltroDesplegable` que reciba el contenido por `children` conserva rangos, atajos, selección múltiple y mapa. **No** se propone sustituir el calendario por `CodeplexSelectorRangoFecha` (depende de MUI X Pro, licencia comercial) ni retirar ninguna función.')
A_('- **Incidencia visible:** el panel de Ubicación mide 730 px y a 820 px sobresale hasta 1007,9 px (INC-02; captura `' + EVID + '/eventos/evt_Ubicación_820_abierto.png`).\n')
A_('### 3.4 Empresas (las seis páginas de la regresión)\n')
A_('Las «seis páginas» son `/empresas` a 1280, 1024, 768, 600, 390 y 320 px (`scripts/quality_gate.mjs` filtra las claves `ancho|/empresas`). Controles medidos en esa ruta y en sus estados (modales, filtros, historial):\n')
gs = [g for g in FINAL if any(r.startswith('/empresas') for r in g['rutas']) and g['scope'] in ('Empresas',)]
A_(tabla_controles(sorted(gs, key=lambda g: (g['fam'], g['cons'], g['nombre'])), 70))
A_('')
A_('- **«Buscar por RUC»**: `CampoBusqueda` → `CampoTexto` → `CodeplexCampoTexto` (MUI TextField), 48 px, solo clases de layout locales (`max-900:min-w-full`). **Selector de estado**: `Selector` variante `default`, 48 px. **Filtros avanzados**: `Boton contorno md` (48 px) que abre un panel de 448×339 px (radio 12 px) con `SelectorFecha`, `Selector` y botones. **Selector de empresa** de la barra superior: `SelectorBuscable` (48 px, panel de 360×391 px).')
A_('- **Formulario «Nueva empresa»**: `CampoEtiquetado` + `CampoTexto`/`Selector` (48 px) con foco 2 px #7c3aed; pestañas del modal con `px-6` local (INC-11); cabecera con `BotonIcono` de color propio (INC-10). No se alcanzó ningún estado de error de validación (NO VERIFICADO).\n')

# ------------------------------------------------------------------ 4 resultados por familia
A_('## 4. Resultados de botones, selectores, inputs y cajas de texto\n')
filas = []
for f in fam_orden:
    gs = [g for g in FINAL if g['fam'] == f]
    if not gs:
        continue
    c = collections.Counter(g['ev']['resultado'] for g in gs)
    ws_ = collections.Counter((g['wrapper'] or ('nativo' if not g['libMui'] else 'MUI')) for g in gs)
    filas.append([f, len(gs), c.get('CUMPLE', 0), c.get('INCUMPLE', 0), c.get('NO DETERMINADO', 0), ', '.join(f'{k} ×{v}' for k, v in ws_.most_common(4))])
A_(tabla(['Familia', 'Controles únicos', 'CUMPLE', 'INCUMPLE', 'NO DET.', 'Componentes'], filas))
A_('')
A_('**Botones.** `Boton` cumple sus alturas por variante en los 4 viewports (medidas en §5). Sobrescrituras locales que contradicen la variante: `rounded-full` sobre `filtro mini` (Inicio), `gap-1 border-0 p-0` sobre `enlace` (Eventos ×3), `py-1.5 gap-0.5` en `TabsTipoPlanes`, y la variante secundaria cambiada por CSS responsive en `TarjetaInvitacion`. **Botones con icono:** `BotonIcono` cumple 32/28, 24 y 28 px; INC-10 recoge los colores locales. **Enlaces con apariencia de botón** consumen `clasesBoton`/`clasesChip` (CUMPLE); los chips de Mensajes sobrescriben el padding (INC-08). **Botones nativos:** todos figuran en el registro de excepciones (clases A–G); no hay `<button>` sin registrar (gate «Botones no registrados» ✅).\n')
A_('**Selectores y desplegables.** `Selector` (MUI Select vía `CodeplexSelector`) 48 px en `default`/`colaboradores`, 40 px en `mini` (sin contrato); `SelectorBuscable` 48 px; `SelectorFecha`/`SelectorHora` 48 px. Fuera de ellos hay cuatro tipos de «desplegable» que no son `Selector`: los pseudo-selectores `Boton` + chevron (INC-01), los filtros de Eventos (patrón válido, INC-05), los chips de módulo (Estadísticas, Indicadores, Reportes: `Boton filtro` 32 px) y el menú de usuario/campana nativos de la barra superior.\n')
A_('**Inputs y cajas de texto.** `CampoTexto`, `CampoBusqueda`, `CampoNumero` y los selectores de fecha/hora miden 48 px; la caja multilínea del formulario de evento 142 px y el editor de publicación usa `controles.campo_texto_editor`. Estados de foco medidos (INC-04): `CampoTexto`/`Selector`/multilínea 2 px + halo; `SelectorFecha/Hora` 2 px sin halo; `CampoNumero` 1 px sin halo, todos en #7c3aed. Estados de error: **NO VERIFICADO** (ningún formulario sondeado mostró errores al enviar vacío).\n')

# ------------------------------------------------------------------ 5 contratos
A_('## 5. Contratos de dimensiones y variantes\n')
A_('Fuente contractual: `catalogos/capacidades/redsocial/compartido.json` y `montaje_local/index.css` (`--control-height: 48px`). `max-600:` equivale a `<600 px` (a 600 px exactos se aplica el valor de escritorio, comprobado). La tabla completa (562 filas con panel y foco) está en la hoja «3 Catálogo de dimensiones».\n')
filas = []
for r in D['dimensiones']:
    if r['propiedad'] == 'Altura exterior' and r['familia'] in ('Botón', 'Botón con icono', 'Selector / desplegable', 'Campo de texto', 'Buscador', 'Campo numérico', 'Selector de fecha/hora', 'Pestaña', 'Chip de filtro (enlace)', 'Enlace con apariencia de botón'):
        filas.append([r['variante'], r['contractual'], r['v1280'], r['v820'], r['v400'], r['v320'], r['instancias'], r['estado']])
A_(tabla(['Variante / tamaño', 'Contractual (código)', '1280', '820', '400', '320', 'Instancias', 'Estado'], filas))
A_('')
A_('**Otras propiedades por variante** (padding, icono, separación, tipografía, radio, ancho) en el Excel; resumen de lo definido en código: `Boton` — `md`/`cta`: padding 18 px (13 px <600), radio 8 px (7 px <600), icono 16; `default`: 13 px (10 px <600), radio 7, icono 16; `mini`: 10 px, 12 px/600, icono 14; `filtro`: 12 px, radio 8, 14 px/500, icono 14; separación 8 px. `BotonIcono`: caja 32/28, 24 y 28 px; icono 18 (16 <600), 14 y 14; los glifos Material de `BotonIcono` se dibujan a 1,1× (19,8 px de caja para 18 px de fuente) mientras `Boton` los anula (`transform:none`).\n')
A_('**Paneles (medidos aparte del disparador).** Panel del `Selector` (MUI): radio 12 px, ítems 38,8 px; panel del `Menu`: radio 4 px, ítems 32 px; selector emergente de fecha/hora: 320×336 px, radio 4 px; paneles propios: radio 12 px (Fecha 502×369, Categoría 290×439, Estado 260×347, Ubicación 730×488, Filtros avanzados Empresas 448×339 y Colaboradores 500×600, selector de empresa 360×391, panel de usuario 380×402) y hoja inferior de 16 px de radio a ≤600 px. Ver «3 Catálogo de dimensiones».\n')

# ------------------------------------------------------------------ 6 mapa de compartibilidad
A_('## 6. Mapa de compartibilidad\n')
A_('Clases: **A** componente compartido usado correctamente · **B** propio que consume la configuración compartida (`clasesBoton`, `clasesChip`) · **C** propio que implementa un patrón paralelo o sin clasificar · **D** librería directa (barra lateral, MUI sin wrapper) · **E** nativo con excepción registrada. Estructura = barra superior/lateral (una vez).\n')
filas = []
for m in mods15 + ['Acceso', ESTRUCTURA, 'Compartido (componente reutilizado por varios módulos)']:
    gs = [g for g in FINAL if g['scope'] == m]
    c = collections.Counter(reutiliza(g) for g in gs)
    tot = sum(c.values()) or 1
    filas.append([m if len(m) < 40 else m[:38] + '…', len(gs), c['A'], c['B'], c['C'], c['D'], c['E'], f"{round(100 * (c['A'] + c['B']) / tot)} %"])
A_(tabla(['Módulo', 'Controles únicos', 'A', 'B', 'C', 'D', 'E', 'A+B'], filas))
A_('\nLos controles de clase **C** son las excepciones nativas no registradas por archivo y patrones sin contrato (ver hoja «2 Inventario», columna «Clase de reutilización» y «8 Pendientes»). «Una apariencia parecida no demuestra reutilización»: por eso los pseudo-selectores (`Boton` + chevron) cuentan como A por su wrapper pero se señalan como INCUMPLE de patrón en §8.\n')

# ------------------------------------------------------------------ 7 escalabilidad
A_('## 7. Escalabilidad\n')
filas = [[e['componente'], e['fuente'][:70], e['modulos'][:70] if isinstance(e['modulos'], str) else '', e['locales'] if e['locales'] is not None else '—', e['propaga'][:80], e['individuales'][:80], e['centralizable'][:90]] for e in D['escalabilidad']]
A_(tabla(['Componente / patrón', 'Fuente de verdad', 'Módulos consumidores', 'Con estilos locales', 'Se propaga automáticamente', 'Requiere editar consumidores', 'Centralizable'], filas))
A_('\nEl detalle (configuración y tokens, listas completas de consumidores con estilos locales) está en la hoja «5 Escalabilidad».\n')

# ------------------------------------------------------------------ 8 incidencias
A_('## 8. Incidencias priorizadas\n')
A_('P1 = defecto visible demostrado; P2 = patrón paralelo o sobrescritura local con equivalente compartido; P3 = decisión de diseño. Las evidencias numéricas son mediciones del navegador; ver hoja «6 Incidencias».\n')
for i in D['incidencias']:
    A_(f"**{i['id']} · {i['prioridad']} · {i['titulo']}** — {i['evidencia']} *Archivos:* {i['archivo']}. *Causa:* {i['causa']} *Recomendación:* {i['recomendacion']} *Tipo:* {i['tipo']}.\n")

# ------------------------------------------------------------------ 9 Empresas
A_('## 9. Comparación visual de Empresas\n')
A_(f'**Cómo se obtuvo la referencia.** `roles.json` es una medición (no hay capturas). Su primera versión en Git entró con el commit `a2b857e`; se extrajo ese árbol a una carpeta aparte (sin tocar el repositorio), se sirvió en otro puerto reutilizando `node_modules` mediante un *junction* y se midió `/empresas` con la misma sonda: **la firma (`agg`, `campos`, `iconBtn`, `botones`) coincide con `roles.json` en los 6 anchos**, por lo que esa versión es la referencia exacta de la medición. Las capturas de página completa de ambas versiones, los lado a lado y las diferencias están en `{EVID}/empresas/`.\n')
filas = []
for w in ANCHOS_EMP:
    img = next(x for x in IMG if x['w'] == w)
    its = [r for r in D['empresas'] if r['ancho'] == w and r['nivel'] == 'Diferencia de firma']
    c = collections.Counter(r['clasificacion'].split(' (')[0] for r in its)
    filas.append([f'/empresas · {w} px', f"{img['h1']} → {img['h2']} px (Δ {img['h2'] - img['h1']:+d})", f"{img['pct']} %", len(its), c.get('INTENCIONAL', 0), c.get('CAMBIO NO REGISTRADO', 0), c.get('NO DETERMINADA', 0), f'[lado a lado]({EVID}/empresas/cmp/empresas_{w}_lado_a_lado.png) · [diferencias]({EVID}/empresas/cmp/empresas_{w}_diferencias.png)'])
A_(tabla(['Página', 'Alto de documento ref → act', '% píxeles distintos', 'Diferencias de firma', 'Intencionales', 'No registradas', 'No determinadas', 'Imágenes'], filas))
A_('')
A_('**Cambios observados y su origen** (detalle por ancho en la hoja «7 Regresión Empresas»):\n')
A_(tabla(['Cambio', 'Antes → después', 'Origen en el código', 'Clasificación'], [
    ['Botones «Nueva empresa» y «Filtros avanzados»', '38 px (34 px móvil) → 48 px', '`boton_tamanos.md = min-h-control` (Fase 2)', 'INTENCIONAL — aprobada 2026-10-17'],
    ['Buscar por RUC, selector de estado y «por página»', '40 → 48 px', '`controles.campo_texto`/`selector_libreria` con `--height-control` (Fase 2)', 'INTENCIONAL — aprobada'],
    ['Buscador superior', '40 → 48 px', '`CampoBusqueda` → `CampoTexto`', 'INTENCIONAL — aprobada'],
    ['Selector de empresa', '52 → 48 px; RUC oculto cerrado', '`selector_empresa_topbar.tsx` → `SelectorBuscable`', 'INTENCIONAL — aprobada'],
    ['Botón de carrito', '6 → 7 botones de icono', '`boton_carrito_topbar.tsx` (nuevo)', 'INTENCIONAL — aprobada'],
    ['Altura de la barra superior', '64 → 72 px (+8 px en toda la página)', '`barra_superior.tsx`: `h-16` → `h-18`', 'CAMBIO NO REGISTRADO (causa demostrada por `git diff` y medida en ambas versiones)'],
    ['Tipografía de componentes MUI', 'Roboto → fuente heredada; `letter-spacing` 0,15 px → normal en campos; encabezado «MÓDULOS DISPONIBLES» de 2 líneas (39,8 px) a 1 línea (24 px); botón «+» 23,5 → 24 px', '`proveedor_tema_graficos.tsx`: `typography: fuente_heredada`', 'CAMBIO NO REGISTRADO (causa demostrada por medida de `font-family` en ambas versiones)'],
]))
A_('\n**Dictamen.** Ninguna diferencia se clasifica como defecto visual confirmado. Las diferencias intencionales ya están aprobadas, pero la línea base no se ha regenerado (decisión de la usuaria). Los dos cambios no registrados (altura de la barra superior y tipografía MUI heredada) son consecuencia de trabajos previos y necesitan aceptación explícita antes de proponer una nueva línea base. No se modificaron `roles.json`, hashes ni capturas de referencia.\n')

# ------------------------------------------------------------------ 10 pendientes
A_('## 10. Pendientes y excepciones\n')
c = collections.Counter(p['tipo'] for p in D['pendientes'])
A_('; '.join(f'{k}: {v}' for k, v in c.items()) + '. El detalle completo está en la hoja «8 Pendientes y excepciones». Resumen de lo no verificado:\n')
for p in D['pendientes']:
    if p['estado'] in ('NO VERIFICADO',) or p['tipo'].startswith('Decisión'):
        A_(f"- **{p['tipo']} — {p['elemento']}** ({p['estado']}): {p['detalle']}")
A_('')

# ------------------------------------------------------------------ 11 limitaciones
A_('## 11. Limitaciones de la auditoría\n')
for t in [
    'La enumeración depende del DOM renderizado: controles fuera del DOM (listas virtualizadas, pestañas no montadas) no se ven. Los estados se alcanzaron con un clic por control, a 1280 y 400 px (segundo nivel solo a 1280 px); 820 y 320 px solo tienen el estado base.',
    'No se midieron hover, active, disabled ni navegación con teclado/lector de pantalla en esta fase; los estados de error de formulario no se pudieron reproducir (0 campos con `aria-invalid` tras enviar vacío).',
    'El «consumidor» y el archivo proceden de `_debugOwner`/`_debugStack` de React en modo desarrollo (solo ruta del archivo; los números de línea del stack no coinciden con el código fuente y no se usan).',
    'Una altura que coincide con el contrato no demuestra que el componente sea el correcto: por eso se cruzaron wrapper, variante, `className` local, semántica ARIA y comportamiento al clic.',
    'La clasificación A–E y CUMPLE/INCUMPLE usa reglas explícitas (contrato dimensional, sobrescrituras de `className` dimensionales o de color, registro de excepciones de `pruebas/compartido/registro_componentes_permitidos.ts`); las reglas pueden dar falsos positivos en sobrescrituras legítimas (p. ej. responsive).',
    'La referencia de Empresas es una reconstrucción verificada por firma, no las capturas originales (que no existen).',
    '`/no-encontrada` y los estados posteriores al inicio de sesión no se recorrieron.',
]:
    A_('- ' + t)
A_('')

# ------------------------------------------------------------------ 12 etapas
A_('## 12. Recomendación de corrección por etapas\n')
A_('No se implementa nada hasta que la usuaria revise el inventario y autorice la siguiente fase.\n')
A_(tabla(['Etapa', 'Contenido', 'Incidencias', 'Requiere decisión'], [
    ['1 · Defectos visibles locales', 'Panel de Ubicación a 820 px; solape del botón de menú con el buscador; categoría con estado de selección', 'INC-02, INC-03, INC-06', 'No'],
    ['2 · Foco unificado', 'Un solo estado de foco (borde, halo, color) para CampoTexto, Selector, fecha/hora y CampoNumero', 'INC-04', 'Sí: color de foco/primario'],
    ['3 · Variantes compartidas', 'Variantes de BotonIcono (sobre oscuro/imagen/peligro), tamaño enlace compacto, chip compacto, pie de lista único, pestañas de modal', 'INC-08–INC-12, INC-14, INC-15, INC-26, INC-27', 'No (solo catálogo)'],
    ['4 · Componentes nuevos', 'FiltroDesplegable (Eventos), BannerInformativo', 'INC-05, INC-07', 'No si se conserva el contenido propio'],
    ['5 · Desplegables simulados', 'Sustituir `Boton`+chevron por `Selector` o quitar el chevron', 'INC-01, INC-19', 'Sí: variante y opciones'],
    ['6 · Decisiones de diseño', 'Primario MUI, alturas de la barra superior, píldoras de Inicio, patrones especiales, tamaños de cabecera de Actividad, radios de paneles', 'INC-13, INC-16–INC-18, INC-20', 'Sí'],
    ['7 · Línea base', 'Aceptar o rechazar la altura de la barra superior y la tipografía MUI; después proponer la línea base', '§9', 'Sí'],
]))
A_('')
A_('## Anexo. Archivos y reproducibilidad\n')
A_(f'- `{NOMBRE}.xlsx` (8 hojas), `{NOMBRE}_inventario.md` (inventario completo) y `{EVID}/` con capturas, diferencias, datos de las sondas (`datos/`), el comprimido de mediciones crudas y los scripts de las sondas (`sondas/`).')
A_('- Sondas: Chrome headless por CDP contra `http://localhost:5173` (servidor Vite del proyecto); `aud.mjs` (base + clic), `aud3.mjs` (búsqueda vacía y formularios vacíos), `evt.mjs` (filtros de Eventos), `foco.mjs`, `banner.mjs`, `emp_shots.mjs`/`imgdiff.mjs` (Empresas), `emp_estilos.mjs`/`emp_head.mjs` (estilos calculados en ambas versiones).')
open(SC + r'\au\informe.md', 'w', encoding='utf8').write('\n'.join(md))
print('informe md', len('\n'.join(md)))

# ------------------------------------------------------------------ inventario md
im = []
im.append('# Inventario de controles — Auditoría Fase 4 (CodePlex Red Social)\n')
im.append(f'Generado el {fecha} a partir de las mismas mediciones que [{NOMBRE}.xlsx]({NOMBRE}.xlsx) (hoja «2 Inventario de controles») y que [{NOMBRE}.md]({NOMBRE}.md). {len(inv)} controles únicos; alturas en px: 1280/820/400/320 (NO VISIBLE = visitado y ausente; NO VERIFICADO = no visitado).\n')
orden = MODULOS + ['Acceso', ESTRUCTURA, 'Compartido (componente reutilizado por varios módulos)']
for m in orden:
    rows = [r for r in inv if r['modulo'] == m]
    if not rows:
        continue
    im.append(f'## {m} ({len(rows)})\n')
    im.append(tabla(['ID', 'Control', 'Tipo', 'Componente', 'Var./tam.', 'Consumidor', 'Rutas', 'Estado', 'h 1280', 'h 820', 'h 400', 'h 320', 'Resultado', 'Motivo'],
                    [[r['id'], r['nombre'][:40], r['tipo'], r['componente'], f"{r['variante']}/{r['tamano']}", r['consumidor'], f"{r['n_rutas']}: {r['rutas'][:50]}", r['estado'][:40], r['h1280'], r['h820'], r['h400'], r['h320'], r['resultado'], r['motivo'][:140]] for r in rows]))
    im.append('')
open(SC + r'\au\inventario.md', 'w', encoding='utf8').write('\n'.join(im))
print('inventario md', len('\n'.join(im)))
