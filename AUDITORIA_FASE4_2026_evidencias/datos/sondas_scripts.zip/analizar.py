import json, re, os, glob, collections, statistics
from carga import SC, A, jsonl

BS = chr(92)
RAIZ = r'C:\Users\Angie\Documents\CODEPLEX\redSocial'
FRONT = RAIZ + r'\redsocial\frontend'

# ---------------------------------------------------------------- rutas y módulos
MOD_RUTA = [
    ('/inicio', 'Inicio'), ('/actividad', 'Actividad'), ('/notificaciones', 'Notificaciones'), ('/mensajes', 'Mensajes'),
    ('/amigos', 'Amigos'), ('/grupos', 'Grupos'), ('/marketplace', 'Marketplace'), ('/eventos', 'Eventos'),
    ('/guardados', 'Guardados'), ('/colaboradores', 'Colaboradores'), ('/empresas', 'Empresas'), ('/dashboard', 'Dashboard'),
    ('/estadisticas', 'Estadísticas'), ('/reportes', 'Reportes'), ('/indicadores', 'Indicadores'), ('/acceso', 'Acceso'),
]
MODULOS = [m for _, m in MOD_RUTA]
ESTRUCTURA = 'Estructura compartida (barra superior y lateral)'
PESTANA = {
    '/inicio': 'Inicio (feed)', '/actividad': 'Todas', '/actividad/publicaciones': 'Publicaciones', '/actividad/menciones': 'Menciones',
    '/actividad/colaboradores': 'Colaboradores', '/actividad/grupos': 'Grupos', '/actividad/modulos': 'Módulos', '/actividad/sistema': 'Sistema',
    '/notificaciones': 'Todas', '/notificaciones/no-leidas': 'No leídas', '/notificaciones/solicitudes': 'Solicitudes', '/notificaciones/menciones': 'Menciones',
    '/notificaciones/eventos': 'Eventos', '/notificaciones/sistema': 'Sistema',
    '/mensajes': 'Todos', '/mensajes/no-leidos': 'No leídos', '/mensajes/favoritos': 'Favoritos', '/mensajes/videollamadas': 'Videollamadas',
    '/mensajes/videollamadas/iniciar': 'Videollamadas · Iniciar', '/mensajes/videollamadas/en-curso': 'Videollamadas · En curso',
    '/amigos': 'Todos', '/amigos/solicitudes': 'Solicitudes', '/amigos/sugerencias': 'Sugerencias', '/amigos/listas': 'Listas',
    '/grupos': 'Mis grupos', '/grupos/descubrir': 'Descubrir', '/grupos/invitaciones': 'Invitaciones',
    '/marketplace': 'Marketplace', '/eventos': 'Para ti', '/eventos/proximos': 'Próximos', '/eventos/populares': 'Populares', '/eventos/mis-eventos': 'Mis eventos',
    '/eventos/invitaciones': 'Invitaciones', '/eventos/invitaciones/pendientes': 'Invitaciones · Pendientes', '/eventos/invitaciones/aceptadas': 'Invitaciones · Aceptadas',
    '/eventos/invitaciones/rechazadas': 'Invitaciones · Rechazadas', '/eventos/calendario': 'Calendario', '/guardados': 'Guardados',
    '/colaboradores': 'Listado', '/colaboradores/perfil': 'Perfil', '/empresas': 'Listado', '/dashboard': 'Dashboard',
    '/estadisticas': 'Todos los módulos', '/estadisticas/contabilidad': 'Contabilidad', '/estadisticas/planillas': 'Planillas', '/estadisticas/ventas': 'Ventas',
    '/reportes': 'Reportes', '/indicadores': 'Indicadores', '/acceso': 'Acceso',
}


def modulo_de(ruta):
    for p, m in MOD_RUTA:
        if ruta == p or ruta.startswith(p + '/'):
            return m
    return 'Otros'


# ---------------------------------------------------------------- índice componente -> archivo
INDICE = {}
for f in glob.glob(FRONT + r'\**\*.tsx', recursive=True):
    rel = os.path.relpath(f, FRONT).replace(BS, '/')
    if rel.startswith('pruebas/'):
        continue
    s = open(f, encoding='utf8').read()
    for m in re.finditer(r'(?:^|\n)(?:export\s+)?(?:default\s+)?function\s+([A-Z]\w*)\s*[(<]', s):
        INDICE.setdefault(m.group(1), rel)
    for m in re.finditer(r'(?:^|\n)(?:export\s+)?const\s+([A-Z]\w*)\s*(?::[^=]+)?=\s*(?:\(|memo|forwardRef)', s):
        INDICE.setdefault(m.group(1), rel)

REG = open(FRONT + r'\pruebas\compartido\registro_componentes_permitidos.ts', encoding='utf8').read()
REGISTRO = {}
for m in re.finditer(r"'(/[^']+\.tsx)':\s*\{\s*cantidad:\s*(\d+),\s*clasificacion:\s*'(\w)',\s*motivo:\s*([^}]+?)\s*\}", REG):
    REGISTRO[m.group(1).lstrip('/')] = dict(cantidad=int(m.group(2)), clase=m.group(3), motivo=m.group(4).strip().strip("'"))
MOT = {'SUPERFICIE_SOBRE_VIDEO': 'control sobre el video con paleta de superposicion propia', 'FILA_DE_OPCION': 'fila de opcion o de seleccion con estado propio, no es una accion estandar'}
for v in REGISTRO.values():
    v['motivo'] = MOT.get(v['motivo'], v['motivo'])

# ---------------------------------------------------------------- clasificación
WRAP_CTRL = ['ListaOpcionesBuscables', 'PanelSelectorBuscable', 'BotonPieLista', 'Boton', 'BotonIcono', 'SelectorBuscable', 'Selector', 'SelectorFecha', 'SelectorHora', 'CampoBusqueda', 'CampoNumero', 'CampoTexto', 'Casilla', 'Radio', 'Interruptor', 'Pestanas', 'Paginacion', 'Menu']
GENERICOS = re.compile(r'^(Mui|Styled|Box$|ForwardRef|DefaultPropsProvider|RtlProvider|EmotionTheme|ThemeContext|ThemeProvider|FormControl|ListContext|List$|Typography|ButtonBase|IconButton|Tab$|Tabs|PickersSection|SwitchBase|TextField|OutlinedInput|Select|InputBase|Popper|Popover|Modal|Paper|Menu|Portal|Grow|Fade|Transition|Backdrop|TouchRipple|Dialog|Pickers|Date|Time|Link$|Checkbox|Radio$|Switch|Input|Slide|Collapse|Ripple|Unstable|PopperTooltip)')
ESTRUCT = re.compile(r'^(Pagina|Proveedor|Aplicacion|EstructuraApp|EstructuraTresColumnas|ProveedorTemaGraficos|BarraSuperior$)')
TOK_TEXTO = set('titulo-pagina titulo-seccion titulo-banner subtitulo cuerpo-grande valor-destacado nombre-entidad cuerpo auxiliar etiqueta badge estado contador conteo titulo-subseccion boton-mini chip boton enlace-accion navegacion encabezado-tabla fecha-abreviada campo-formulario nombre-fila dia-evento mes-evento'.split())
SEGURO = re.compile(r'^(?:[\w\[\]-]+:)*(?:-?m[trblxy]?-[\w.\[\]/-]+|flex-none|flex-1|flex|shrink-0|grow|self-\w+|justify-\w+|items-\w+|w-full|min-w-0|max-w-[\w.\[\]/-]+|col-span-[\w-]+|order-[\w-]+|ml-auto|mr-auto|mx-auto|hidden|block|inline(?:-flex|-block)?|relative|absolute|sticky|z-\d+|top-[\w.-]+|left-[\w.-]+|right-[\w.-]+|bottom-[\w.-]+|inset-[\w.-]+|truncate|cursor-\w+|disabled:[\w:/.-]+|hover:no-underline|aria-[\w:-]+|focus-visible:[\w:/.-]+|whitespace-\w+|w-\d[\w.]*|w-\[[^\]]+\]|min-w-\d[\w.]*|shrink|basis-[\w./-]+|flex-wrap|flex-col|overflow-\w+|transition[\w-]*|opacity-\d+|invisible|visible)$')
DIM = re.compile(r'^(?:[\w\[\]-]+:)*(?:h-[\w.\[\]/-]+|min-h-[\w.\[\]/-]+|max-h-[\w.\[\]/-]+|p-[\w.\[\]]+|px-[\w.\[\]]+|py-[\w.\[\]]+|pt-[\w.\[\]]+|pb-[\w.\[\]]+|pl-[\w.\[\]]+|pr-[\w.\[\]]+|gap(?:-[xy])?-[\w.\[\]]+|size-[\w.\[\]]+|leading-[\w.\[\]-]+|rounded(?:-[\w.\[\]]+)?|font-(?:titulo|control|etiqueta|normal|bold|semibold|medium|\w+)|text-(?:' + '|'.join(sorted(TOK_TEXTO)) + r'))$')


COL = re.compile(r'^(?:[\w\[\]-]+:)*(?:bg|border|shadow|ring|fill|stroke|outline|from|to|via)-[\w./\[\]#%-]+$|^(?:[\w\[\]-]+:)*text-(?!left$|center$|right$|inherit$|start$|end$|balance$|wrap$|nowrap$|ellipsis$|clip$)[\w./\[\]#%-]+$')
DIM0 = re.compile(r'^(?:[\w\[\]-]+:)*border-0$')


def tokens_locales(cn):
    seg, dim, otros = [], [], []
    for t in (cn or '').split():
        if DIM.match(t) or DIM0.match(t):
            dim.append(t)
        elif COL.match(t):
            otros.append(t)
        else:
            seg.append(t)
    return seg, dim, otros


def consumidor(c):
    for n in c['cadena']:
        if n in WRAP_CTRL or n in ('CampoEtiquetado', 'Acordeon', 'Modal', 'FondoPanelFlotante'):
            continue
        if GENERICOS.match(n) or len(n) <= 3:
            continue
        if ESTRUCT.match(n):
            continue
        return n
    for n in c['cadena']:
        if n.startswith('Pagina'):
            return n
    return c['cadena'][0] if c['cadena'] else '?'


def principal(c):
    ws = [e for e in c['envolturas'] if e['nombre'] in WRAP_CTRL]
    if not ws:
        return None
    nom = {e['nombre']: e for e in ws}
    for n in WRAP_CTRL:
        if n in nom:
            return nom[n]
    return ws[0]


def etiquetado(c):
    return any(e['nombre'] == 'CampoEtiquetado' for e in c['envolturas'])


def en_modal(c):
    return any(e['nombre'] == 'Modal' for e in c['envolturas'])


ICON_TOK = re.compile(r'\b[a-z]+(?:_[a-z0-9]+)+\b')


def nombre_clave(n):
    n = nombre_visible(n).lower()
    n = re.sub(r'\d+', '', n)
    return re.sub(r'\s+', ' ', n).strip()


_cat = json.load(open(FRONT + '/catalogos/capacidades/redsocial/compartido.json', encoding='utf8'))
_nombres = set()
for _k in ('nombres_iconos', 'iconos_libreria', 'iconos'):
    _v = _cat.get(_k)
    if isinstance(_v, dict):
        for _x in _v.values():
            if isinstance(_x, str) and re.fullmatch(r'[a-z0-9_]+', _x):
                _nombres.add(_x)
_nombres |= {'keyboard_arrow_down', 'keyboard_arrow_up', 'expand_more', 'expand_less', 'chevron_left', 'chevron_right', 'arrow_drop_down'}
GLIFOS_US = sorted([x for x in _nombres if '_' in x], key=len, reverse=True)
GLIFOS_1 = sorted([x for x in _nombres if '_' not in x and len(x) >= 3], key=len, reverse=True)


def nombre_visible(n):
    n = n or ''
    for g in GLIFOS_US:
        n = n.replace(g, ' ')
    n = ICON_TOK.sub(' ', n)
    for g in GLIFOS_1:
        m = re.match(r'^' + g + r'(?=[A-ZÁÉÍÓÚÑ])', n)
        if m:
            n = n[len(g):]
            break
    return re.sub(r'\s+', ' ', n).strip()


TIPO_NOM = {'boton': 'Botón', 'enlace': 'Enlace', 'pestana': 'Pestaña', 'item_menu': 'Ítem de menú', 'selector': 'Selector / desplegable', 'interruptor': 'Interruptor',
            'casilla': 'Casilla', 'radio': 'Radio', 'campo': 'Campo de texto', 'campo_numero': 'Campo numérico', 'campo_fecha': 'Selector de fecha/hora', 'busqueda': 'Buscador',
            'campo_multilinea': 'Caja de texto multilínea', 'archivo': 'Selección de archivo', 'rango': 'Control deslizante'}


def familia(c, pr, nat_clase):
    t = c['tipo']
    if pr:
        n = pr['nombre']
        if n in ('ListaOpcionesBuscables', 'PanelSelectorBuscable'):
            return 'Opción de panel de selector buscable'
        if n == 'BotonIcono':
            return 'Botón con icono'
        if n in ('Boton', 'BotonPieLista'):
            return 'Botón'
        if n in ('Selector', 'SelectorBuscable'):
            return 'Selector / desplegable'
        if n in ('SelectorFecha', 'SelectorHora'):
            return 'Selector de fecha/hora'
        if n == 'CampoBusqueda':
            return 'Buscador'
        if n == 'CampoNumero':
            return 'Campo numérico'
        if n == 'CampoTexto':
            return 'Caja de texto multilínea' if t == 'campo_multilinea' else 'Campo de texto'
        if n in ('Casilla', 'Radio', 'Interruptor'):
            return n
        if n == 'Pestanas':
            return 'Pestaña'
        if n == 'Paginacion':
            return 'Paginación'
        if n == 'Menu':
            return 'Ítem de menú'
    if t == 'boton' and c['tag'] == 'button' and c['ariaHaspopup'] and not c['envolturas']:
        return 'Selector / desplegable'
    if nat_clase == 'mapa':
        return 'Control de mapa (Leaflet)'
    if t == 'enlace' and nat_clase == 'pie_enlace':
        return 'Enlace de pie de lista (hecho a mano)'
    if t == 'enlace' and nat_clase == 'boton_a_mano':
        return 'Enlace con apariencia de botón (hecho a mano)'
    if t == 'enlace' and nat_clase == 'fila':
        return 'Fila de lista navegable'
    if t == 'enlace' and nat_clase in ('boton', 'boton_pie', 'chip'):
        return 'Chip de filtro (enlace)' if nat_clase == 'chip' else 'Enlace con apariencia de botón'
    if t == 'enlace':
        return 'Enlace de texto'
    return TIPO_NOM.get(t, t)


CLASES_BOTON = 'inline-flex items-center justify-center gap-sm whitespace-nowrap border'


def nativo_clase(c):
    cl = c['claseHost']
    if 'leaflet' in cl:
        return 'mapa'
    if CLASES_BOTON in cl:
        return 'boton_pie' if ('rounded-none' in cl and 'p-3.5' in cl) else 'boton'
    if 'rounded-20' in cl and 'h-8' in cl and 'border' in cl:
        return 'chip'
    if c['tipo'] == 'enlace':
        if 'text-enlace-accion' in cl and 'justify-center' in cl and ('p-3.5' in cl or 'py-3' in cl or 'p-3 ' in cl or cl.endswith('p-3')):
            return 'pie_enlace'
        if 'rounded-lg' in cl and 'border' in cl and ('text-center' in cl or 'justify-center' in cl):
            return 'boton_a_mano'
        if 'text-inherit' in cl and 'border-b' in cl:
            return 'fila'
        if 'border' not in cl and 'bg-' not in cl and not re.search(r'(^| )(p|px|py)-', cl) and ('text-primario' in cl or 'text-texto-suave' in cl):
            return 'texto'
    return None


# contrato de altura (fuente: compartido.json -> boton_tamanos, boton_icono_tamanos, controles)
def contrato_altura(c, pr, w, nat_clase):
    movil = w < 600
    if pr:
        n, p = pr['nombre'], pr['props']
        if n in ('Boton', 'BotonPieLista'):
            size = p.get('size') or 'default'
            if n == 'BotonPieLista':
                return None
            m = {'md': ('min', 48), 'cta': ('min', 40), 'default': ('min', 30 if movil else 34), 'mini': ('min', 30), 'filtro': ('exacta', 32)}
            return m.get(size)
        if n == 'BotonIcono':
            size = p.get('size') or 'default'
            return {'default': ('exacta', 28 if movil else 32), 'sm': ('exacta', 24), 'md': ('exacta', 28)}.get(size)
        if n in ('CampoTexto', 'CampoBusqueda', 'CampoNumero', 'Selector', 'SelectorFecha', 'SelectorHora'):
            if c['tipo'] == 'campo_multilinea':
                return None
            if n == 'Selector' and p.get('variant') in ('mini', 'integrado'):
                return None
            return ('min', 48)
        if n == 'SelectorBuscable':
            return ('exacta', 48)
        if n == 'Pestanas':
            return ('min', 40)
    if nat_clase == 'chip':
        return ('exacta', 32)
    if nat_clase == 'boton':
        return ('uno_de', (30, 34, 40, 48))
    return None


def evalua_altura(contr, h):
    if not contr:
        return None
    k, v = contr
    if k == 'min':
        return h + 0.6 >= v
    if k == 'exacta':
        return abs(h - v) <= 0.6
    if k == 'uno_de':
        return any(abs(h - x) <= 0.6 for x in v)
    return None


def texto_contrato(contr):
    if not contr:
        return 'sin contrato de altura'
    k, v = contr
    if k == 'min':
        return f'mín. {v} px'
    if k == 'exacta':
        return f'{v} px'
    return 'uno de ' + '/'.join(map(str, v)) + ' px'


def archivo_de(nombre):
    return INDICE.get(nombre)


def registro_de(nombre):
    f = archivo_de(nombre)
    if f and f in REGISTRO:
        return f, REGISTRO[f]
    return f, None


def es_mui(c):
    return bool(c['cadena'] and c['cadena'][0].startswith('Mui')) or 'Mui' in (c.get('claseHost') or '')
