import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${process.env.FOCO_PORT || 9395}`, `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch(`http://127.0.0.1:${process.env.FOCO_PORT || 9395}/json`)).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

await cdp('Page.enable')
const FAM = `((raiz) => {
  if (raiz.matches('.MuiPickersInputBase-root')) return 'SelectorFecha/Hora'
  if (raiz.querySelector('textarea')) return 'Caja multilínea'
  if (raiz.querySelector('[role=combobox]')) return 'Selector'
  if (raiz.querySelector('input[type=search]') || /buscar/i.test(raiz.querySelector('input')?.placeholder || '')) return 'Buscador'
  if (raiz.querySelector('input[type=number]')) return 'Campo numérico'
  return 'Campo de texto'
})`
const ESTILO = `((raiz) => {
  const f = raiz.querySelector('fieldset') || raiz
  const cs = getComputedStyle(raiz); const cf = getComputedStyle(f)
  const r = raiz.getBoundingClientRect()
  const inp = raiz.querySelector('input, textarea, [role=combobox]')
  const ci = inp ? getComputedStyle(inp) : cs
  return { h: Math.round(r.height * 10) / 10, w: Math.round(r.width * 10) / 10, bordeFieldset: cf.borderTopWidth + ' ' + cf.borderTopColor, sombraRaiz: cs.boxShadow.slice(0, 60), sombraFieldset: cf.boxShadow.slice(0, 60), outline: cs.outlineStyle + ' ' + cs.outlineWidth + ' ' + cs.outlineColor, radio: cs.borderTopLeftRadius, fondo: cs.backgroundColor, fuente: ci.fontSize, peso: ci.fontWeight, color: ci.color, claseFoco: raiz.className.includes('Mui-focused'), claseError: raiz.className.includes('Mui-error'), ariaInvalid: inp ? inp.getAttribute('aria-invalid') : null }
})`
const RES = []
for (const [w, h, mv] of [[1280, 900, false], [400, 850, true]]) {
  await viewport(w, h, mv)
  await cdp('Page.navigate', { url: 'http://localhost:5173' + ('/' + (process.env.FOCO_URL || 'empresas')) }); await dormir(9000)
  await clicSel(`[...document.querySelectorAll('button')].find((b) => new RegExp(${JSON.stringify(process.env.FOCO_BTN || 'Nueva empresa')}).test(b.textContent))`)
  await dormir(1200)
  const n = await evalJS(`document.querySelectorAll('[role=dialog] .MuiInputBase-root, [role=dialog] .MuiPickersInputBase-root').length`)
  const fams = await evalJS(`(() => { const out = {}; [...document.querySelectorAll('[role=dialog] .MuiInputBase-root, [role=dialog] .MuiPickersInputBase-root')].forEach((r, i) => { const f = ${FAM}(r); if (!(f in out)) out[f] = i }); return out })()`)
  for (const [fam, i] of Object.entries(fams)) {
    const sel = `[...document.querySelectorAll('[role=dialog] .MuiInputBase-root, [role=dialog] .MuiPickersInputBase-root')][${i}]`
    let normal = await evalJS(`${ESTILO}(${sel})`)
    if (typeof normal === 'string') normal = { error: normal.slice(0, 160) }
    await clicSel(`${sel}.querySelector('input, textarea, [role=combobox], [role=spinbutton]') || ${sel}`)
    await dormir(400)
    let foco = await evalJS(`${ESTILO}(${sel})`)
    if (typeof foco === 'string') foco = { error: foco.slice(0, 160) }
    await evalJS(`document.activeElement && document.activeElement.blur()`); await dormir(250)
    if (fam === 'Selector') { await tecla('Escape', 'Escape'); await dormir(300) }
    RES.push({ vp: w, fam, estado: 'normal', ...normal }, { vp: w, fam, estado: 'foco', ...foco })
  }
  await evalJS(`document.activeElement && document.activeElement.blur()`)
  const env = await evalJS(`(() => { const d = document.querySelector('[role=dialog]'); const b = [...d.querySelectorAll('button')].reverse().find((x) => /crear|guardar|registrar|siguiente/i.test(x.textContent) && !x.disabled); if (!b) return null; b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2, t: b.textContent.trim() } })()`)
  if (env) {
    await clicXY(env.x, env.y); await dormir(900)
    const errs = await evalJS(`(() => { const out = {}; [...document.querySelectorAll('[role=dialog] .MuiInputBase-root, [role=dialog] .MuiPickersInputBase-root')].forEach((r) => { const f = ${FAM}(r); const inv = r.className.includes('Mui-error') || r.querySelector('[aria-invalid=true]'); if (inv && !(f in out)) out[f] = { ...(${ESTILO}(r)), ayuda: (() => { const hp = r.parentElement.querySelector('.MuiFormHelperText-root') || r.closest('div')?.parentElement?.querySelector('.MuiFormHelperText-root'); return hp ? { texto: hp.textContent.slice(0, 60), fuente: getComputedStyle(hp).fontSize, color: getComputedStyle(hp).color } : null })() } }); return out })()`)
    for (const [fam, e] of Object.entries(errs || {})) RES.push({ vp: w, fam, estado: 'error', boton: env.t, ...e })
    RES.push({ vp: w, fam: '(resumen)', estado: 'tras enviar', campos: n, familiasConError: Object.keys(errs || {}), boton: env.t })
  }
  await foto('foco_' + w)
}
writeFileSync(SALIDA + '/' + (process.env.FOCO_OUT || 'foco') + '.json', JSON.stringify(RES, null, 1))
ws.close(); chrome.kill(); process.exit(0)
