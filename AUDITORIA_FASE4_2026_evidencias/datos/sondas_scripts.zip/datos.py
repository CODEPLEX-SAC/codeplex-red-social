import json, sys, collections, os, re
from grupos import *

RUTA_REPO = 'C:/Users/Angie/Documents/CODEPLEX/redSocial/redsocial/frontend/'
ENL = lambda f: ('file:///' + RUTA_REPO + f) if f else None

INFO = {
    'Boton': ('— (propio; @codeplex-sac no ofrece botón)', 'Boton · componentes/compartido/interfaz/boton.tsx', 'compartido.json: boton_base, boton_medio, boton_tamanos, boton_tamanos_medios, boton_variantes, boton_activo, boton_icono_por_tamano, boton_icono_clases'),
    'BotonIcono': ('— (propio)', 'BotonIcono · interfaz/boton_icono.tsx', 'compartido.json: boton_icono_base, boton_icono_variantes, boton_icono_tamanos'),
    'BotonPieLista': ('— (propio, sobre Boton)', 'BotonPieLista · interfaz/boton_pie_lista.tsx → Boton', 'compartido.json: boton_pie_lista (+ configuración de Boton)'),
    'Selector': ('@codeplex-sac/formularios · CodeplexSelector (MUI Select)', 'Selector · interfaz/selector.tsx', 'compartido.json: selector_libreria, selector_envoltorio, selector_label, selector_atributo_accesible, campos.seleccionar_opcion'),
    'SelectorBuscable': ('— (propio; sin librería)', 'SelectorBuscable · interfaz/selector_buscable.tsx', 'compartido.json: selector_buscable (+ selector_empresa en la barra superior)'),
    'ListaOpcionesBuscables': ('— (propio)', 'ListaOpcionesBuscables · interfaz/lista_opciones_buscables.tsx', 'compartido.json: selector_buscable (opcion, opcion_seleccionada, lista)'),
    'PanelSelectorBuscable': ('— (propio)', 'PanelSelectorBuscable · interfaz/panel_selector_buscable.tsx', 'compartido.json: selector_buscable (panel, buscador, pie)'),
    'SelectorFecha': ('@codeplex-sac/selectores-fecha · CodeplexSelectorFecha (MUI X Date Pickers)', 'SelectorFecha · interfaz/selector_fecha.tsx', 'compartido.json: controles.selector_fecha'),
    'SelectorHora': ('@codeplex-sac/selectores-fecha · CodeplexSelectorHora (MUI X Date Pickers)', 'SelectorHora · interfaz/selector_hora.tsx', 'compartido.json: controles.selector_hora'),
    'CampoTexto': ('@codeplex-sac/formularios · CodeplexCampoTexto (MUI TextField)', 'CampoTexto · interfaz/campo_texto.tsx', 'compartido.json: controles.campo_texto (+ controles.campo_texto_editor), controles.texto_vacio, placeholder_tema'),
    'CampoBusqueda': ('@codeplex-sac/formularios · CodeplexCampoTexto (vía CampoTexto)', 'CampoBusqueda · interfaz/campo_busqueda.tsx → CampoTexto', 'compartido.json: controles.tipo_busqueda, controles.atributo_accesible, campos.buscar_en_codeplex'),
    'CampoNumero': ('@codeplex-sac/formularios · CodeplexCampoNumero', 'CampoNumero · interfaz/campo_numero.tsx', 'compartido.json: controles.campo_numero'),
    'Casilla': ('@codeplex-sac/formularios · CodeplexCasilla (MUI Checkbox)', 'Casilla · interfaz/casilla.tsx', 'compartido.json: controles.casilla_tamano'),
    'Radio': ('@codeplex-sac/formularios · CodeplexRadio (MUI Radio)', 'Radio · interfaz/radio.tsx', 'compartido.json: controles.radio'),
    'Interruptor': ('@codeplex-sac/formularios · CodeplexInterruptor (MUI Switch)', 'Interruptor · interfaz/interruptor.tsx', 'compartido.json: controles.interruptor'),
    'Pestanas': ('@codeplex-sac/navegacion · CodeplexPestanas + MUI Tab', 'Pestanas · interfaz/pestanas.tsx', 'compartido.json: pestanas, pestanas_tema'),
    'Menu': ('@codeplex-sac/navegacion · CodeplexMenu (MUI Menu)', 'Menu · interfaz/menu.tsx', 'compartido.json: menu, elemento_menu_tema'),
    'Paginacion': ('@codeplex-sac/navegacion · CodeplexPaginacion', 'Paginacion · interfaz/paginacion.tsx', 'compartido.json: paginacion'),
}


def fmt_vp(v, clave='h'):
    if v is None:
        return 'NO VERIFICADO'
    if v['estado'] != 'MEDIDO':
        return v['estado']
    x = v.get(clave)
    return x if x is not None else '—'


def fila_inventario(i, g):
    ev = g['ev']
    wr = g['wrapper']
    lib, wrapper_txt, conf = INFO.get(wr, ('', '', '')) if wr else ('', '', '')
    if not wr:
        if g['nat'] == 'boton':
            lib, wrapper_txt, conf = '— (HTML nativo <a>/<button>)', 'ninguno (consume clasesBoton)', 'compartido.json: boton_* vía clasesBoton() (interfaz/boton.tsx)'
        elif g['nat'] == 'chip':
            lib, wrapper_txt, conf = '— (HTML nativo <a>/<button>)', 'ninguno (consume clasesChip)', 'compartido.json: chip_filtro vía interfaz/chip_filtro.ts'
        elif g['libMui']:
            lib, wrapper_txt, conf = '@codeplex-sac / MUI (sin envoltorio propio)', 'según archivo', 'según archivo'
        else:
            lib, wrapper_txt, conf = '— (HTML nativo)', 'ninguno', 'ninguna' + (f" (registro clase {ev['registro']['clase']})" if ev['registro'] else '')
    local = ' '.join(ev['dim'] + ev['otros'])
    seg = ' '.join(ev['seg'])
    n_pant = max([v.get('n', 0) for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'] or [0])
    ruta0 = g['rutas'][0]
    estado0 = g['estados'][0] if 'Base' not in g['estados'] else 'Base'
    medidos = [w for w, v in g['por_vp'].items() if v['estado'] == 'MEDIDO']
    v1280 = g['por_vp'].get(1280)
    return dict(
        id=f'C-{i:04d}', modulo=g['scope'], rutas=', '.join(g['rutas'][:4]) + (f' (+{len(g["rutas"]) - 4})' if len(g['rutas']) > 4 else ''), n_rutas=len(g['rutas']),
        pestana=PESTANA.get(ruta0, ruta0), estado=('Base (sin interacción)' if 'Base' in g['estados'] else g['estados'][0]) + (f' (+{len(g["estados"]) - 1} estados)' if len(g['estados']) > 1 else ''),
        nombre=g['nombre'], tipo=g['fam'], contexto=g['ctx'], consumidor=g['cons'], archivo=g['archivo'] or 'no determinado', enlace=ENL(g['archivo']),
        componente=wr or ('<' + g['tag'] + '> nativo' if not g['libMui'] else 'MUI / librería'), variante=g['var'] or '—', tamano=g['size'] or '—',
        libreria=lib, wrapper=wrapper_txt, config=conf, locales=local or '—', layout=seg or '—', n_pantalla=n_pant, etiquetas=g['n_etiquetas'],
        h1280=fmt_vp(g['por_vp'].get(1280)), h820=fmt_vp(g['por_vp'].get(820)), h400=fmt_vp(g['por_vp'].get(400)), h320=fmt_vp(g['por_vp'].get(320)),
        w1280=fmt_vp(g['por_vp'].get(1280), 'w'), contrato=ev['contrato'], origen_medida='navegador (Chrome headless, CDP): getBoundingClientRect/getComputedStyle; contrato: código (compartido.json)',
        clase=ev['clase'], resultado=ev['resultado'], motivo='; '.join(ev['motivos']) or ('Medidas dentro del contrato y sin estilos locales dimensionales ni de color' if ev['resultado'] == 'CUMPLE' else ''),
        fuente_obs=', '.join(g['fuentes']), medidos=len(medidos),
    )


def construir_inventario():
    orden = {m: i for i, m in enumerate(MODULOS + ['Acceso', ESTRUCTURA, 'Compartido (componente reutilizado por varios módulos)', 'Página no encontrada (404)'])}
    gs = sorted(FINAL, key=lambda g: (orden.get(g['scope'], 99), g['fam'], g['cons'], g['nombre']))
    return [fila_inventario(i + 1, g) for i, g in enumerate(gs)], gs
