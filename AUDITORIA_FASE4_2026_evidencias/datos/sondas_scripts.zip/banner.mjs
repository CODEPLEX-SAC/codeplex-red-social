import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', '--remote-debugging-port=9398', `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch('http://127.0.0.1:9398/json')).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

await cdp('Page.enable')
const SONDA = `(() => [...document.querySelectorAll('main *')].filter((e) => String(e.className).includes('border-borde-primario-suave') && String(e.className).includes('bg-fondo-activo-filtro')).map((e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); const ico = e.querySelector('span'); const ri = ico ? ico.getBoundingClientRect() : null; return { clase: String(e.className).slice(0, 170), w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10, pad: [cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft].join(' '), radio: cs.borderTopLeftRadius, borde: cs.borderTopWidth + ' ' + cs.borderTopColor, fondo: cs.backgroundColor, gap: cs.columnGap, icono: ri ? Math.round(ri.width) + 'x' + Math.round(ri.height) : null, tituloFs: (e.querySelector('strong') ? getComputedStyle(e.querySelector('strong')).fontSize : null), cierre: !!e.querySelector('button[aria-label]'), botones: [...e.querySelectorAll('button')].map((b) => Math.round(b.getBoundingClientRect().width) + 'x' + Math.round(b.getBoundingClientRect().height)) } }))()`
const RES = []
for (const ruta of ['/notificaciones', '/notificaciones/no-leidas', '/notificaciones/solicitudes', '/notificaciones/menciones', '/notificaciones/eventos', '/notificaciones/sistema', '/grupos', '/grupos/descubrir', '/colaboradores/perfil', '/colaboradores']) {
  for (const [w, h, mv] of [[1280, 900, false], [400, 850, true]]) {
    await viewport(w, h, mv)
    await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta }); await dormir(4000)
    const b = await evalJS(SONDA)
    RES.push({ ruta, w, banners: b })
  }
}
writeFileSync(SALIDA + '/banner.json', JSON.stringify(RES, null, 1))
ws.close(); chrome.kill(); process.exit(0)
