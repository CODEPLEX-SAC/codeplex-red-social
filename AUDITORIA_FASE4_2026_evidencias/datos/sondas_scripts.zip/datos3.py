import json, collections, re, os
from datos2 import *

EST = json.load(open(SC + r'\au\estatico.json', encoding='utf8'))
EVT = json.load(open(SC + r'\au\evt\evt.json', encoding='utf8'))
FOCO = json.load(open(SC + r'\au\foco_all.json', encoding='utf8'))
IMG = json.load(open(SC + r'\au\emp\cmp\imgdiff.json', encoding='utf8'))
e3 = jsonl(A + r'\e3_1280\estado.jsonl') + jsonl(A + r'\e3_400\estado.jsonl')

TODAS_RUTAS = json.load(open(SC + r'\f3\rutas.json', encoding='utf8'))
RUTAS_APP = [r for r in TODAS_RUTAS if r != '/no-encontrada']


def fam_corta(f):
    return {'Botón': 'Botón', 'Botón con icono': 'Botón con icono', 'Selector / desplegable': 'Selector', 'Selector de fecha/hora': 'Fecha/Hora', 'Campo de texto': 'Campo texto', 'Buscador': 'Buscador',
            'Campo numérico': 'Campo numérico', 'Caja de texto multilínea': 'Multilínea', 'Casilla': 'Casilla/Radio/Interr.', 'Radio': 'Casilla/Radio/Interr.', 'Interruptor': 'Casilla/Radio/Interr.', 'Pestaña': 'Pestañas',
            'Enlace con apariencia de botón': 'Enlace-botón/Chip', 'Chip de filtro (enlace)': 'Enlace-botón/Chip', 'Enlace de texto': 'Enlace de texto', 'Paginación': 'Paginación', 'Ítem de menú': 'Menú',
            'Opción de panel de selector buscable': 'Selector'}.get(f, 'Otros / nativos')


COLUMNAS_FAM = ['Botón', 'Botón con icono', 'Selector', 'Fecha/Hora', 'Campo texto', 'Buscador', 'Campo numérico', 'Multilínea', 'Casilla/Radio/Interr.', 'Pestañas', 'Enlace-botón/Chip', 'Enlace de texto', 'Paginación', 'Menú', 'Otros / nativos']


def reutiliza(g):
    c = g['ev']['clase'] or ''
    if c.startswith('Componente compartido'):
        return 'A'
    if c.startswith('Componente propio que consume'):
        return 'B'
    if c.startswith('Nativo con excepción') or c.startswith('Nativo sin equivalente'):
        return 'E'
    if c.startswith('Librería directa') or c.startswith('Parte interna'):
        return 'D'
    return 'C'


NOMBRE_REUT = {'A': 'Compartido (wrapper CodePlex)', 'B': 'Propio que consume configuración compartida', 'C': 'Propio paralelo / no clasificado', 'D': 'Librería directa', 'E': 'Nativo con excepción registrada / sin equivalente'}


def construir_matriz():
    filas = []
    por_ruta = collections.defaultdict(list)
    for g in FINAL:
        if g['scope'] == ESTRUCTURA:
            continue
        for r in g['rutas']:
            por_ruta[r].append(g)
    visitas_r = collections.defaultdict(set)
    for (r, w, e) in visitas:
        visitas_r[r].add(w)
    est_r = collections.Counter()
    for e in estados:
        if not e['cambioUrl']:
            est_r[e['ruta']] += 1
    for ruta in RUTAS_APP:
        gs = por_ruta.get(ruta, [])
        celdas = {}
        for col in COLUMNAS_FAM:
            sub = [g for g in gs if fam_corta(g['fam']) == col and (ruta in g['rutas'])]
            if not sub:
                celdas[col] = '—'
                continue
            comp = collections.Counter((g['wr'] or '(nativo)') for g in sub)
            res = collections.Counter(g['ev']['resultado'] for g in sub)
            celdas[col] = '; '.join(f'{k} ×{v}' for k, v in comp.most_common(3)) + f"  [{res.get('CUMPLE', 0)}C/{res.get('INCUMPLE', 0)}I/{res.get('NO DETERMINADO', 0)}ND]"
        reut = collections.Counter(reutiliza(g) for g in gs)
        total = sum(reut.values()) or 1
        pct = round(100 * (reut['A'] + reut['B']) / total)
        res = collections.Counter(g['ev']['resultado'] for g in gs)
        vp = sorted(visitas_r[ruta])
        es404 = any(g['cons'] == 'PaginaNoEncontrada' for g in gs)
        if es404:
            est = 'NO VERIFICADO'
        elif res.get('INCUMPLE'):
            est = 'INCUMPLE'
        elif res.get('NO DETERMINADO'):
            est = 'NO DETERMINADO'
        elif gs:
            est = 'CUMPLE'
        else:
            est = 'NO VERIFICADO'
        filas.append(dict(modulo=modulo_de(ruta), pestana=PESTANA.get(ruta, ruta), ruta=ruta, **{c: celdas[c] for c in COLUMNAS_FAM}, grupos=len(gs), reutilizacion=f'{pct} % (A+B) · {reut["A"]}A {reut["B"]}B {reut["C"]}C {reut["D"]}D {reut["E"]}E',
                          viewports=', '.join(str(x) for x in vp) if vp else 'NO VERIFICADO', estados=est_r.get(ruta, 0), cobertura=('LA RUTA MUESTRA LA PÁGINA 404 (no hay página registrada; la pestaña tiene ruta «#»). ' if es404 else '') + ('Base en 4 viewports; ' if len(vp) >= 4 else 'Base parcial; ') + f'{est_r.get(ruta, 0)} estados tras clic (1280/400)', estado=est))
    return filas


def construir_resumen(inv):
    filas = []
    for m in MODULOS + ['Acceso', ESTRUCTURA, 'Compartido (componente reutilizado por varios módulos)', 'Página no encontrada (404)']:
        gs = [g for g in FINAL if g['scope'] == m]
        rutas = [r for r in RUTAS_APP if modulo_de(r) == m] if m in MODULOS + ['Acceso'] else []
        vis = [r for r in rutas if any(v[0] == r for v in visitas)]
        n_est = len({(e['ruta'], e['estado']) for e in estados if modulo_de(e['ruta']) == m and not e['cambioUrl']}) if rutas else 0
        res = collections.Counter(g['ev']['resultado'] for g in gs)
        medidos = sum(1 for g in gs if any(v['estado'] == 'MEDIDO' for v in g['por_vp'].values()))
        inst = sum(max([v.get('n', 0) for v in g['por_vp'].values() if v['estado'] == 'MEDIDO'] or [0]) for g in gs)
        pend = []
        if rutas:
            nv = [r for r in rutas if len({w for (rr, w, e) in visitas if rr == r and e == 'Base'}) < 4]
            if nv:
                pend.append('rutas sin 4 viewports: ' + ', '.join(nv))
        pend.append('estados tras clic solo a 1280 y 400 px; 820 y 320 px: NO VERIFICADO' if rutas else '')
        filas.append(dict(modulo=m, rutas=len(rutas), visitadas=len(vis), estados=n_est, inventariados=len(gs), medidos=medidos, instancias=inst, cumple=res.get('CUMPLE', 0), incumple=res.get('INCUMPLE', 0), nd=res.get('NO DETERMINADO', 0),
                          nv=len(gs) - medidos, pendiente=' · '.join(p for p in pend if p)))
    return filas
