import re, glob, json, os, collections
RAIZ = r'C:\Users\Angie\Documents\CODEPLEX\redSocial\redsocial\frontend'
BS = chr(92)
MOD = {'inicio':'Inicio','actividad':'Actividad','avisos':'Notificaciones','mensajeria':'Mensajes','amigos':'Amigos','grupos':'Grupos','marketplace':'Marketplace','eventos':'Eventos','guardados':'Guardados','colaboradores':'Colaboradores','empresas':'Empresas','dashboard':'Dashboard','estadisticas':'Estadísticas','reportes':'Reportes','indicadores':'Indicadores','acceso':'Acceso','compartido':'Compartido (estructura)'}
COMPS = ['Boton','BotonIcono','BotonPieLista','Selector','SelectorBuscable','SelectorFecha','SelectorHora','CampoTexto','CampoBusqueda','CampoNumero','CampoEtiquetado','Casilla','Radio','Interruptor','Pestanas','Menu']
NAT = ['button','a','input','select','textarea']


def modulo(rel):
    p = rel.split('/')
    if p[0] in ('componentes', 'paginas', 'formularios', 'tablas') and len(p) > 1:
        return MOD.get(p[1], p[1])
    return 'Otros (' + p[0] + ')'


filas = []
libs = collections.defaultdict(set)
for sub in ('componentes', 'paginas', 'formularios', 'tablas'):
    for f in glob.glob(os.path.join(RAIZ, sub, '**', '*.tsx'), recursive=True):
        rel = os.path.relpath(f, RAIZ).replace(BS, '/')
        s = open(f, encoding='utf8').read()
        for m in re.finditer(r"import\s+(?:type\s+)?\{([^}]*)\}\s+from\s+'(@mui/[^']+|@codeplex-sac/[^']+)'", s):
            for n in m.group(1).split(','):
                n = n.strip().split(' as ')[0].strip()
                if n:
                    libs[rel].add(m.group(2) + ':' + n)
        for m in re.finditer(r"import\s+(\w+)\s+from\s+'(@mui/[^']+)'", s):
            libs[rel].add(m.group(2) + ':' + m.group(1))
        for tag in COMPS + NAT:
            for m in re.finditer(r'<' + tag + r'(?=[\s/>])((?:[^<>{}]|\{(?:[^{}]|\{(?:[^{}]|\{[^{}]*\})*\})*\})*)>', s):
                a = m.group(1)

                def val(k):
                    r = re.search(r'\b' + k + r'=(?:"([^"]*)"|\{((?:[^{}]|\{[^{}]*\})*)\})', a)
                    if not r:
                        return None
                    return r.group(1) if r.group(1) is not None else r.group(2)

                line = s[:m.start()].count('\n') + 1
                filas.append(dict(archivo=rel, linea=line, modulo=modulo(rel), tag=tag, nativo=tag in NAT,
                                  variant=val('variant'), size=val('size'), className=val('className'),
                                  type=val('type'), role=val('role'), spread=('{...' in a)))
json.dump(dict(instancias=filas, librerias={k: sorted(v) for k, v in libs.items()}), open('estatico.json', 'w', encoding='utf8'), ensure_ascii=False)
c = collections.Counter((r['modulo'], r['tag']) for r in filas)
mods = sorted({r['modulo'] for r in filas})
tags = COMPS + NAT
print('modulo'.ljust(26), *[t[:7].rjust(8) for t in tags])
for mo in mods:
    print(mo.ljust(26), *[str(c.get((mo, t), 0)).rjust(8) for t in tags])
print(len(filas))
