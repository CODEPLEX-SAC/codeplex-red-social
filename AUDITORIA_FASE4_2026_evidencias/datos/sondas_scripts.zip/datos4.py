import json, collections, os
from datos3 import *

# ---------------------------------------------------------------- paneles (disparador vs panel por separado)
NOM_PANEL = {
    'Select': 'Panel de opciones del Selector (MUI Menu/Popover)',
}


def clave_panel(p):
    c = p['cadena']
    cl = p['clase']
    if p['rol'] == 'dialog' and c[:1] == ['Styled(div)']:
        return 'Modal compartido (diálogo)'
    if p['rol'] is None and 'MuiMenuPaper' in c and 'Paper' not in c[:2]:
        return 'Panel del Selector (MUI Select · Popover)'
    if p['rol'] is None and 'MuiMenuPaper' in c:
        return 'Panel del Menú (CodeplexMenu · MUI Menu)'
    if p['rol'] == 'listbox' and 'MuiMenuList' in c:
        return None
    if 'PanelFiltroFecha' in c:
        return 'Panel Eventos · Fecha (PanelFiltroFecha)'
    if 'PanelFiltroCategoria' in c:
        return 'Panel Eventos · Categoría (PanelFiltroCategoria)'
    if 'PanelFiltroEstado' in c:
        return 'Panel Eventos · Estado (PanelFiltroEstado)'
    if 'PanelFiltroUbicacion' in c:
        return 'Panel Eventos · Ubicación (PanelFiltroUbicacion)'
    if 'PanelFiltrosAvanzadosEmpresas' in c:
        return 'Panel Empresas · Filtros avanzados'
    if 'PanelFiltrosAvanzados' in c:
        return 'Panel Colaboradores · Filtros avanzados'
    if 'PanelSelectorBuscable' in c:
        return 'Panel del SelectorBuscable (selector de empresa)'
    if 'PanelUsuarioTopbar' in c:
        return 'Panel de usuario de la barra superior'
    if 'MuiPickerPopperPaper' in c or 'PopperTooltip' in c:
        return 'Selector emergente de fecha/hora (MUI X)'
    if 'MuiMultiSection' in cl:
        return 'Lista de horas/minutos (MUI X)'
    if p['rol'] == 'tabpanel':
        return None
    return None


def construir_paneles():
    P = collections.defaultdict(lambda: collections.defaultdict(list))
    rutas_p = collections.defaultdict(set)
    for e in estados:
        for p in e['paneles']:
            k = clave_panel(p)
            if not k:
                continue
            P[k][e['w']].append(p)
            rutas_p[k].add(e['ruta'])
    filas = []
    for k in sorted(P):
        for prop, f in (('Ancho', lambda p: p['w']), ('Alto', lambda p: p['h']), ('Radio de borde', lambda p: px_num(p['radio'])), ('Padding (arriba)', lambda p: p['pad'][0]), ('Altura de ítem', lambda p: p['itemH'])):
            cel = {}
            for w in VP:
                ps = P[k].get(w, [])
                if not ps:
                    cel[w] = 'NO VERIFICADO'
                    continue
                vs = [f(p) for p in ps if f(p) is not None]
                cel[w] = rango_txt(vs) if vs else '—'
            if all(v in ('NO VERIFICADO', '—') for v in cel.values()):
                continue
            filas.append(dict(familia='Panel / desplegable (medido por separado del disparador)', variante=k, propiedad=prop, contractual='sin contrato dimensional (panel propio o de librería)' if 'Eventos' in k or 'Filtros' in k or 'Buscable' in k or 'usuario' in k else ('definido en compartido.json: selector_buscable.panel (w-90 = 360 px, rounded-xl)' if 'Buscable' in k else 'sin valor contractual explícito'),
                              fuente_contrato='—', v1280=cel[1280], v820=cel[820], v400=cel[400], v320=cel[320], instancias=sum(len(v) for v in P[k].values()),
                              consumidores=', '.join(sorted(rutas_p[k])[:3]), origen='navegador: getBoundingClientRect / getComputedStyle del elemento del panel', estado='NO DETERMINADO'))
    # paneles de Eventos con 4 viewports (sonda dedicada)
    for filtro in ('Fecha', 'Categoría', 'Ubicación'):
        for prop, clave in (('Ancho', 'w'), ('Alto', 'h')):
            cel = {}
            for w in VP:
                r = next((x for x in EVT if x['w'] == w and x['filtro'] == filtro and x.get('panel')), None)
                cel[w] = f"{r['panel'][clave]:g}" if r else 'NO VERIFICADO'
            filas.append(dict(familia='Panel / desplegable (medido por separado del disparador)', variante=f'Panel Eventos · {filtro} (sonda dedicada, 4 viewports)', propiedad=prop, contractual='sin contrato dimensional',
                              fuente_contrato='—', v1280=cel[1280], v820=cel[820], v400=cel[400], v320=cel[320], instancias=1, consumidores='/eventos', origen='navegador (sonda evt.mjs: panel por id)', estado='NO DETERMINADO'))
        r = [x for x in EVT if x['filtro'] == filtro and x.get('panel')]
        cel = {x['w']: f"{x['panel']['pos']} · radio {x['panel']['radio']}" for x in r}
        filas.append(dict(familia='Panel / desplegable (medido por separado del disparador)', variante=f'Panel Eventos · {filtro} (sonda dedicada, 4 viewports)', propiedad='Posicionamiento / radio', contractual='hoja inferior ≤600 px (fixed, rounded-t-2xl); popover absoluto en >600 px',
                          fuente_contrato='componentes/eventos/bloques/panel_filtro_*.tsx (clases locales)', v1280=cel.get(1280, 'NO VERIFICADO'), v820=cel.get(820, 'NO VERIFICADO'), v400=cel.get(400, 'NO VERIFICADO'), v320=cel.get(320, 'NO VERIFICADO'), instancias=1,
                          consumidores='/eventos', origen='navegador', estado='NO DETERMINADO'))
        des = {x['w']: x['desborde'] for x in r}
        filas.append(dict(familia='Panel / desplegable (medido por separado del disparador)', variante=f'Panel Eventos · {filtro} (sonda dedicada, 4 viewports)', propiedad='Desborde horizontal del documento con el panel abierto', contractual='sin desborde (0)',
                          fuente_contrato='criterio de Responsive del quality gate', v1280='sí' if des.get(1280) else 'no', v820='sí' if des.get(820) else 'no', v400='sí' if des.get(400) else 'no', v320='sí' if des.get(320) else 'no', instancias=1,
                          consumidores='/eventos', origen='navegador (scrollWidth > innerWidth)', estado='INCUMPLE' if any(des.values()) else 'CUMPLE'))
    return filas


def construir_foco():
    filas = []
    for r in FOCO:
        if r['estado'] not in ('normal', 'foco'):
            continue
        filas.append(dict(familia='Campos · estados de foco', variante=f"{r['fam']} ({r['origen']})", propiedad=f"Borde del fieldset en estado «{r['estado']}»", contractual='no definido en compartido.json; --color-foco = var(--color-primario) = #5a43f4',
                          fuente_contrato='montaje_local/index.css (--color-foco)', v1280=(f"{r['bordeFieldset']} · halo {r['sombraFieldset']}" if r['vp'] == 1280 else 'NO VERIFICADO'), v820='NO VERIFICADO', v400=(f"{r['bordeFieldset']} · halo {r['sombraFieldset']}" if r['vp'] == 400 else 'NO VERIFICADO'), v320='NO VERIFICADO',
                          instancias=1, consumidores=r['origen'], origen='navegador (getComputedStyle del fieldset MUI, tras clic)', estado='NO DETERMINADO'))
    return filas
