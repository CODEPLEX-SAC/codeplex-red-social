import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
const require = createRequire('C:/Users/Angie/Documents/CODEPLEX/redSocial/package.json')
const ExcelJS = require('exceljs')

const [, , DATOS, SALIDA, META] = process.argv
const D = JSON.parse(readFileSync(DATOS, 'utf8'))
const M = JSON.parse(readFileSync(META, 'utf8'))
const wb = new ExcelJS.Workbook()
wb.creator = 'Auditoría Fase 4 — CodePlex Red Social'
wb.created = new Date()

const COLOR = { CUMPLE: 'C6EFCE', INCUMPLE: 'FFC7CE', 'NO VERIFICADO': 'FFEB9C', 'NO DETERMINADO': 'D9E1F2', 'NO VISIBLE': 'EDEDED' }
const FUENTE_ENC = { name: 'Calibri', bold: true, color: { argb: 'FFFFFFFF' }, size: 11 }
const ENLACE = { name: 'Calibri', color: { argb: 'FF0563C1' }, underline: true }

function colorDe(v) {
  if (typeof v !== 'string') return null
  const t = v.trim()
  for (const k of ['NO VERIFICADO', 'NO DETERMINADO', 'NO VISIBLE', 'INCUMPLE', 'CUMPLE']) {
    if (t === k || t.startsWith(k + ' ') || t.startsWith(k + ':')) return COLOR[k]
  }
  return null
}

function hoja(nombre, columnas, filas, { inicio = 1, titulo = null, notas = [], congelar = true, filtro = true, colorCols = [] } = {}) {
  const ws = wb.addWorksheet(nombre, { views: [] })
  let fila = 1
  if (titulo) {
    ws.getCell(fila, 1).value = titulo
    ws.getCell(fila, 1).font = { name: 'Calibri', bold: true, size: 14 }
    fila++
  }
  for (const n of notas) {
    ws.getCell(fila, 1).value = n
    ws.getCell(fila, 1).font = { name: 'Calibri', italic: true, size: 10, color: { argb: 'FF444444' } }
    ws.getCell(fila, 1).alignment = { wrapText: false, vertical: 'top' }
    fila++
  }
  if (titulo || notas.length) fila++
  const filaEnc = fila
  columnas.forEach((c, i) => {
    const cell = ws.getCell(filaEnc, i + 1)
    cell.value = c.h
    cell.font = FUENTE_ENC
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF305496' } }
    cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' }
    cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    ws.getColumn(i + 1).width = c.w || 16
  })
  ws.getRow(filaEnc).height = 34
  filas.forEach((r, ri) => {
    const row = ws.getRow(filaEnc + 1 + ri)
    columnas.forEach((c, ci) => {
      const cell = row.getCell(ci + 1)
      let v = r[c.k]
      if (v === undefined || v === null || v === '') v = c.vacio ?? ''
      if (c.enlace && r[c.enlace]) {
        cell.value = { text: String(v), hyperlink: String(r[c.enlace]) }
        cell.font = ENLACE
      } else if (c.link && v) {
        cell.value = { text: String(v).split('/').pop(), hyperlink: String(v) }
        cell.font = ENLACE
      } else {
        cell.value = typeof v === 'number' ? v : String(v)
        cell.font = { name: 'Calibri', size: 10 }
      }
      cell.alignment = { wrapText: true, vertical: 'top', horizontal: c.centro ? 'center' : 'left' }
      cell.border = { top: { style: 'hair' }, left: { style: 'hair' }, bottom: { style: 'hair' }, right: { style: 'hair' } }
      const col = colorDe(v)
      if (col && (c.color || colorCols.includes(c.k))) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + col } }
    })
  })
  if (filtro && filas.length) ws.autoFilter = { from: { row: filaEnc, column: 1 }, to: { row: filaEnc, column: columnas.length } }
  if (congelar) ws.views = [{ state: 'frozen', ySplit: filaEnc, xSplit: 0 }]
  return { ws, filaEnc }
}

// ---------------------------------------------------------------- 1 Resumen general
{
  const cols = [
    { h: 'Módulo', k: 'modulo', w: 34 }, { h: 'Rutas registradas', k: 'rutas', w: 11, centro: true }, { h: 'Rutas visitadas', k: 'visitadas', w: 11, centro: true },
    { h: 'Pestañas/estados revisados tras interacción', k: 'estados', w: 15, centro: true }, { h: 'Controles inventariados (únicos)', k: 'inventariados', w: 14, centro: true },
    { h: 'Controles medidos', k: 'medidos', w: 12, centro: true }, { h: 'Instancias máx. por pantalla', k: 'instancias', w: 13, centro: true },
    { h: 'CUMPLE', k: 'cumple', w: 10, centro: true }, { h: 'INCUMPLE', k: 'incumple', w: 10, centro: true }, { h: 'NO DETERMINADO', k: 'nd', w: 14, centro: true },
    { h: 'No medidos (NO VERIFICADO)', k: 'nv', w: 14, centro: true }, { h: 'Cobertura pendiente', k: 'pendiente', w: 70 },
  ]
  const tot = D.resumen.reduce((a, r) => { for (const k of ['rutas', 'visitadas', 'estados', 'inventariados', 'medidos', 'instancias', 'cumple', 'incumple', 'nd', 'nv']) a[k] = (a[k] || 0) + (r[k] || 0); return a }, { modulo: 'TOTAL (sin doble conteo entre filas)', pendiente: '' })
  const { ws, filaEnc } = hoja('1 Resumen general', cols, [...D.resumen, tot], {})
  ws.getRow(filaEnc + D.resumen.length + 1).font = { name: 'Calibri', bold: true }
  const r0 = filaEnc + D.resumen.length + 4
  ws.getCell(r0 - 1, 1).value = 'Auditoría Fase 4 — Diseño compartido CodePlex Red Social: notas, método y hechos de la medición'
  ws.getCell(r0 - 1, 1).font = { name: 'Calibri', bold: true, size: 14 }
  M.resumen_notas.forEach((n, i) => {
    ws.mergeCells(r0 + 1 + i, 1, r0 + 1 + i, 12)
    ws.getCell(r0 + 1 + i, 1).value = n
    ws.getCell(r0 + 1 + i, 1).alignment = { wrapText: true, vertical: 'top' }
    ws.getCell(r0 + 1 + i, 1).font = { name: 'Calibri', italic: true, size: 10 }
    ws.getRow(r0 + 1 + i).height = 30
  })
  const r0b = r0 + M.resumen_notas.length + 2
  ws.getCell(r0b, 1).value = 'Hechos de la medición'
  ws.getCell(r0, 1).font = { name: 'Calibri', bold: true, size: 12 }
  M.hechos.forEach((h, i) => {
    ws.getCell(r0b + 1 + i, 1).value = h[0]
    ws.getCell(r0b + 1 + i, 1).font = { name: 'Calibri', bold: true, size: 10 }
    ws.getCell(r0b + 1 + i, 1).alignment = { wrapText: true, vertical: 'top' }
    ws.mergeCells(r0b + 1 + i, 2, r0b + 1 + i, 12)
    ws.getCell(r0b + 1 + i, 2).value = String(h[1])
    ws.getCell(r0b + 1 + i, 2).alignment = { wrapText: true, vertical: 'top' }
    ws.getCell(r0b + 1 + i, 2).font = { name: 'Calibri', size: 10 }
    ws.getRow(r0b + 1 + i).height = Math.max(18, 15 * Math.ceil(String(h[1]).length / 150))
  })
}

// ---------------------------------------------------------------- 2 Inventario
hoja('2 Inventario de controles', [
  { h: 'ID', k: 'id', w: 9 }, { h: 'Módulo propietario del código', k: 'modulo', w: 22 }, { h: 'Rutas donde aparece', k: 'rutas', w: 34 }, { h: 'Nº rutas', k: 'n_rutas', w: 8, centro: true },
  { h: 'Pestaña (primera ruta)', k: 'pestana', w: 18 }, { h: 'Estado de la interfaz', k: 'estado', w: 30 }, { h: 'Nombre del control', k: 'nombre', w: 34 }, { h: 'Tipo de control', k: 'tipo', w: 20 },
  { h: 'Contexto', k: 'contexto', w: 13 }, { h: 'Componente consumidor (JSX)', k: 'consumidor', w: 28 }, { h: 'Archivo del consumidor', k: 'archivo', w: 44, enlace: 'enlace' },
  { h: 'Componente usado', k: 'componente', w: 18 }, { h: 'Variante', k: 'variante', w: 13 }, { h: 'Tamaño', k: 'tamano', w: 10 }, { h: 'Librería original', k: 'libreria', w: 32 },
  { h: 'Wrapper CodePlex', k: 'wrapper', w: 34 }, { h: 'Configuración compartida', k: 'config', w: 44 }, { h: 'Estilos locales (dimensionales/color en className)', k: 'locales', w: 30 },
  { h: 'Clases de layout locales (no visuales)', k: 'layout', w: 24 }, { h: 'Instancias máx. en una pantalla', k: 'n_pantalla', w: 11, centro: true },
  { h: 'Altura 1280 px', k: 'h1280', w: 11, color: true, centro: true }, { h: 'Altura 820 px', k: 'h820', w: 11, color: true, centro: true }, { h: 'Altura 400 px', k: 'h400', w: 11, color: true, centro: true }, { h: 'Altura 320 px', k: 'h320', w: 11, color: true, centro: true },
  { h: 'Ancho 1280 px', k: 'w1280', w: 11, centro: true }, { h: 'Contrato de altura (código)', k: 'contrato', w: 22 }, { h: 'Origen de la medida', k: 'origen_medida', w: 40 },
  { h: 'Clase de reutilización', k: 'clase', w: 40 }, { h: 'Resultado', k: 'resultado', w: 16, color: true, centro: true }, { h: 'Motivo / observación', k: 'motivo', w: 70 }, { h: 'Fuente de observación', k: 'fuente_obs', w: 20 },
], D.inventario, { titulo: 'Inventario de controles (una fila por control único; las repeticiones se cuentan en «Instancias»)', notas: M.inventario_notas })

// ---------------------------------------------------------------- 3 Dimensiones
hoja('3 Catálogo de dimensiones', [
  { h: 'Familia', k: 'familia', w: 30 }, { h: 'Variante / tamaño / panel', k: 'variante', w: 46 }, { h: 'Propiedad', k: 'propiedad', w: 26 }, { h: 'Contractual (código)', k: 'contractual', w: 36 }, { h: 'Fuente del contrato', k: 'fuente_contrato', w: 40 },
  { h: '1280 px (navegador)', k: 'v1280', w: 16, color: true, centro: true }, { h: '820 px (navegador)', k: 'v820', w: 16, color: true, centro: true }, { h: '400 px (navegador)', k: 'v400', w: 16, color: true, centro: true }, { h: '320 px (navegador)', k: 'v320', w: 16, color: true, centro: true },
  { h: 'Instancias medidas', k: 'instancias', w: 11, centro: true }, { h: 'Consumidores (muestra)', k: 'consumidores', w: 46 }, { h: 'Origen de la medida', k: 'origen', w: 36 }, { h: 'Estado', k: 'estado', w: 16, color: true, centro: true },
], D.dimensiones, { titulo: 'Catálogo de dimensiones: contractuales (código) y efectivas (navegador), por viewport', notas: M.dimensiones_notas })

// ---------------------------------------------------------------- 4 Matriz
const FAM = ['Botón', 'Botón con icono', 'Selector', 'Fecha/Hora', 'Campo texto', 'Buscador', 'Campo numérico', 'Multilínea', 'Casilla/Radio/Interr.', 'Pestañas', 'Enlace-botón/Chip', 'Enlace de texto', 'Paginación', 'Menú', 'Otros / nativos']
hoja('4 Matriz por módulo', [
  { h: 'Módulo', k: 'modulo', w: 16 }, { h: 'Pestaña / estado', k: 'pestana', w: 26 }, { h: 'Ruta', k: 'ruta', w: 30 },
  ...FAM.map((f) => ({ h: f + ' (componente ×grupos [Cumple/Incumple/ND])', k: f, w: 26 })),
  { h: 'Controles únicos', k: 'grupos', w: 10, centro: true }, { h: 'Grado de reutilización', k: 'reutilizacion', w: 36 }, { h: 'Viewports medidos (base)', k: 'viewports', w: 22 }, { h: 'Estados tras clic', k: 'estados', w: 10, centro: true },
  { h: 'Cobertura', k: 'cobertura', w: 50 }, { h: 'Estado de auditoría', k: 'estado', w: 18, color: true, centro: true },
], D.matriz, { titulo: 'Matriz por módulo y pestaña (A=compartido, B=propio con configuración compartida, C=paralelo, D=librería directa, E=nativo con excepción)', notas: M.matriz_notas })

// ---------------------------------------------------------------- 5 Escalabilidad
hoja('5 Escalabilidad', [
  { h: 'Componente / patrón', k: 'componente', w: 34 }, { h: 'Fuente de verdad', k: 'fuente', w: 50 }, { h: 'Configuración y tokens que consume', k: 'config', w: 56 }, { h: 'Módulos consumidores (medidos)', k: 'modulos', w: 40 },
  { h: 'Controles únicos medidos', k: 'grupos', w: 11, centro: true }, { h: 'Sitios JSX (estático)', k: 'sitios_jsx', w: 10, centro: true }, { h: 'Con estilos locales (nº)', k: 'locales', w: 10, centro: true }, { h: 'Consumidores con estilos locales', k: 'consumidores_locales', w: 44 },
  { h: 'Cambios que se propagan automáticamente', k: 'propaga', w: 52 }, { h: 'Cambios que requieren editar consumidores', k: 'individuales', w: 50 }, { h: 'Patrones duplicados que podrían centralizarse', k: 'centralizable', w: 56 },
], D.escalabilidad, { titulo: 'Escalabilidad del sistema de diseño compartido', notas: M.escalabilidad_notas })

// ---------------------------------------------------------------- 6 Incidencias
hoja('6 Incidencias', [
  { h: 'ID', k: 'id', w: 9 }, { h: 'Prioridad', k: 'prioridad', w: 10, centro: true }, { h: 'Título', k: 'titulo', w: 44 }, { h: 'Evidencia', k: 'evidencia', w: 80 }, { h: 'Ruta(s)', k: 'rutas', w: 34 }, { h: 'Archivo(s)', k: 'archivo', w: 56, enlace: 'enlace' },
  { h: 'Causa', k: 'causa', w: 48 }, { h: 'Recomendación', k: 'recomendacion', w: 56 }, { h: 'Alcance', k: 'alcance', w: 24 }, { h: 'Riesgo', k: 'riesgo', w: 26 }, { h: 'Tipo de corrección', k: 'tipo', w: 24 }, { h: 'Verificación', k: 'verificacion', w: 34 },
], D.incidencias, { titulo: 'Incidencias priorizadas (P1 = defecto visible demostrado; P2 = patrón paralelo o sobrescritura local; P3 = decisión de diseño)', notas: M.incidencias_notas })

// ---------------------------------------------------------------- 7 Regresión Empresas
hoja('7 Regresión Empresas', [
  { h: 'Nivel', k: 'nivel', w: 24 }, { h: 'Ruta', k: 'ruta', w: 12 }, { h: 'Ancho (px)', k: 'ancho', w: 9, centro: true }, { h: 'Elemento / clave de firma', k: 'elemento', w: 44 }, { h: 'Campo', k: 'campo', w: 12 },
  { h: 'Captura de referencia', k: 'ref', w: 18, link: true }, { h: 'Captura actual', k: 'act', w: 18, link: true }, { h: 'Lado a lado', k: 'lado', w: 18, link: true }, { h: 'Imagen de diferencias', k: 'dif', w: 18, link: true },
  { h: 'Antes (referencia / línea base)', k: 'antes', w: 46 }, { h: 'Después (actual)', k: 'despues', w: 46 }, { h: 'Píxeles', k: 'pixeles', w: 24 }, { h: 'Origen probable en código', k: 'origen', w: 56 },
  { h: 'Clasificación', k: 'clasificacion', w: 34, color: true }, { h: 'Evidencia', k: 'evidencia', w: 52 }, { h: 'Dictamen / observación', k: 'dictamen', w: 64 },
], D.empresas, { titulo: 'Regresión Empresas: /empresas en los seis anchos del gate (1280, 1024, 768, 600, 390 y 320 px)', notas: M.empresas_notas })

// ---------------------------------------------------------------- 8 Pendientes
hoja('8 Pendientes y excepciones', [
  { h: 'Tipo', k: 'tipo', w: 34 }, { h: 'Elemento', k: 'elemento', w: 44 }, { h: 'Ruta(s)', k: 'ruta', w: 30 }, { h: 'Detalle', k: 'detalle', w: 80 }, { h: 'Motivo / fuente', k: 'motivo', w: 56 }, { h: 'Estado', k: 'estado', w: 16, color: true, centro: true }, { h: 'Acción recomendada', k: 'accion', w: 40 },
], D.pendientes, { titulo: 'Pendientes, estados no recorridos, excepciones justificadas y decisiones de diseño', notas: M.pendientes_notas })

await wb.xlsx.writeFile(SALIDA)
console.log('escrito', SALIDA)
