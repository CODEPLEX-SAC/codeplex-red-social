import json, collections, os, re
from datos6 import *


def construir_pendientes(inv):
    filas = []

    def add(tipo, elemento, ruta, detalle, motivo, estado, accion):
        filas.append(dict(tipo=tipo, elemento=elemento, ruta=ruta, detalle=detalle, motivo=motivo, estado=estado, accion=accion))

    # 1. excepciones registradas (botones nativos)
    for f, r in sorted(REGISTRO.items()):
        if f.startswith('componentes/compartido/interfaz/boton'):
            continue
        add('Excepción justificada (registro de pruebas)', f'<button> nativo ×{r["cantidad"]}', '—', f"Clase {r['clase']}: {r['motivo']}", f'pruebas/compartido/registro_componentes_permitidos.ts · archivo {f}', 'CUMPLE' if r['clase'] in ('A', 'B') else 'NO DETERMINADO', 'Mantener o decidir patrón compartido (clases C, F, G)' if r['clase'] not in ('A', 'B') else 'Mantener')
    # 2. viewport/estados
    add('Estado no recorrido', 'Estados tras clic a 820 y 320 px', 'todas', 'La exploración por interacción se ejecutó a 1280 y 400 px; a 820 y 320 px solo se midió el estado base', 'Tiempo/alcance de la sonda', 'NO VERIFICADO', 'Repetir la exploración con la misma sonda a 820 y 320 px')
    add('Estado no recorrido', 'Segundo nivel de interacción solo a 1280 px', 'Empresas, Colaboradores, Eventos, Marketplace, Inicio, Mensajes, Dashboard, Reportes, Guardados, Indicadores, Amigos, Grupos, Notificaciones', 'Modales y paneles abiertos se exploraron un nivel más (selectores, pestañas e interruptores internos) únicamente a 1280 px; no se recorrieron pasos de asistentes ni terceros niveles', 'Alcance de la sonda', 'NO VERIFICADO', 'Ampliar sonda a 400 px y a pasos de asistente')
    add('Estado no recorrido', 'Estados de error de validación de formularios', 'Empresas > Nueva empresa; Eventos > Crear evento; Colaboradores > Invitar', 'Al enviar vacío no apareció ningún elemento con aria-invalid ni .Mui-error (0 campos con error) en los tres formularios probados', 'No se reprodujo validación visible con envío vacío', 'NO VERIFICADO', 'Reproducir con datos inválidos concretos')
    add('Estado no recorrido', 'Mensaje de estado vacío tras búsqueda sin resultados', 'Amigos, Eventos, Grupos > Invitaciones, Guardados, Marketplace, Mensajes (5 rutas)', 'Se escribió una cadena sin coincidencias en 12 buscadores: solo Colaboradores y Empresas mostraron un mensaje de vacío; en el resto no apareció texto de estado vacío ni controles nuevos', 'El buscador puede no filtrar o el texto de vacío difiere del patrón buscado', 'NO DETERMINADO', 'Revisar si cada buscador filtra la lista')
    add('Estado no recorrido', 'Estados hover, active, disabled y teclado', 'todas', 'No se midieron estilos de hover/active/disabled ni recorrido con teclado o lector de pantalla (salvo atributos aria ya verificados en Eventos y Dashboard en la fase anterior)', 'Fuera del alcance de la sonda de dimensiones', 'NO VERIFICADO', 'Fase específica de accesibilidad')
    add('Ruta no medida', '/no-encontrada (404)', '/no-encontrada', 'No se visitó directamente; su único botón («Volver a Inicio») se midió a través de /notificaciones/sistema, que la renderiza', 'Alcance', 'NO VERIFICADO', 'Añadir /no-encontrada al barrido')
    add('Ruta sin página', 'Pestaña «Sistema» de Notificaciones', '/notificaciones/sistema', 'La ruta está declarada pero muestra la página 404; la pestaña usa la ruta «#»', 'Ruta no registrada en rutas.tsx', 'NO VERIFICADO', 'Registrar la página o retirar la pestaña')
    add('Ruta no medida', 'Acceso (/acceso) tras iniciar sesión', '/acceso', 'Solo la pantalla de acceso; modo «Crear cuenta» y confirmación de correo no se recorrieron con interacción completa', 'Alcance', 'NO VERIFICADO', 'Recorrer con datos de demostración')
    add('Control no medido', 'Selector buscable abierto con búsqueda', 'barra superior', 'Se midió el panel abierto, no los estados «sin resultados» ni el foco por teclado', 'Alcance', 'NO VERIFICADO', '—')
    add('Control no medido', 'Foco y error de Buscador, Casilla, Radio, Interruptor', 'varias', 'Foco medido solo para CampoTexto, Selector, SelectorFecha/Hora, CampoNumero y multilínea; error medido en ninguno (no se reprodujo)', 'Alcance', 'NO VERIFICADO', '—')
    add('Control no medido', 'Elementos fuera de pantalla o con scroll interno', 'listas largas', 'Solo se miden los controles renderizados en el DOM en el momento de la captura', 'Método', 'NO VERIFICADO', '—')
    # 3. decisiones de diseño
    for t, d in (('Color primario de MUI', 'Foco, pestañas y barra lateral usan #7c3aed; botones usan #5a43f4'), ('Alturas de la barra superior', 'Header 72 px; selector de empresa 48; BotonIcono 32; campana 36; menú de usuario 40'), ('Píldoras de Inicio', 'Boton filtro + mini + rounded-full (5 botones)'), ('Patrones especiales', 'Controles de videollamada (clase G), tarjetas punteadas (F), filas de opción (C), control segmentado de Eventos'), ('Selector mini/integrado', 'Altura 40 px sin contrato'), ('Desplegables simulados con Boton', 'Reemplazar por Selector o quitar chevron'), ('Estado de foco único', 'Borde/halo/color de foco para todas las familias'), ('Calendario de Eventos y licencia', 'CodeplexSelectorRangoFecha depende de MUI X Pro (licencia comercial): no se sustituye el calendario propio sin autorización')):
        add('Decisión de diseño pendiente', t, '—', d, 'Requiere decisión de la usuaria', 'NO DETERMINADO', 'Decidir antes de la fase de corrección')
    return filas


def ensamblar():
    inv, gs = construir_inventario()
    dims = construir_dimensiones() + construir_paneles() + construir_foco()
    matriz = construir_matriz()
    esc = construir_escalabilidad()
    inc = construir_incidencias()
    emp = construir_empresas()
    pend = construir_pendientes(inv)
    res = construir_resumen(inv)
    return dict(inventario=inv, dimensiones=dims, matriz=matriz, escalabilidad=esc, incidencias=inc, empresas=emp, pendientes=pend, resumen=res)


if __name__ == '__main__':
    D = ensamblar()
    # comprobar existencia de archivos citados
    faltan = set()
    for fila in D['incidencias']:
        for tok in re.split(r'[;,]\s*', fila['archivo']):
            tok = tok.strip()
            if tok.startswith(('componentes/', 'paginas/', 'formularios/')) and not tok.endswith('/*.tsx') and '*' not in tok and not os.path.exists(os.path.join(FRONT, tok.replace('/', os.sep))):
                faltan.add(tok)
    print('archivos inexistentes citados:', sorted(faltan))
    for k, v in D.items():
        print(k, len(v))
    json.dump(D, open(SC + r'\au\datos.json', 'w', encoding='utf8'), ensure_ascii=False)
