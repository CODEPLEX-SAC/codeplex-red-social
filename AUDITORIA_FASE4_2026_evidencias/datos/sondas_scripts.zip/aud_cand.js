window.__aud = (() => {
  const SEL = 'button, [role=button], [role=tab], [role=combobox], [role=switch], input[type=checkbox], input[type=radio], select'
  const norm = (s) => (s || '').split(/[ \n\t ]+/).join(' ').trim().slice(0, 60)
  const nombre = (e) => norm(e.getAttribute('aria-label') || e.textContent || e.getAttribute('title'))
  const rolDe = (e) => e.getAttribute('role') || e.tagName.toLowerCase()
  const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' }
  const filtro = (e, modo) => {
    if (!vis(e)) return false
    if (e.tagName === 'INPUT' && e.classList.contains('MuiSelect-nativeInput')) return false
    if (modo === 'overlay') return !!e.closest('[role=dialog], .MuiPopover-root, .MuiPopper-root, [role=menu], [role=listbox]')
    if (modo === 'shell') return !!e.closest('header') && !e.closest('aside')
    return !e.closest('aside, header, nav')
  }
  return {
    lista(modo) {
      const out = []; const visto = new Set()
      for (const e of document.querySelectorAll(SEL)) {
        if (!filtro(e, modo) || e.disabled || e.getAttribute('aria-disabled') === 'true') continue
        const n = nombre(e); const rol = rolDe(e); const k = rol + '|' + n
        if (visto.has(k)) continue
        visto.add(k); out.push({ n, rol })
      }
      return out
    },
    pos(n, rol, modo) {
      const e = [...document.querySelectorAll(SEL)].find((x) => filtro(x, modo) && nombre(x) === n && rolDe(x) === rol)
      if (!e) return null
      e.scrollIntoView({ block: 'center' })
      const r = e.getBoundingClientRect()
      return { x: r.x + r.width / 2, y: r.y + r.height / 2 }
    },
  }
})()
