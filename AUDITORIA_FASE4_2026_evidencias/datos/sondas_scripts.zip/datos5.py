import json, collections, os, re
from datos4 import *

BASE_VIS = json.load(open(RAIZ + r'\herramientas\validacion\linea_base_visual\roles.json', encoding='utf8'))
ACT_VIS = json.load(open(SC + r'\au\emp\act\roles.json', encoding='utf8'))
REF_VIS = json.load(open(SC + r'\au\emp\ref\roles.json', encoding='utf8'))
ESTIL = json.load(open(SC + r'\au\emp\estilos\emp_estilos.json', encoding='utf8'))
ANCHOS_EMP = [1280, 1024, 768, 600, 390, 320]
EV_DIR = 'AUDITORIA_FASE4_2026_evidencias/empresas/'


def dif_dict(b, a):
    out = []
    for k in sorted(set(b) | set(a)):
        if b.get(k) != a.get(k):
            out.append((k, b.get(k), a.get(k)))
    return out


def clasifica_firma(campo, k, b, a):
    ks = k.lower()
    if campo == 'botones' and k.startswith('main|14px/600') and ('h48' in k or 'h38' in k or 'h34' in k):
        return ('INTENCIONAL (aprobada)', 'Fase 2: Boton md de 48 px también en móvil (antes 38/34 px)', 'diferencias_aceptadas_linea_base.md (2026-10-17) · compartido.json boton_tamanos.md = min-h-control', 'boton_tamanos.md → min-h-control; empresas: filtros_empresas.tsx / pagina_empresas.tsx')
    if campo == 'campos' and k.startswith('main|'):
        return ('INTENCIONAL (aprobada)', 'Fase 2: --control-height 48 px en CampoTexto/CampoBusqueda/Selector (antes 40 px)', 'diferencias_aceptadas_linea_base.md (2026-10-17)', 'compartido.json controles.campo_texto/selector_libreria minHeight var(--height-control)')
    if campo == 'campos' and k.startswith('shell|'):
        return ('INTENCIONAL (aprobada)', 'Buscador superior pasa a 48 px (CampoBusqueda, --control-height)', 'diferencias_aceptadas_linea_base.md (2026-10-17)', 'campo_busqueda.tsx → CampoTexto (controles.campo_texto)')
    if campo == 'botones' and k.startswith('shell|') and ('h52' in k or 'h48' in k):
        return ('INTENCIONAL (aprobada)', 'Selector de empresa de la barra superior de 48 px (antes 52 px) con RUC oculto', 'diferencias_aceptadas_linea_base.md (2026-10-17)', 'selector_empresa_topbar.tsx → SelectorBuscable (selector_buscable.disparador h-control)')
    if campo == 'agg' and 'RUC' in json.dumps(b if b else a, ensure_ascii=False):
        return ('INTENCIONAL (aprobada)', 'RUC oculto en el selector de empresa cerrado', 'diferencias_aceptadas_linea_base.md (2026-10-17)', 'selector_empresa_topbar.tsx')
    if campo == 'iconBtn' and k.startswith('shell') and ('caja 32x32|glifo 20' in k or 'caja 28x28|glifo 18' in k):
        return ('INTENCIONAL (aprobada)', 'Botón de carrito en la barra superior (7 botones de icono en vez de 6)', 'diferencias_aceptadas_linea_base.md (2026-10-17)', 'barra_superior.tsx + boton_carrito_topbar.tsx (nuevo)')
    if campo == 'iconBtn' and 'glifo 15' in k:
        return ('CAMBIO NO REGISTRADO (causa demostrada)', 'Botón «Agregar módulo» de la barra lateral: 23x24 → 24x24. El encabezado «MÓDULOS DISPONIBLES» ya no se parte en 2 líneas porque el tema MUI pasó de Roboto a la fuente heredada (font-family medida: Roboto → Inter/system-ui; alto del encabezado 39,8 → 24 px)', 'emp_estilos / emp_head (computed style en ambas versiones)', 'proveedor_tema_graficos.tsx: typography: fuente_heredada (añadido tras la línea base)')
    return ('NO DETERMINADA', 'Diferencia sin atribución demostrada', '—', '—')


def construir_empresas():
    filas = []
    for w in ANCHOS_EMP:
        k = f'{w}|/empresas'
        img = next((x for x in IMG if x['w'] == w), None)
        b, a = BASE_VIS[k], ACT_VIS[k]
        sig_ok_ref = json.dumps([REF_VIS[k][c] for c in ('agg', 'campos', 'iconBtn', 'botones')], sort_keys=True) == json.dumps([b[c] for c in ('agg', 'campos', 'iconBtn', 'botones')], sort_keys=True)
        items = []
        for campo in ('agg', 'campos', 'iconBtn', 'botones'):
            for kk, vb, va in dif_dict(b[campo], a[campo]):
                vbs = json.dumps(vb, ensure_ascii=False) if vb is not None else '(ausente)'
                vas = json.dumps(va, ensure_ascii=False) if va is not None else '(ausente)'
                cl = clasifica_firma(campo, kk, vb, va)
                items.append((campo, kk, vbs, vas, cl))
        n_int = sum(1 for i in items if i[4][0].startswith('INTENCIONAL'))
        n_nr = sum(1 for i in items if i[4][0].startswith('CAMBIO NO REGISTRADO'))
        n_nd = sum(1 for i in items if i[4][0] == 'NO DETERMINADA')
        h1, h2 = (img['h1'], img['h2']) if img else (None, None)
        filas.append(dict(nivel='Página (resumen)', ruta='/empresas', ancho=w, elemento='Página completa', campo='—',
                          ref=EV_DIR + f'ref/empresas_{w}_completa.png', act=EV_DIR + f'act/empresas_{w}_completa.png', lado=EV_DIR + f'cmp/empresas_{w}_lado_a_lado.png', dif=EV_DIR + f'cmp/empresas_{w}_diferencias.png',
                          antes=f'alto de documento {h1} px', despues=f'alto de documento {h2} px (Δ {h2 - h1:+d} px)' if img else '—', pixeles=f"{img['pct']} % de píxeles distintos (umbral 30/765 por canal)" if img else '—',
                          origen='Ver filas de detalle', clasificacion=f'{n_int} intencionales · {n_nr} no registrado(s) · {n_nd} no determinada(s)', evidencia='La firma de la versión de referencia (commit a2b857e renderizado) coincide con roles.json en este ancho: ' + ('SÍ' if sig_ok_ref else 'NO'),
                          dictamen='REGRESIÓN POR DIFERENCIAS REGISTRADAS Y 1 NO REGISTRADA: sin defecto visual confirmado; requiere decisión de aceptación' if n_nr or n_nd else 'REGRESIÓN POR DIFERENCIAS INTENCIONALES REGISTRADAS: sin defecto visual confirmado'))
        for campo, kk, vbs, vas, cl in items:
            filas.append(dict(nivel='Diferencia de firma', ruta='/empresas', ancho=w, elemento=kk, campo=campo, ref='', act='', lado='', dif='', antes=vbs[:300], despues=vas[:300], pixeles='', origen=cl[3], clasificacion=cl[0], evidencia=cl[2], dictamen=cl[1]))
    # diferencias de estilo calculado (ambas versiones renderizadas)
    for w in (1280, 390):
        for r, c in zip(ESTIL[f'ref|{w}'], ESTIL[f'act|{w}']):
            if r.get('ausente') or c.get('ausente'):
                continue
            d = {k: (r[k], c[k]) for k in r if k not in ('nombre', 'x', 'y') and r[k] != c[k]}
            if not d:
                continue
            ls = 'ls' in d
            filas.append(dict(nivel='Diferencia de estilo calculado', ruta='/empresas', ancho=w, elemento=r['nombre'], campo='getComputedStyle', ref='', act='', lado='', dif='', antes='; '.join(f'{k}={v[0]}' for k, v in d.items()), despues='; '.join(f'{k}={v[1]}' for k, v in d.items()), pixeles='',
                              origen=('proveedor_tema_graficos.tsx: typography.fontFamily=inherit (letter-spacing 0.15px de la tipografía MUI desaparece)' if ls and 'h' not in d else ('Fase 2 (--control-height 48 px)' if 'h' in d else 'ajuste de maquetación')),
                              clasificacion=('CAMBIO NO REGISTRADO (efecto colateral del tema)' if ls and 'h' not in d else ('INTENCIONAL (aprobada)' if 'h' in d else 'NO DETERMINADA')),
                              evidencia='sonda emp_estilos.mjs: ambas versiones renderizadas (a2b857e frente al árbol de trabajo)', dictamen='letter-spacing 0,15 px → normal en campos MUI: no figura en las diferencias aceptadas' if ls and 'h' not in d else ''))
    filas.append(dict(nivel='Diferencia de estilo calculado', ruta='/empresas', ancho=1280, elemento='Barra superior (header)', campo='getComputedStyle', ref='', act='', lado='', dif='', antes='h=64 px (h-16)', despues='h=72 px (h-18)', pixeles='',
                      origen='barra_superior.tsx: h-16 → h-18 (junto a SelectorEmpresaTopbar)', clasificacion='CAMBIO NO REGISTRADO', evidencia='git diff a2b857e -- barra_superior.tsx; medida en ambas versiones', dictamen='Explica +8 px en el desplazamiento vertical de toda la página; no figura en diferencias_aceptadas_linea_base.md'))
    filas.append(dict(nivel='Diferencia de estilo calculado', ruta='/empresas', ancho=1280, elemento='Encabezado «MÓDULOS DISPONIBLES» (barra lateral)', campo='getComputedStyle', ref='', act='', lado='', dif='', antes='font-family Roboto, Helvetica, Arial; alto 39,8 px (2 líneas)', despues='font-family Inter, ui-sans-serif, system-ui; alto 24 px (1 línea)', pixeles='',
                      origen='proveedor_tema_graficos.tsx: typography: fuente_heredada (MUI Typography deja de usar Roboto)', clasificacion='CAMBIO NO REGISTRADO (causa demostrada)', evidencia='sonda emp_head.mjs (ambas versiones renderizadas)', dictamen='Cambio de tipografía en todo componente MUI Typography (barra lateral, pestañas, menús): intencional según proveedor_tema_graficos.md, no listado como diferencia aceptada'))
    return filas


def contar_consumidores(wr):
    return sorted({g['scope'] for g in FINAL if g['wrapper'] == wr})


def stats(wr):
    gs = [g for g in FINAL if g['wrapper'] == wr]
    return gs, sum(1 for g in gs if g['ev']['dim'] or g['ev']['otros']), sorted({g['cons'] for g in gs if (g['ev']['dim'] or g['ev']['otros'])})


def sitios_estaticos(tag):
    c = collections.Counter(r['modulo'] for r in EST['instancias'] if r['tag'] == tag)
    return dict(c), sum(c.values())


ESC = [
    ('Boton', 'Boton + clasesBoton', 'componentes/compartido/interfaz/boton.tsx; tipos/compartido/contrato_boton.ts', 'compartido.json: boton_base, boton_medio, boton_tamanos, boton_tamanos_medios, boton_variantes, boton_activo, boton_icono_por_tamano, boton_icono_clases · index.css: --control-height, --text-boton, --text-boton-mini, --text-chip, --spacing-sm, --radius-7',
     'Alturas por tamaño, padding, radio, tipografía, colores por variante, tamaño de icono (se propagan a todo <Boton> y a los <a> que usan clasesBoton)', 'Consumidores con className dimensional o de color (ver columna de estilos locales); botones nativos con excepción registrada', 'Variante compacta de enlace (gap/p/border locales ×3 en Eventos); combinación filtro+mini+rounded-full en Inicio; pestañas hechas con Boton en TabsTipoPlanes'),
    ('BotonIcono', 'BotonIcono', 'componentes/compartido/interfaz/boton_icono.tsx; contrato_boton_icono.ts', 'compartido.json: boton_icono_base, boton_icono_variantes, boton_icono_tamanos',
     'Tamaños 32/28 (default), 24 (sm), 28 (md), iconos 18/14, radios por variante', 'Consumidores con color propio (sobre fondo oscuro, destructivo) en lugar de variante', 'Variante sobre_oscuro existente re-implementada a mano; falta variante destructiva'),
    ('BotonPieLista', 'BotonPieLista', 'componentes/compartido/interfaz/boton_pie_lista.tsx', 'compartido.json: boton_pie_lista (envuelve Boton enlace/pie_lista)',
     'Aspecto de «Cargar más» de lista', 'Notificaciones > Menciones usa Boton secundario md en su lugar', 'Unificar «Cargar más» (BotonPieLista) y enlaces con borde superior escritos a mano'),
    ('Selector', 'Selector', 'componentes/compartido/interfaz/selector.tsx; contrato_selector.ts', 'compartido.json: selector_libreria, selector_envoltorio, selector_label, selector_atributo_accesible · proveedor_tema_graficos.tsx (MUI)',
     'Altura 48 px (default/colaboradores), radio, borde, foco, panel (MUI Menu)', 'Variante mini (40 px sin contrato) e integrado: altura no definida en el catálogo', 'Pseudo-selectores hechos con Boton secundario + chevron (4 sitios medidos) deberían usar Selector'),
    ('SelectorBuscable', 'SelectorBuscable (+ PanelSelectorBuscable, ListaOpcionesBuscables)', 'componentes/compartido/interfaz/selector_buscable.tsx, panel_selector_buscable.tsx, lista_opciones_buscables.tsx', 'compartido.json: selector_buscable, selector_empresa',
     'Disparador 48 px, panel 360 px, filas', 'Único consumidor: selector de empresa de la barra superior', 'Candidato a base del filtro desplegable de Eventos (disparador + panel)'),
    ('SelectorFecha', 'SelectorFecha / SelectorHora', 'componentes/compartido/interfaz/selector_fecha.tsx, selector_hora.tsx', 'compartido.json: controles.selector_fecha, controles.selector_hora · @codeplex-sac/selectores-fecha (MUI X)',
     'Altura 48 px del campo', 'Estados de foco distintos a CampoTexto (sin halo)', 'Foco del campo de fecha/hora y calendario emergente con tema MUI propio'),
    ('CampoTexto', 'CampoTexto / CampoBusqueda / CampoNumero', 'componentes/compartido/interfaz/campo_texto.tsx, campo_busqueda.tsx, campo_numero.tsx', 'compartido.json: controles.campo_texto, campo_texto_editor, campo_numero, tipo_busqueda, atributo_accesible · proveedor_tema_graficos.tsx',
     'Altura 48 px, padding vertical, placeholder, foco (tema MUI)', 'Anchos locales (w-*, max-*), editor de publicación (campo_texto_editor)', 'CampoNumero: borde normal 0,26 alfa y foco de 1 px frente a 2 px + halo del resto'),
    ('Pestanas', 'Pestanas', 'componentes/compartido/interfaz/pestanas.tsx', 'compartido.json: pestanas, pestanas_tema · @codeplex-sac/navegacion (MUI Tab)',
     'Alto mínimo 40 px, tipografía, padding por breakpoint', 'Pestañas de los modales de Empresas con px-6 local', 'Pestañas hechas con Boton (TabsTipoPlanes) y SelectorModoAcceso nativo'),
    ('Casilla', 'Casilla / Radio / Interruptor', 'componentes/compartido/interfaz/casilla.tsx, radio.tsx, interruptor.tsx', 'compartido.json: controles.casilla_tamano, radio, interruptor',
     'Tamaño pequeño, color primario del tema', 'Ninguno detectado con className', 'Color de foco/seleccionado procede del tema MUI (#7c3aed)'),
    ('Menu', 'Menu', 'componentes/compartido/interfaz/menu.tsx', 'compartido.json: menu, elemento_menu_tema', 'Panel y filas de menú (radio 4 px frente a 12 px del panel del Selector)', 'Ninguno detectado', 'Unificar radio de paneles Menu/Selector'),
]


def construir_escalabilidad():
    filas = []
    for clave, nombre, fuente, config, propaga, local_txt, central in ESC:
        gs, n_loc, cons_loc = stats(clave)
        mods = contar_consumidores(clave)
        sitios, total = sitios_estaticos(clave if clave != 'CampoTexto' else 'CampoTexto')
        filas.append(dict(componente=nombre, fuente=fuente, config=config, tokens='ver configuración', modulos=', '.join(mods) or '—', grupos=len(gs), sitios_jsx=total, locales=n_loc, consumidores_locales=', '.join(cons_loc[:8]) + (f' (+{len(cons_loc) - 8})' if len(cons_loc) > 8 else '') if cons_loc else '—',
                          propaga=propaga, individuales=local_txt, centralizable=central))
    # clases compartidas en <a>
    gs = [g for g in FINAL if g['nat'] in ('boton', 'boton_pie')]
    ch = [g for g in FINAL if g['nat'] == 'chip']
    filas.append(dict(componente='clasesBoton (enlaces <a> con apariencia de botón)', fuente='componentes/compartido/interfaz/boton.tsx (clasesBoton)', config='compartido.json: boton_*', tokens='igual que Boton', modulos=', '.join(sorted({g['scope'] for g in gs})), grupos=len(gs), sitios_jsx=len(gs), locales=0, consumidores_locales='—',
                      propaga='Cambios en boton_* se propagan a estos enlaces', individuales='Ninguno detectado', centralizable='—'))
    filas.append(dict(componente='clasesChip / clasesConteoChip (chips de filtro)', fuente='componentes/compartido/interfaz/chip_filtro.ts', config='compartido.json: chip_filtro', tokens='--text-navegacion, --radius-20', modulos=', '.join(sorted({g['scope'] for g in ch})), grupos=len(ch), sitios_jsx=len(ch),
                      locales=sum(1 for g in ch if g['ev']['resultado'] == 'INCUMPLE'), consumidores_locales=', '.join(sorted({g['cons'] for g in ch if g['ev']['resultado'] == 'INCUMPLE'})) or '—', propaga='Altura 32 px, borde, color activo/inactivo', individuales='Chips de Mensajes con padding 8 px', centralizable='Chip de filtro como componente (hoy solo clases)'))
    # patrones sin componente compartido
    extra = [
        ('Filtro desplegable de Eventos (disparador + estado + panel)', 'No existe: lógica repetida en bloque_categoria.tsx (Fecha, Categoría), bloque_eventos_para_ti1.tsx (Ubicación), seccion_eventos_organizas.tsx (Estado)', 'Disparador: Boton filtro (compartido); panel: clases locales absolute left-0 top-tooltip z-20 … rounded-xl border shadow-t13; FondoPanelFlotante compartido', '—', 'Eventos', 'Cambios del disparador se propagan (Boton); marco del panel y aria NO se propagan', 'Cada filtro repite estado abierto/cerrado, aria-expanded/aria-controls y marco del panel', 'Wrapper FiltroDesplegable (disparador Boton filtro + apertura/cierre + marco de panel + hoja inferior ≤600 px) con contenido propio; no sustituir calendario ni mapa'),
        ('Banner informativo', 'No existe: bloque duplicado en banner_info_aviso.tsx, seccion_datos_del_colaborador2.tsx, seccion_descubrir.tsx, pagina_grupos_mis_grupos.tsx', 'clases locales rounded-xl border-borde-primario-suave bg-fondo-activo-filtro p-3.5', '—', 'Notificaciones, Colaboradores, Grupos', 'Nada', 'Cuatro copias del mismo contenedor', 'Componente BannerInformativo (icono, título, descripción, cierre con BotonIcono sm)'),
        ('Tema MUI (color primario/foco)', 'componentes/compartido/proveedor_tema_graficos.tsx', 'createTheme con palette.primary.main = colores_graficos.primario (#7c3aed, paleta de gráficos); el sistema usa --color-primario #5a43f4', 'index.css --color-primario/--color-foco', 'Todos los módulos con componentes MUI', 'Un único cambio de palette.primary.main (colores_graficos.primario) actualizaría foco, casillas, pestañas, barra lateral', 'Ninguno (es centralizado)', 'Decisión de diseño: alinear palette.primary con --color-primario'),
    ]
    for comp, fuente, config, tokens, mods, prop, indiv, centr in extra:
        filas.append(dict(componente=comp, fuente=fuente, config=config, tokens=tokens, modulos=mods, grupos=None, sitios_jsx=None, locales=None, consumidores_locales='—', propaga=prop, individuales=indiv, centralizable=centr))
    return filas
