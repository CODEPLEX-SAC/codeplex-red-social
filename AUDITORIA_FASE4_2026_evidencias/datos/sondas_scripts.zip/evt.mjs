import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', '--remote-debugging-port=9371', `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch('http://127.0.0.1:9371/json')).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

await cdp('Page.enable')
const FILTROS = [['Fecha', 'panel-filtro-fecha'], ['Categoría', 'panel-filtro-categoria'], ['Ubicación', 'panel-filtro-ubicacion']]
const MED = `((sel, tit) => {
  const e = sel === 'T' ? [...document.querySelectorAll('button')].find((b) => b.textContent.includes(tit) && b.closest('main')) : document.getElementById(sel)
  if (!e) return null
  const r = e.getBoundingClientRect(); const cs = getComputedStyle(e)
  return { x: Math.round(r.x * 10) / 10, y: Math.round(r.y * 10) / 10, w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10, radio: cs.borderTopLeftRadius, pad: [cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft].join(' '), fondo: cs.backgroundColor, borde: cs.borderTopWidth + ' ' + cs.borderTopColor, sombra: cs.boxShadow.slice(0, 70), pos: cs.position, z: cs.zIndex, fuente: cs.fontSize, peso: cs.fontWeight, ariaExpanded: e.getAttribute('aria-expanded'), ariaControls: e.getAttribute('aria-controls'), texto: (e.textContent || '').replace(/[a-z]+_[a-z_]+/g, '').trim().slice(0, 60), clase: String(e.className).slice(0, 200), derecha: Math.round((r.right) * 10) / 10, vw: innerWidth }
})`
const CONT = `((id) => {
  const p = document.getElementById(id); if (!p) return null
  const out = []
  p.querySelectorAll('button, input, [role=option], [role=radio], [role=checkbox], a[href]').forEach((e) => { const r = e.getBoundingClientRect(); if (r.width && r.height) out.push({ tag: e.tagName.toLowerCase(), tipo: e.type || e.getAttribute('role') || '', t: (e.textContent || e.getAttribute('aria-label') || e.placeholder || '').replace(/\s+/g, ' ').trim().slice(0, 28), w: Math.round(r.width), h: Math.round(r.height), cls: String(e.className).slice(0, 70) }) })
  const mapas = p.querySelectorAll('.leaflet-container').length
  return { n: out.length, items: out.slice(0, 40), mapas, tieneScroll: p.scrollHeight > p.clientHeight + 1 }
})`
const RES = []
for (const [w, h, mv] of [[1280, 900, false], [820, 900, false], [400, 850, true], [320, 700, true]]) {
  await viewport(w, h, mv)
  for (const [tit, id] of FILTROS) {
    await cdp('Page.navigate', { url: 'http://localhost:5173/eventos' }); await dormir(2600)
    const cerrado = await evalJS(`${MED}('T', ${JSON.stringify(tit)})`)
    if (!cerrado) { RES.push({ w, filtro: tit, error: 'disparador no encontrado' }); continue }
    await clicSel(`[...document.querySelectorAll('button')].find((b) => b.textContent.includes(${JSON.stringify(tit)}) && b.closest('main'))`)
    await dormir(700)
    const abierto = await evalJS(`${MED}('T', ${JSON.stringify(tit)})`)
    const panel = await evalJS(`${MED}(${JSON.stringify(id)})`)
    const cont = await evalJS(`${CONT}(${JSON.stringify(id)})`)
    const desborde = await evalJS('document.documentElement.scrollWidth > innerWidth + 1')
    await foto(`evt_${tit}_${w}_abierto`)
    let sel = null
    const alt = await evalJS(`(() => { const p = document.getElementById(${JSON.stringify(id)}); if (!p) return null; const o = [...p.querySelectorAll('input[type=radio], input[type=checkbox], button')].find((e) => !/cancelar|cerrar|aplicar|limpiar|atr|anterior|siguiente|mes|ver /i.test((e.textContent || e.getAttribute('aria-label') || '')) && e.getBoundingClientRect().width > 0); if (!o) return null; o.scrollIntoView({block:'center'}); const r = o.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2, t: (o.textContent || o.type || '').slice(0, 30) } })()`)
    if (alt && typeof alt !== 'string') {
      await clicXY(alt.x, alt.y); await dormir(500)
      const ap = await evalJS(`(() => { const p = document.getElementById(${JSON.stringify(id)}); const b = p && [...p.querySelectorAll('button')].find((e) => /aplicar|listo|confirmar/i.test(e.textContent)); if (!b) return null; const r = b.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2, t: b.textContent.trim() } })()`)
      if (ap && typeof ap !== 'string') { await clicXY(ap.x, ap.y); await dormir(600) }
      const trig = await evalJS(`${MED}('T', ${JSON.stringify(tit)}) || ${MED}('T', 'Fecha')`)
      const t2 = await evalJS(`[...document.querySelectorAll('main button')].filter((b) => b.className.includes('h-8') && /calendar|sell|location|Hoy|Lima|Categ|Ubic|Fecha/i.test(b.textContent)).map((b) => ({ t: b.textContent.replace(/[a-z]+_[a-z_]+/g, '').trim().slice(0, 40), h: Math.round(b.getBoundingClientRect().height), exp: b.getAttribute('aria-expanded'), clase: b.className.slice(0, 160) }))`)
      sel = { opcion: alt.t, aplicar: ap && ap.t, disparadores: t2, panelSigueAbierto: !!(await evalJS(`!!document.getElementById(${JSON.stringify(id)})`)), limpiar: await evalJS(`!![...document.querySelectorAll('main button')].find((b) => /limpiar/i.test(b.textContent))`) }
      await foto(`evt_${tit}_${w}_seleccionado`)
    }
    RES.push({ w, filtro: tit, cerrado, abierto, panel, cont, desborde, seleccion: sel })
  }
}
writeFileSync(SALIDA + '/evt.json', JSON.stringify(RES, null, 1))
ws.close(); chrome.kill(); process.exit(0)
