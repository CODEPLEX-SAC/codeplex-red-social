import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', '--remote-debugging-port=9352', `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch('http://127.0.0.1:9352/json')).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

import { readFileSync as leer2 } from 'node:fs'
await cdp('Page.enable')
const PARES = JSON.parse(process.argv[3])
const res = []
for (const p of PARES) {
  const a = leer2(p.ref).toString('base64')
  const b = leer2(p.act).toString('base64')
  const r = await evalJS(`(async () => {
    const carga = (s) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(i); i.src = 'data:image/png;base64,' + s })
    const A = await carga(${JSON.stringify(a)}); const B = await carga(${JSON.stringify(b)})
    const W = Math.max(A.width, B.width), H = Math.max(A.height, B.height)
    const mk = (img) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d', { willReadFrequently: true }); x.fillStyle = '#ff00ff'; x.fillRect(0, 0, W, H); x.drawImage(img, 0, 0); return x }
    const xa = mk(A), xb = mk(B)
    const da = xa.getImageData(0, 0, W, H), db = xb.getImageData(0, 0, W, H)
    const out = document.createElement('canvas'); out.width = W; out.height = H
    const xo = out.getContext('2d'); const dd = xo.createImageData(W, H)
    let n = 0, minx = W, miny = H, maxx = -1, maxy = -1
    const filas = new Array(H).fill(0)
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4
      const d = Math.abs(da.data[i] - db.data[i]) + Math.abs(da.data[i + 1] - db.data[i + 1]) + Math.abs(da.data[i + 2] - db.data[i + 2])
      if (d > 30) { n++; filas[y]++; if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y
        dd.data[i] = 255; dd.data[i + 1] = 0; dd.data[i + 2] = 0; dd.data[i + 3] = 255 }
      else { const g = (db.data[i] + db.data[i + 1] + db.data[i + 2]) / 3; const v = 255 - (255 - g) * 0.25; dd.data[i] = dd.data[i + 1] = dd.data[i + 2] = v; dd.data[i + 3] = 255 }
    }
    xo.putImageData(dd, 0, 0)
    const lado = document.createElement('canvas'); lado.width = W * 2 + 20; lado.height = H + 24
    const xl = lado.getContext('2d'); xl.fillStyle = '#ffffff'; xl.fillRect(0, 0, lado.width, lado.height)
    xl.fillStyle = '#000'; xl.font = 'bold 14px sans-serif'; xl.fillText('REFERENCIA (a2b857e, firma = línea base)', 4, 16); xl.fillText('ACTUAL (árbol de trabajo)', W + 24, 16)
    xl.drawImage(xa.canvas, 0, 24); xl.drawImage(xb.canvas, W + 20, 24)
    const bandas = []; let ini = -1
    for (let y = 0; y <= H; y++) { const on = y < H && filas[y] > 0; if (on && ini < 0) ini = y; if (!on && ini >= 0) { bandas.push([ini, y - 1]); ini = -1 } }
    return { w1: A.width, h1: A.height, w2: B.width, h2: B.height, pixeles: n, pct: Math.round(n / (W * H) * 10000) / 100, bbox: n ? [minx, miny, maxx, maxy] : null, bandas: bandas.slice(0, 60), lado: lado.toDataURL('image/png').split(',')[1], dif: out.toDataURL('image/png').split(',')[1] }
  })()`)
  if (typeof r === 'string') { res.push({ ...p, error: r }); continue }
  writeFileSync(p.salida + '_lado_a_lado.png', Buffer.from(r.lado, 'base64'))
  writeFileSync(p.salida + '_diferencias.png', Buffer.from(r.dif, 'base64'))
  delete r.lado; delete r.dif
  res.push({ ...p, ...r })
}
writeFileSync(SALIDA + '/imgdiff.json', JSON.stringify(res, null, 1))
ws.close(); chrome.kill(); process.exit(0)
