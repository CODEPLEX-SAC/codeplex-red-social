import { spawn } from 'node:child_process'
import { writeFileSync, mkdirSync, rmSync } from 'node:fs'

const CHROME = 'C:/Users/Angie/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe'
const PUERTO = process.env.AUD_PORT || 9335
const SALIDA = process.argv[2]
const URL_APP = process.argv[3]
const PERFIL = SALIDA + '/perfil'
rmSync(PERFIL, { recursive: true, force: true })
mkdirSync(SALIDA, { recursive: true })

const chrome = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${PUERTO}`, `--user-data-dir=${PERFIL}`, '--no-first-run', '--window-size=1280,900', 'about:blank'], { stdio: 'ignore' })
const dormir = (ms) => new Promise((r) => setTimeout(r, ms))

let lista
for (let i = 0; i < 40; i++) {
  try {
    lista = await (await fetch(`http://127.0.0.1:${PUERTO}/json`)).json()
    if (lista.length) break
  } catch {}
  await dormir(250)
}
const pagina = lista.find((t) => t.type === 'page')
const ws = new WebSocket(pagina.webSocketDebuggerUrl)
await new Promise((r) => (ws.onopen = r))
let id = 0
const pendientes = new Map()
ws.onmessage = (m) => {
  const d = JSON.parse(m.data)
  if (d.id && pendientes.has(d.id)) {
    pendientes.get(d.id)(d)
    pendientes.delete(d.id)
  }
}
const cdp = (method, params = {}) => new Promise((res) => {
  id += 1
  pendientes.set(id, res)
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJS = async (expresion) => {
  const r = await cdp('Runtime.evaluate', { expression: expresion, awaitPromise: true, returnByValue: true })
  if (r.result.exceptionDetails) return 'EXC: ' + JSON.stringify(r.result.exceptionDetails.exception?.description ?? r.result.exceptionDetails)
  return r.result.result.value
}
const foto = async (nombre) => {
  const r = await cdp('Page.captureScreenshot', { format: 'png' })
  writeFileSync(`${SALIDA}/${nombre}.png`, Buffer.from(r.result.data, 'base64'))
}
const viewport = (w, h, movil = false) => cdp('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: movil })
const clicXY = async (x, y) => {
  await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y })
  await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 })
  await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 })
}
const clicSel = async (js) => {
  const p = await evalJS(`(() => { const e = ${js}; if (!e) return null; e.scrollIntoView({block:'center'}); const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2} })()`)
  if (!p) throw new Error('no encontrado: ' + js)
  await clicXY(p.x, p.y)
  await dormir(250)
}
const tecla = async (key, code) => {
  await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: key === 'Escape' ? 27 : 9 })
  await dormir(200)
}
const escribir = async (texto) => {
  await cdp('Input.insertText', { text: texto })
  await dormir(200)
}
const boton = (nombre) => `[...document.querySelectorAll('[role=dialog] button')].find(b => b.getAttribute('aria-label') ? b.getAttribute('aria-label') === ${JSON.stringify(nombre)} : b.textContent.includes(${JSON.stringify(nombre)}))`
const botonPagina = (nombre) => `[...document.querySelectorAll('button')].find(b => b.textContent.trim().includes(${JSON.stringify(nombre)}) && !b.closest('[role=dialog]'))`
const hay = (sel) => evalJS(`!!document.querySelector(${JSON.stringify(sel)})`)

import { readFileSync as leer, appendFileSync as anexar } from 'node:fs'
const SC = process.argv[4]
const MODO = process.argv[5]
const VPS = process.argv[6].split(',').map((v) => v.split('x').map(Number))
const FILTRO = process.env.AUD_F ? new RegExp(process.env.AUD_F) : null
const FN = leer(SC + '/h/aud_cuerpo.js', 'utf8')
const RUTAS = JSON.parse(leer(SC + '/f3/rutas.json', 'utf8')).filter((r) => !/^\/no-encontrada/.test(r) && (!FILTRO || FILTRO.test(r)))
const OUT = process.argv[2] + '/' + MODO + '.jsonl'
const guardar = (o) => anexar(OUT, JSON.stringify(o) + '\n')
const PROHIBIDO = /cerrar sesi|salir|logout|eliminar cuenta|desactivar cuenta/i
const claveC = (c) => [c.region, c.tipo, c.cadena.slice(0, 4).join('>'), c.nombre].join('|')

const listo = async () => {
  await dormir(900)
  let previo = -1, estable = 0
  for (let i = 0; i < 60; i++) {
    const n = await evalJS(`document.querySelectorAll('button, a, input, textarea, [role]').length + ':' + document.body.innerText.length`)
    const cuenta = parseInt(String(n).split(':')[0], 10)
    if (n === previo && cuenta >= 4) { estable++; if (estable >= 3) break } else { estable = 0; previo = n }
    await dormir(400)
  }
}
const CAND = leer(SC + '/h/aud_cand.js', 'utf8')
const SHELL = process.env.AUD_SHELL ? 'shell' : 'pagina'
await cdp("Page.enable")
for (const [w, h] of VPS) {
  const movil = w <= 480
  await viewport(w, h, movil)
  for (const ruta of RUTAS) {
    const t0 = Date.now()
    await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta })
    await listo()
    let base = await evalJS(FN)
    for (let r = 0; r < 4 && typeof base !== 'string' && base.controles.length < 4 && ruta !== '/acceso'; r++) { await dormir(3000); base = await evalJS(FN) }
    if (typeof base === 'string') { guardar({ modo: MODO, ruta, w, error: base }); continue }
    if (MODO === 'base') { guardar({ modo: 'base', ruta, w, ...base }); continue }
    const clavesBase = new Set(base.controles.map(claveC))
    guardar({ modo: 'base', ruta, w, ...base })
    await evalJS(CAND)
    const lista = (await evalJS(`window.__aud.lista('${SHELL}')`)).filter((c) => !PROHIBIDO.test(c.n)).slice(0, 40)
    let sucio = false
    for (const c of lista) {
      if (sucio) {
        await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta })
        await listo()
        sucio = false
      }
      await evalJS(CAND)
      const p = await evalJS(`window.__aud.pos(${JSON.stringify(c.n)}, ${JSON.stringify(c.rol)}, '${SHELL}')`)
      if (!p || typeof p === 'string') continue
      await clicXY(p.x, p.y)
      await dormir(450)
      const st = await evalJS(FN)
      if (typeof st === 'string') continue
      const nuevos = st.controles.filter((x) => !clavesBase.has(claveC(x)))
      const cambioUrl = st.url !== ruta
      guardar({ modo: 'estado', ruta, w, disparador: c, urlTras: st.url, cambioUrl, nuevos, paneles: st.paneles, desborde: st.desborde, nTotal: st.controles.length, nBase: base.controles.length })
      if (process.env.AUD_N2 && st.paneles.length && !cambioUrl) {
        const clavesE = new Set(st.controles.map(claveC))
        await evalJS(CAND)
        const interior = (await evalJS(`window.__aud.lista('overlay')`)).filter((q) => !PROHIBIDO.test(q.n) && !/cancelar|cerrar|guardar|eliminar|confirmar|aceptar|enviar|crear|publicar|pagar|descargar|exportar/i.test(q.n) && ['combobox', 'tab', 'switch', 'button'].includes(q.rol)).slice(0, 14)
        for (const q of interior) {
          await cdp('Page.navigate', { url: 'http://localhost:5173' + ruta })
          await listo()
          await evalJS(CAND)
          const p1 = await evalJS(`window.__aud.pos(${JSON.stringify(c.n)}, ${JSON.stringify(c.rol)}, '${SHELL}')`)
          if (!p1 || typeof p1 === 'string') continue
          await clicXY(p1.x, p1.y)
          await dormir(450)
          await evalJS(CAND)
          const p2 = await evalJS(`window.__aud.pos(${JSON.stringify(q.n)}, ${JSON.stringify(q.rol)}, 'overlay')`)
          if (!p2 || typeof p2 === 'string') continue
          await clicXY(p2.x, p2.y)
          await dormir(450)
          const s2 = await evalJS(FN)
          if (typeof s2 === 'string') continue
          guardar({ modo: 'estado', nivel: 2, ruta, w, padre: c, disparador: q, urlTras: s2.url, cambioUrl: s2.url !== ruta, nuevos: s2.controles.filter((x) => !clavesE.has(claveC(x)) && !clavesBase.has(claveC(x))), paneles: s2.paneles, desborde: s2.desborde, nTotal: s2.controles.length, nBase: st.controles.length })
          sucio = true
        }
        sucio = true
      }
      await tecla('Escape', 'Escape')
      await dormir(150)
      const chk = await evalJS(`(() => ({ u: location.pathname, d: !!document.querySelector('[role=dialog],.MuiPopover-root,.MuiPopper-root,[role=listbox],[role=menu]') }))()`)
      if (cambioUrl || !chk || chk.u !== ruta || chk.d || st.controles.length !== base.controles.length) sucio = true
    }
    console.log(w, ruta, 'cand', lista.length, ((Date.now() - t0) / 1000).toFixed(0) + 's')
  }
}
ws.close(); chrome.kill(); process.exit(0)
