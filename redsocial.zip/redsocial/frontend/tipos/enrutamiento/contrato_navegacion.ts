export type Escucha = () => void
