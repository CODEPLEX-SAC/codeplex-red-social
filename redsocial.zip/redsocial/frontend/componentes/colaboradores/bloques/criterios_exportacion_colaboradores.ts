import dayjs from 'dayjs'
import type { Dayjs } from 'dayjs'
import catalogoColaboradores from '../../../catalogos/capacidades/redsocial/colaboradores.json'
import type { AmbitoExportacion, CondicionCriterio, CriteriosExportacion, FiltroActivo, FiltrosAvanzadosColaboradores } from '@/tipos/colaboradores/contrato_gestion_colaboradores'
import { ESTADO_POR_ETIQUETA_PESTANA, interpolarPlantilla } from './colaboradores_tabla_config'

const plantillas = catalogoColaboradores.exportacion.criterios
const panel = catalogoColaboradores.panel_filtros_avanzados
const OPCION_TODOS = catalogoColaboradores.selectores.rol_perfil.opciones[0]
const OPCION_TODAS = catalogoColaboradores.selectores.aplicaciones.opciones[0]
const ULTIMO_ACCESO_TODOS = panel.ultimo_acceso.opciones[0]
const APLICACION_ASIGNADA_TODAS = panel.aplicaciones_asignadas.opciones[0]
const CLAVES = catalogoColaboradores.filtros_activos.claves

function valor(plantilla: string, texto: string): string {
  return interpolarPlantilla(plantilla, { valor: texto })
}

function fecha(instante: Dayjs | null): string {
  return dayjs(instante).format(panel.formato_fecha)
}

function activas(condiciones: CondicionCriterio[]): string[] {
  return condiciones.filter(([activa]) => activa).map(([, texto]) => texto)
}

export function listarFiltrosAvanzados(filtros: FiltrosAvanzadosColaboradores): FiltroActivo[] {
  const condiciones: [string, boolean, string][] = [
    [CLAVES.vigencia_desde, Boolean(filtros.fechaInicio), valor(plantillas.vigencia_desde, fecha(filtros.fechaInicio))],
    [CLAVES.vigencia_hasta, Boolean(filtros.fechaFin), valor(plantillas.vigencia_hasta, fecha(filtros.fechaFin))],
    [CLAVES.invitacion_desde, Boolean(filtros.invitacionDesde), valor(plantillas.invitacion_desde, fecha(filtros.invitacionDesde))],
    [CLAVES.invitacion_hasta, Boolean(filtros.invitacionHasta), valor(plantillas.invitacion_hasta, fecha(filtros.invitacionHasta))],
    [CLAVES.ultimo_acceso, filtros.ultimoAcceso !== ULTIMO_ACCESO_TODOS, valor(plantillas.ultimo_acceso, filtros.ultimoAcceso)],
    [CLAVES.acceso_vigente, filtros.accesoVigente, plantillas.acceso_vigente],
    [CLAVES.acceso_vencido, filtros.accesoVencido, plantillas.acceso_vencido],
    [CLAVES.aplicacion_asignada, filtros.aplicaciones !== APLICACION_ASIGNADA_TODAS, valor(plantillas.aplicacion_asignada, filtros.aplicaciones)],
    [CLAVES.cuenta_creada, filtros.cuentaCreada, plantillas.cuenta_creada],
    [CLAVES.cuenta_invitada, filtros.cuentaInvitada, plantillas.cuenta_invitada],
  ]
  return condiciones.filter(([, activa]) => activa).map(([clave, , etiqueta]) => ({ clave, etiqueta }))
}

export function describirFiltrosAvanzados(filtros: FiltrosAvanzadosColaboradores): string[] {
  return listarFiltrosAvanzados(filtros).map((filtro) => filtro.etiqueta)
}

export function describirCriteriosFiltrados(criterios: CriteriosExportacion): string[] {
  return activas([
    [Boolean(ESTADO_POR_ETIQUETA_PESTANA[criterios.pestana]), valor(plantillas.pestana, criterios.pestana)],
    [Boolean(criterios.busqueda.trim()), valor(plantillas.busqueda, criterios.busqueda.trim())],
    [criterios.rol !== OPCION_TODOS, valor(plantillas.rol, criterios.rol)],
    [criterios.aplicacion !== OPCION_TODAS, valor(plantillas.aplicacion, criterios.aplicacion)],
  ]).concat(describirFiltrosAvanzados(criterios.avanzados))
}

export function describirCriterios(criterios: CriteriosExportacion, ambito: AmbitoExportacion): string[] {
  const orden = valor(plantillas.orden, criterios.ordenarPor)
  const alcance = ambito === 'vista' ? [valor(plantillas.vista, criterios.pestana)] : [plantillas.filtrados, ...describirCriteriosFiltrados(criterios)]
  return [...alcance, orden]
}
