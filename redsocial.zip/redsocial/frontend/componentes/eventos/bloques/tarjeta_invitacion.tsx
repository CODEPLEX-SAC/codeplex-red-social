import { GrupoAvatares } from '../../compartido/interfaz/grupo_avatares'
import { Boton } from '../../compartido/interfaz/boton'
import { Icono } from '../../compartido/icono'
import { TextoColor } from '../../compartido/interfaz/texto_color'
import { AvatarImagen } from '../../compartido/interfaz/avatar_imagen'
import { imagenEventoPredeterminada as imagenEvento } from '../../compartido/icono'
import catalogoEventos from '../../../catalogos/capacidades/redsocial/eventos.json'
import type { TarjetaInvitacionProps } from '@/tipos/eventos/contrato_invitacion'

export function TarjetaInvitacion({ inv }: TarjetaInvitacionProps) {
  return (
    <article className="grid grid-cols-140-1fr-auto overflow-hidden rounded-xl border border-gris-borde bg-white transition-shadow hover:shadow-t7 max-900:grid-cols-1">
      <div className="relative min-h-35 overflow-hidden max-900:min-h-40">
        <AvatarImagen src={imagenEvento} className="h-full w-full" />
        <div className="absolute left-3.5 top-3.5 rounded-control bg-white px-3 py-2 text-center shadow-t5">
          <span className="block text-dia-evento leading-none text-texto">{inv.dia}</span>
          <span className="mt-px block text-mes-evento uppercase text-texto-suave">{inv.mes}</span>
        </div>
      </div>
      <div className="flex flex-col justify-center gap-1.5 px-5 py-4">
        <div className="flex items-start justify-between gap-2">
          <TextoColor variante={inv.categoriaColor} className="inline-block text-badge uppercase tracking-wide">
            {inv.categoria}
          </TextoColor>
          {inv.estado === 'aceptada' && (
            <span className="hidden whitespace-nowrap rounded-lg bg-fondo-categoria-verde px-3 py-1 text-badge text-verde-categoria-texto max-900:inline-flex">
              {catalogoEventos.leyendas.estado_aceptada}
            </span>
          )}
        </div>
        <h3 className="m-0 text-nombre-entidad text-texto">{inv.nombre}</h3>
        <p className="m-0 text-subtitulo leading-texto text-texto-suave">{inv.descripcion}</p>
        <div className="flex flex-wrap gap-3 text-auxiliar text-texto-suave">
          <span className="flex items-center gap-1"><Icono name="calendario" className="w-3.5 h-3.5" /> {inv.fecha}</span>
          <span className="flex items-center gap-1"><Icono name="reloj" className="w-3.5 h-3.5" /> {inv.hora}</span>
          <span className="flex items-center gap-1"><Icono name="ubicacion" className="w-3.5 h-3.5" /> {inv.ubicacion}</span>
        </div>
        <div className="mt-1 flex items-center gap-2">
          <GrupoAvatares avatares={inv.avatares} tamano="sm" />
          <div className="text-auxiliar leading-compacto">
            <span className="block text-nombre-fila">{inv.invitador}</span>
            <span className="text-auxiliar text-texto-suave">{catalogoEventos.leyendas.te_ha_invitado}</span>
          </div>
        </div>
      </div>
      <div
        className={
          'flex flex-col justify-center gap-2 p-4 max-900:items-center max-900:px-4 max-900:pb-4 max-900:pt-0 ' +
          (inv.estado === 'aceptada' ? '' : 'max-900:flex-row')
        }
      >
        {inv.estado === 'pendiente' ? (
          <>
            <Boton type="button" variant="primario" size="default" className="max-900:flex-1">{catalogoEventos.botones.aceptar}</Boton>
            <Boton type="button" variant="secundario" size="default" className="max-900:flex-1">{catalogoEventos.botones.tal_vez}</Boton>
            <Boton type="button" variant="peligro_contorno" size="default" className="max-900:flex-1">{catalogoEventos.botones.rechazar}</Boton>
          </>
        ) : inv.estado === 'aceptada' ? (
          <>
            <span className="flex items-center justify-center whitespace-nowrap rounded-lg bg-fondo-categoria-verde px-4 py-2 text-boton text-verde-categoria-texto max-900:hidden">
              {catalogoEventos.leyendas.estado_aceptada}
            </span>
            <Boton type="button" variant="secundario" size="default" className="max-900:order-2 max-900:w-full max-900:border-transparent max-900:bg-primario-suave max-900:text-primario">
              {catalogoEventos.botones.ver_evento}
            </Boton>
            <Boton type="button" variant="secundario" size="default" className="max-900:order-1 max-900:w-full">
              {catalogoEventos.botones.agregar_calendario}
            </Boton>
          </>
        ) : (
          <>
            <span className="flex items-center justify-center whitespace-nowrap rounded-lg bg-fondo-peligro-suave px-4 py-2 text-boton text-rojo-categoria-texto">
              {catalogoEventos.leyendas.estado_rechazada}
            </span>
            <Boton type="button" variant="secundario" size="default" className="max-900:flex-1">
              {catalogoEventos.botones.ver_evento}
            </Boton>
          </>
        )}
      </div>
    </article>
  )
}
