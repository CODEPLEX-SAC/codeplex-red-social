import { BotonIcono } from '../../compartido/interfaz/boton_icono'
import { Boton } from '../../compartido/interfaz/boton'
import { Icono } from '../../compartido/icono'
import { AvatarUsuario } from '../../compartido/interfaz/avatar_usuario'
import { imagenUsuarioPredeterminada as usuarioImg } from '../../compartido/icono'
import catalogoAvisos from '../../../catalogos/capacidades/redsocial/avisos.json'
import textosRedSocial from '../../../mensajes/capacidades/redsocial/textos.json'
import type { PanelDetalleAvisoProps } from '@/tipos/avisos/contrato_detalle_aviso'
import { CLASE_ENLACE_ACCION } from '../../compartido/clases_enlace'

export function PanelDetalleNovedad({ detalle }: PanelDetalleAvisoProps) {
  return (
    <section className="rounded-xl border border-borde bg-white p-4">
      <div className="mb-3.5 flex items-center gap-2.5">
        <AvatarUsuario tamano="sm" imagen={usuarioImg} />
        <div className="min-w-0 flex-1">
          <strong className="block truncate text-nombre-fila text-texto">{detalle.autor}</strong>
          <span className="block text-fecha-abreviada text-texto-suave">{detalle.tiempo}</span>
        </div>
        <BotonIcono icono="cerrar" type="button" aria-label={textosRedSocial.CERRAR} variant="discreto" size="sm" className="flex-none" />
      </div>

      <h2 className="m-0 mb-1.5 text-titulo-banner text-texto">{catalogoAvisos.secciones.comentaron_en_tu_publicacion}</h2>
      <p className="m-0 mb-3 text-subtitulo leading-texto text-texto-suave">{detalle.comentario}</p>

      <div className="mb-3 flex items-center gap-2.5 rounded-lg border border-borde bg-fondo p-2.5">
        <div className="grid h-11 w-11 flex-none place-items-center rounded-md bg-fondo-miniatura text-texto-suave">
          <Icono name="panel" className="h-4.5 w-4.5" />
        </div>
        <div className="min-w-0 flex-1">
          <strong className="block truncate text-subtitulo text-texto">{detalle.publicacion.titulo}</strong>
          <span className="block truncate text-subtitulo text-texto-suave">{detalle.publicacion.descripcion}</span>
        </div>
      </div>

      <div className="mb-3.5 flex items-center gap-2 border-b border-borde-suave pb-3.5">
        <Boton type="button" variant="secundario" size="default" className="flex-1">
          <Icono name="me-gusta" className="h-4 w-4" /> {catalogoAvisos.botones.me_gusta}
        </Boton>
        <Boton type="button" variant="secundario" size="default" className="flex-1">
          <Icono name="comentario" className="h-4 w-4" /> {catalogoAvisos.botones.responder}
        </Boton>
      </div>

      <h3 className="m-0 mb-2 text-titulo-banner text-texto">
        {catalogoAvisos.secciones.personas_que_comentaron} ({detalle.comentarios.length})
      </h3>
      <ul className="m-0 grid list-none gap-2.5 p-0">
        {detalle.comentarios.map((c) => (
          <li key={c.nombre} className="flex items-start gap-2">
            <AvatarUsuario tamano="xs" imagen={usuarioImg} />
            <div className="min-w-0 flex-1 text-subtitulo">
              <span className="text-nombre-fila text-texto">{c.nombre}</span> <span className="text-texto-suave">{c.texto}</span>
              <span className="mt-0.5 block text-fecha-abreviada text-texto-suave">{c.tiempo}</span>
            </div>
            <BotonIcono icono="puntos" type="button" aria-label={textosRedSocial.MAS_OPCIONES} variant="discreto" size="sm" className="flex-none" />
          </li>
        ))}
      </ul>

      <a href="#" className={[CLASE_ENLACE_ACCION, 'mt-3 flex items-center justify-center gap-1'].join(' ')}>
        {catalogoAvisos.botones.ver_conversacion_completa} <Icono name="flecha-derecha" className="h-3 w-3" />
      </a>
    </section>
  )
}
