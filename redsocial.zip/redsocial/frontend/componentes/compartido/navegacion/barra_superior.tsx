import { BotonIcono } from '../../compartido/interfaz/boton_icono'
import { irARuta } from '../../compartido/interfaz/menu'
import { BuscadorGlobal } from './buscador_global'
import { AccesoNovedadesTopbar } from './boton_avisos_topbar'
import { BotonCarritoTopbar } from './boton_carrito_topbar'
import { BotonMensajesTopbar } from './boton_mensajes_topbar'
import { MenuUsuarioTopbar } from './menu_usuario_topbar'
import { SelectorEmpresaTopbar } from './selector_empresa_topbar'
import textosRedSocial from '../../../mensajes/capacidades/redsocial/textos.json'
import catalogoAmigos from '../../../catalogos/capacidades/redsocial/amigos.json'

export function BarraSuperior() {
  return (
    <header className="flex h-barra-superior items-center gap-md border-b border-borde bg-superficie px-md max-900:pl-16">
      <div className="flex min-w-0 flex-1 items-center gap-md max-800:hidden">
        <BuscadorGlobal />

        <SelectorEmpresaTopbar />
      </div>

      <div className="ml-auto flex items-center gap-sm max-800:gap-1.5">
        <BotonIcono icono="mas" type="button" aria-label={textosRedSocial.CREAR} variant="primario" size="default" />
        <BotonIcono icono="amigos" type="button" aria-label={textosRedSocial.AMIGOS} variant="sutil" size="default" className="max-800:hidden" onClick={() => irARuta(catalogoAmigos.rutas.todos)} />
        <BotonMensajesTopbar />
        <BotonCarritoTopbar />
        <AccesoNovedadesTopbar />
        <BotonIcono icono="cuadricula" type="button" aria-label={textosRedSocial.MODULOS} variant="sutil" size="default" className="max-800:hidden" />
        <MenuUsuarioTopbar />
      </div>
    </header>
  )
}
