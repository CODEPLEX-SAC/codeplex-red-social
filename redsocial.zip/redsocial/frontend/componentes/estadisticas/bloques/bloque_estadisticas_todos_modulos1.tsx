import catalogoCompartido from '../../../catalogos/capacidades/redsocial/compartido.json'
import type { IconName } from '@/tipos/compartido/contrato_icono'
import { CabeceraTarjetaKpi } from '../../compartido/interfaz/cabecera_tarjeta_kpi'
import { Sparkline } from '../../compartido/interfaz/sparkline'
import { Icono } from '../../compartido/icono'
import type { Kpi } from '@/tipos/estadisticas/modelo_estadisticas_todos_modulos'
import { CLASES_TARJETA } from '../../compartido/clases_tarjeta'

export function BloqueEstadisticasTodosModulos1({
  KPIS,
  CLASES_ICONO_KPI,
  COMPARATIVO_KPI,
}: {
  KPIS: Kpi[]
  CLASES_ICONO_KPI: Record<'azul' | 'rojo' | 'verde' | 'morado' | 'cian', string>
  COMPARATIVO_KPI: string
}) {
  return (
    <div className="mb-5 grid grid-cols-5 gap-4 max-1250:grid-cols-3 max-900:grid-cols-2 max-480:grid-cols-1">
      {KPIS.map((kpi) => (
        <article key={kpi.etiqueta} className={CLASES_TARJETA.mosaico}>
          <CabeceraTarjetaKpi etiqueta={kpi.etiqueta} icono={kpi.icono} claseIcono={CLASES_ICONO_KPI[kpi.color]} />
          <strong className="mb-2 block text-valor-destacado text-texto">{kpi.valor}</strong>
          <div className="flex items-center justify-between gap-2.5">
            <small
              className={
                'inline-flex min-w-0 flex-wrap items-center gap-0.75 text-conteo ' +
                catalogoCompartido.variacion_kpi[kpi.variacion.direccion].clase
              }
            >
              <Icono name={catalogoCompartido.variacion_kpi[kpi.variacion.direccion].icono as IconName} className="h-3 w-3" />
              {kpi.variacion.texto} <em className="ml-0.5 font-etiqueta not-italic text-texto-suave">{COMPARATIVO_KPI}</em>
            </small>
            <Sparkline puntos={kpi.sparklinePuntos} color={kpi.sparklineColor} alto={30} grosor={2.5} className="h-5.5 w-15 flex-none" />
          </div>
        </article>
      ))}
    </div>
  )
}
